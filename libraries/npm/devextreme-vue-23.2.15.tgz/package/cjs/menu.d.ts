/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/menu";
import Menu, { Properties } from "devextreme/ui/menu";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "adaptivityEnabled" | "animation" | "cssClass" | "dataSource" | "disabled" | "disabledExpr" | "displayExpr" | "elementAttr" | "focusStateEnabled" | "height" | "hideSubmenuOnMouseLeave" | "hint" | "hoverStateEnabled" | "items" | "itemsExpr" | "itemTemplate" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "onSubmenuHidden" | "onSubmenuHiding" | "onSubmenuShowing" | "onSubmenuShown" | "orientation" | "rtlEnabled" | "selectByClick" | "selectedExpr" | "selectedItem" | "selectionMode" | "showFirstSubmenuMode" | "showSubmenuMode" | "submenuDirection" | "tabIndex" | "visible" | "width">;
interface DxMenu extends AccessibleOptions {
    readonly instance?: Menu;
}
declare const DxMenu: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxDelay: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxShowFirstSubmenuMode: any;
declare const DxShowSubmenuMode: any;
declare const DxTo: any;
export default DxMenu;
export { DxMenu, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxDelay, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxPosition, DxShow, DxShowFirstSubmenuMode, DxShowSubmenuMode, DxTo };
import type * as DxMenuTypes from "devextreme/ui/menu_types";
export { DxMenuTypes };
