/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Slider, { Properties } from "devextreme/ui/slider";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "keyStep" | "label" | "max" | "min" | "name" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "showRange" | "step" | "tabIndex" | "tooltip" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeMode" | "visible" | "width">;
interface DxSlider extends AccessibleOptions {
    readonly instance?: Slider;
}
declare const DxSlider: any;
declare const DxFormat: any;
declare const DxLabel: any;
declare const DxTooltip: any;
export default DxSlider;
export { DxSlider, DxFormat, DxLabel, DxTooltip };
import type * as DxSliderTypes from "devextreme/ui/slider_types";
export { DxSliderTypes };
