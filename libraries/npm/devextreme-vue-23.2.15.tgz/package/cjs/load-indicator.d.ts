/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import LoadIndicator, { Properties } from "devextreme/ui/load_indicator";
declare type AccessibleOptions = Pick<Properties, "elementAttr" | "height" | "hint" | "indicatorSrc" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "visible" | "width">;
interface DxLoadIndicator extends AccessibleOptions {
    readonly instance?: LoadIndicator;
}
declare const DxLoadIndicator: any;
export default DxLoadIndicator;
export { DxLoadIndicator };
import type * as DxLoadIndicatorTypes from "devextreme/ui/load_indicator_types";
export { DxLoadIndicatorTypes };
