/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/context_menu";
import ContextMenu, { Properties } from "devextreme/ui/context_menu";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animation" | "closeOnOutsideClick" | "cssClass" | "dataSource" | "disabled" | "disabledExpr" | "displayExpr" | "elementAttr" | "focusStateEnabled" | "height" | "hideOnOutsideClick" | "hint" | "hoverStateEnabled" | "items" | "itemsExpr" | "itemTemplate" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemRendered" | "onOptionChanged" | "onPositioning" | "onSelectionChanged" | "onShowing" | "onShown" | "position" | "rtlEnabled" | "selectByClick" | "selectedExpr" | "selectedItem" | "selectionMode" | "showEvent" | "showSubmenuMode" | "submenuDirection" | "tabIndex" | "target" | "visible" | "width">;
interface DxContextMenu extends AccessibleOptions {
    readonly instance?: ContextMenu;
}
declare const DxContextMenu: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxDelay: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxShowEvent: any;
declare const DxShowSubmenuMode: any;
declare const DxTo: any;
export default DxContextMenu;
export { DxContextMenu, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxDelay, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxPosition, DxShow, DxShowEvent, DxShowSubmenuMode, DxTo };
import type * as DxContextMenuTypes from "devextreme/ui/context_menu_types";
export { DxContextMenuTypes };
