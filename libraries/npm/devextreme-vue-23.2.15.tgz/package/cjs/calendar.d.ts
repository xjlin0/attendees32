/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Calendar, { Properties } from "devextreme/ui/calendar";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "cellTemplate" | "dateSerializationFormat" | "disabled" | "disabledDates" | "elementAttr" | "firstDayOfWeek" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "max" | "maxZoomLevel" | "min" | "minZoomLevel" | "name" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "selectionMode" | "selectWeekOnClick" | "showTodayButton" | "showWeekNumbers" | "tabIndex" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "weekNumberRule" | "width" | "zoomLevel">;
interface DxCalendar extends AccessibleOptions {
    readonly instance?: Calendar;
}
declare const DxCalendar: any;
export default DxCalendar;
export { DxCalendar };
import type * as DxCalendarTypes from "devextreme/ui/calendar_types";
export { DxCalendarTypes };
