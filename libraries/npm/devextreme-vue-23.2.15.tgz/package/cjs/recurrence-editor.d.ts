/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import RecurrenceEditor, { Properties } from "devextreme/ui/recurrence_editor";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "tabIndex" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "width">;
interface DxRecurrenceEditor extends AccessibleOptions {
    readonly instance?: RecurrenceEditor;
}
declare const DxRecurrenceEditor: any;
export default DxRecurrenceEditor;
export { DxRecurrenceEditor };
import type * as DxRecurrenceEditorTypes from "devextreme/ui/recurrence_editor_types";
export { DxRecurrenceEditorTypes };
