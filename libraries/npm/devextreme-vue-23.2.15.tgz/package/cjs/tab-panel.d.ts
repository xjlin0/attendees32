/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/tab_panel";
import TabPanel, { Properties } from "devextreme/ui/tab_panel";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animationEnabled" | "dataSource" | "deferRendering" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "iconPosition" | "itemHoldTimeout" | "items" | "itemTemplate" | "itemTitleTemplate" | "loop" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "onTitleClick" | "onTitleHold" | "onTitleRendered" | "repaintChangesOnly" | "rtlEnabled" | "scrollByContent" | "scrollingEnabled" | "selectedIndex" | "selectedItem" | "showNavButtons" | "stylingMode" | "swipeEnabled" | "tabIndex" | "tabsPosition" | "visible" | "width">;
interface DxTabPanel extends AccessibleOptions {
    readonly instance?: TabPanel;
}
declare const DxTabPanel: any;
declare const DxItem: any;
export default DxTabPanel;
export { DxTabPanel, DxItem };
import type * as DxTabPanelTypes from "devextreme/ui/tab_panel_types";
export { DxTabPanelTypes };
