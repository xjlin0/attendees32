/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Resizable, { Properties } from "devextreme/ui/resizable";
declare type AccessibleOptions = Pick<Properties, "area" | "elementAttr" | "handles" | "height" | "keepAspectRatio" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onResize" | "onResizeEnd" | "onResizeStart" | "rtlEnabled" | "width">;
interface DxResizable extends AccessibleOptions {
    readonly instance?: Resizable;
}
declare const DxResizable: any;
export default DxResizable;
export { DxResizable };
import type * as DxResizableTypes from "devextreme/ui/resizable_types";
export { DxResizableTypes };
