/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import TextBox, { Properties } from "devextreme/ui/text_box";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "buttons" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "label" | "labelMode" | "mask" | "maskChar" | "maskInvalidMessage" | "maskRules" | "maxLength" | "mode" | "name" | "onChange" | "onContentReady" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOptionChanged" | "onPaste" | "onValueChanged" | "placeholder" | "readOnly" | "rtlEnabled" | "showClearButton" | "showMaskMode" | "spellcheck" | "stylingMode" | "tabIndex" | "text" | "useMaskedValue" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "visible" | "width">;
interface DxTextBox extends AccessibleOptions {
    readonly instance?: TextBox;
}
declare const DxTextBox: any;
declare const DxButton: any;
declare const DxOptions: any;
export default DxTextBox;
export { DxTextBox, DxButton, DxOptions };
import type * as DxTextBoxTypes from "devextreme/ui/text_box_types";
export { DxTextBoxTypes };
