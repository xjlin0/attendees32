/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/accordion";
import Accordion, { Properties } from "devextreme/ui/accordion";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animationDuration" | "collapsible" | "dataSource" | "deferRendering" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "itemTitleTemplate" | "keyExpr" | "multiple" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onItemTitleClick" | "onOptionChanged" | "onSelectionChanged" | "repaintChangesOnly" | "rtlEnabled" | "selectedIndex" | "selectedItem" | "selectedItemKeys" | "selectedItems" | "tabIndex" | "visible" | "width">;
interface DxAccordion extends AccessibleOptions {
    readonly instance?: Accordion;
}
declare const DxAccordion: any;
declare const DxItem: any;
export default DxAccordion;
export { DxAccordion, DxItem };
import type * as DxAccordionTypes from "devextreme/ui/accordion_types";
export { DxAccordionTypes };
