/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Gantt, { Properties } from "devextreme/ui/gantt";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowSelection" | "columns" | "contextMenu" | "dependencies" | "disabled" | "editing" | "elementAttr" | "endDateRange" | "filterRow" | "firstDayOfWeek" | "focusStateEnabled" | "headerFilter" | "height" | "hint" | "hoverStateEnabled" | "onContentReady" | "onContextMenuPreparing" | "onCustomCommand" | "onDependencyDeleted" | "onDependencyDeleting" | "onDependencyInserted" | "onDependencyInserting" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onResourceAssigned" | "onResourceAssigning" | "onResourceDeleted" | "onResourceDeleting" | "onResourceInserted" | "onResourceInserting" | "onResourceManagerDialogShowing" | "onResourceUnassigned" | "onResourceUnassigning" | "onScaleCellPrepared" | "onSelectionChanged" | "onTaskClick" | "onTaskDblClick" | "onTaskDeleted" | "onTaskDeleting" | "onTaskEditDialogShowing" | "onTaskInserted" | "onTaskInserting" | "onTaskMoving" | "onTaskUpdated" | "onTaskUpdating" | "resourceAssignments" | "resources" | "rootValue" | "scaleType" | "scaleTypeRange" | "selectedRowKey" | "showDependencies" | "showResources" | "showRowLines" | "sorting" | "startDateRange" | "stripLines" | "tabIndex" | "taskContentTemplate" | "taskListWidth" | "taskProgressTooltipContentTemplate" | "tasks" | "taskTimeTooltipContentTemplate" | "taskTitlePosition" | "taskTooltipContentTemplate" | "toolbar" | "validation" | "visible" | "width">;
interface DxGantt extends AccessibleOptions {
    readonly instance?: Gantt;
}
declare const DxGantt: any;
declare const DxColumn: any;
declare const DxColumnHeaderFilter: any;
declare const DxColumnHeaderFilterSearch: any;
declare const DxContextMenu: any;
declare const DxContextMenuItem: any;
declare const DxDependencies: any;
declare const DxEditing: any;
declare const DxFilterRow: any;
declare const DxFormat: any;
declare const DxGanttHeaderFilter: any;
declare const DxGanttHeaderFilterSearch: any;
declare const DxHeaderFilter: any;
declare const DxItem: any;
declare const DxOperationDescriptions: any;
declare const DxResourceAssignments: any;
declare const DxResources: any;
declare const DxScaleTypeRange: any;
declare const DxSearch: any;
declare const DxSorting: any;
declare const DxStripLine: any;
declare const DxTasks: any;
declare const DxTexts: any;
declare const DxToolbar: any;
declare const DxToolbarItem: any;
declare const DxValidation: any;
export default DxGantt;
export { DxGantt, DxColumn, DxColumnHeaderFilter, DxColumnHeaderFilterSearch, DxContextMenu, DxContextMenuItem, DxDependencies, DxEditing, DxFilterRow, DxFormat, DxGanttHeaderFilter, DxGanttHeaderFilterSearch, DxHeaderFilter, DxItem, DxOperationDescriptions, DxResourceAssignments, DxResources, DxScaleTypeRange, DxSearch, DxSorting, DxStripLine, DxTasks, DxTexts, DxToolbar, DxToolbarItem, DxValidation };
import type * as DxGanttTypes from "devextreme/ui/gantt_types";
export { DxGanttTypes };
