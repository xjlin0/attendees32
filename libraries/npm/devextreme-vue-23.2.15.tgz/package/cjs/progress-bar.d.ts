/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import ProgressBar, { Properties } from "devextreme/ui/progress_bar";
declare type AccessibleOptions = Pick<Properties, "disabled" | "elementAttr" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "max" | "min" | "onComplete" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "showStatus" | "statusFormat" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "width">;
interface DxProgressBar extends AccessibleOptions {
    readonly instance?: ProgressBar;
}
declare const DxProgressBar: any;
export default DxProgressBar;
export { DxProgressBar };
import type * as DxProgressBarTypes from "devextreme/ui/progress_bar_types";
export { DxProgressBarTypes };
