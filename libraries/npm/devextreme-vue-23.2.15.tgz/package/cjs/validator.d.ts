/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Validator, { Properties } from "devextreme/ui/validator";
declare type AccessibleOptions = Pick<Properties, "adapter" | "elementAttr" | "height" | "name" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValidated" | "validationGroup" | "validationRules" | "width">;
interface DxValidator extends AccessibleOptions {
    readonly instance?: Validator;
}
declare const DxValidator: any;
declare const DxAdapter: any;
declare const DxAsyncRule: any;
declare const DxCompareRule: any;
declare const DxCustomRule: any;
declare const DxEmailRule: any;
declare const DxNumericRule: any;
declare const DxPatternRule: any;
declare const DxRangeRule: any;
declare const DxRequiredRule: any;
declare const DxStringLengthRule: any;
declare const DxValidationRule: any;
export default DxValidator;
export { DxValidator, DxAdapter, DxAsyncRule, DxCompareRule, DxCustomRule, DxEmailRule, DxNumericRule, DxPatternRule, DxRangeRule, DxRequiredRule, DxStringLengthRule, DxValidationRule };
import type * as DxValidatorTypes from "devextreme/ui/validator_types";
export { DxValidatorTypes };
