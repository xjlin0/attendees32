/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import HtmlEditor, { Properties } from "devextreme/ui/html_editor";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowSoftLineBreak" | "customizeModules" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "imageUpload" | "isDirty" | "isValid" | "mediaResizing" | "mentions" | "name" | "onContentReady" | "onDisposing" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "placeholder" | "readOnly" | "rtlEnabled" | "stylingMode" | "tabIndex" | "tableContextMenu" | "tableResizing" | "toolbar" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueType" | "variables" | "visible" | "width">;
interface DxHtmlEditor extends AccessibleOptions {
    readonly instance?: HtmlEditor;
}
declare const DxHtmlEditor: any;
declare const DxFileUploaderOptions: any;
declare const DxImageUpload: any;
declare const DxItem: any;
declare const DxMediaResizing: any;
declare const DxMention: any;
declare const DxTab: any;
declare const DxTableContextMenu: any;
declare const DxTableContextMenuItem: any;
declare const DxTableResizing: any;
declare const DxToolbar: any;
declare const DxToolbarItem: any;
declare const DxVariables: any;
export default DxHtmlEditor;
export { DxHtmlEditor, DxFileUploaderOptions, DxImageUpload, DxItem, DxMediaResizing, DxMention, DxTab, DxTableContextMenu, DxTableContextMenuItem, DxTableResizing, DxToolbar, DxToolbarItem, DxVariables };
import type * as DxHtmlEditorTypes from "devextreme/ui/html_editor_types";
export { DxHtmlEditorTypes };
