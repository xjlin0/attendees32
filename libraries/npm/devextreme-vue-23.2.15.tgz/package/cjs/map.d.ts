/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Map, { Properties } from "devextreme/ui/map";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "apiKey" | "autoAdjust" | "center" | "controls" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "markerIconSrc" | "markers" | "onClick" | "onDisposing" | "onInitialized" | "onMarkerAdded" | "onMarkerRemoved" | "onOptionChanged" | "onReady" | "onRouteAdded" | "onRouteRemoved" | "provider" | "routes" | "rtlEnabled" | "tabIndex" | "type" | "visible" | "width" | "zoom">;
interface DxMap extends AccessibleOptions {
    readonly instance?: Map;
}
declare const DxMap: any;
declare const DxApiKey: any;
declare const DxCenter: any;
declare const DxLocation: any;
declare const DxMarker: any;
declare const DxRoute: any;
declare const DxTooltip: any;
export default DxMap;
export { DxMap, DxApiKey, DxCenter, DxLocation, DxMarker, DxRoute, DxTooltip };
import type * as DxMapTypes from "devextreme/ui/map_types";
export { DxMapTypes };
