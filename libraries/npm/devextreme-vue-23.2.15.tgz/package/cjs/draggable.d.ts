/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Draggable, { Properties } from "devextreme/ui/draggable";
declare type AccessibleOptions = Pick<Properties, "autoScroll" | "boundary" | "clone" | "container" | "cursorOffset" | "data" | "dragDirection" | "dragTemplate" | "elementAttr" | "group" | "handle" | "height" | "onDisposing" | "onDragEnd" | "onDragMove" | "onDragStart" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "scrollSensitivity" | "scrollSpeed" | "width">;
interface DxDraggable extends AccessibleOptions {
    readonly instance?: Draggable;
}
declare const DxDraggable: any;
declare const DxCursorOffset: any;
export default DxDraggable;
export { DxDraggable, DxCursorOffset };
import type * as DxDraggableTypes from "devextreme/ui/draggable_types";
export { DxDraggableTypes };
