/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/tile_view";
import TileView, { Properties } from "devextreme/ui/tile_view";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "baseItemHeight" | "baseItemWidth" | "dataSource" | "direction" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "itemMargin" | "items" | "itemTemplate" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rtlEnabled" | "showScrollbar" | "tabIndex" | "visible" | "width">;
interface DxTileView extends AccessibleOptions {
    readonly instance?: TileView;
}
declare const DxTileView: any;
declare const DxItem: any;
export default DxTileView;
export { DxTileView, DxItem };
import type * as DxTileViewTypes from "devextreme/ui/tile_view_types";
export { DxTileViewTypes };
