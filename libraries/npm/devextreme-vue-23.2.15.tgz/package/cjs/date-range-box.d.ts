/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import DateRangeBox, { Properties } from "devextreme/ui/date_range_box";
declare type AccessibleOptions = Pick<Properties, "acceptCustomValue" | "accessKey" | "activeStateEnabled" | "applyButtonText" | "applyValueMode" | "buttons" | "calendarOptions" | "cancelButtonText" | "dateSerializationFormat" | "deferRendering" | "disabled" | "disableOutOfRangeSelection" | "displayFormat" | "dropDownButtonTemplate" | "dropDownOptions" | "elementAttr" | "endDate" | "endDateInputAttr" | "endDateLabel" | "endDateName" | "endDateOutOfRangeMessage" | "endDatePlaceholder" | "endDateText" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "invalidEndDateMessage" | "invalidStartDateMessage" | "isDirty" | "isValid" | "labelMode" | "max" | "min" | "multiView" | "onChange" | "onClosed" | "onContentReady" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOpened" | "onOptionChanged" | "onPaste" | "onValueChanged" | "opened" | "openOnFieldClick" | "readOnly" | "rtlEnabled" | "showClearButton" | "showDropDownButton" | "spellcheck" | "startDate" | "startDateInputAttr" | "startDateLabel" | "startDateName" | "startDateOutOfRangeMessage" | "startDatePlaceholder" | "startDateText" | "stylingMode" | "tabIndex" | "todayButtonText" | "useMaskBehavior" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "visible" | "width">;
interface DxDateRangeBox extends AccessibleOptions {
    readonly instance?: DateRangeBox;
}
declare const DxDateRangeBox: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCalendarOptions: any;
declare const DxCollision: any;
declare const DxDisplayFormat: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxDateRangeBox;
export { DxDateRangeBox, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCalendarOptions, DxCollision, DxDisplayFormat, DxDropDownOptions, DxFrom, DxHide, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxDateRangeBoxTypes from "devextreme/ui/date_range_box_types";
export { DxDateRangeBoxTypes };
