/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import NumberBox, { Properties } from "devextreme/ui/number_box";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "buttons" | "disabled" | "elementAttr" | "focusStateEnabled" | "format" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "invalidValueMessage" | "isDirty" | "isValid" | "label" | "labelMode" | "max" | "min" | "mode" | "name" | "onChange" | "onContentReady" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOptionChanged" | "onPaste" | "onValueChanged" | "placeholder" | "readOnly" | "rtlEnabled" | "showClearButton" | "showSpinButtons" | "step" | "stylingMode" | "tabIndex" | "text" | "useLargeSpinButtons" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "visible" | "width">;
interface DxNumberBox extends AccessibleOptions {
    readonly instance?: NumberBox;
}
declare const DxNumberBox: any;
declare const DxButton: any;
declare const DxFormat: any;
declare const DxOptions: any;
export default DxNumberBox;
export { DxNumberBox, DxButton, DxFormat, DxOptions };
import type * as DxNumberBoxTypes from "devextreme/ui/number_box_types";
export { DxNumberBoxTypes };
