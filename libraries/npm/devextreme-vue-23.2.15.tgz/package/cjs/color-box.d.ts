/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import ColorBox, { Properties } from "devextreme/ui/color_box";
declare type AccessibleOptions = Pick<Properties, "acceptCustomValue" | "accessKey" | "activeStateEnabled" | "applyButtonText" | "applyValueMode" | "buttons" | "cancelButtonText" | "deferRendering" | "disabled" | "dropDownButtonTemplate" | "dropDownOptions" | "editAlphaChannel" | "elementAttr" | "fieldTemplate" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "keyStep" | "label" | "labelMode" | "name" | "onChange" | "onClosed" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOpened" | "onOptionChanged" | "onPaste" | "onValueChanged" | "opened" | "openOnFieldClick" | "placeholder" | "readOnly" | "rtlEnabled" | "showClearButton" | "showDropDownButton" | "stylingMode" | "tabIndex" | "text" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "width">;
interface DxColorBox extends AccessibleOptions {
    readonly instance?: ColorBox;
}
declare const DxColorBox: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxColorBox;
export { DxColorBox, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxColorBoxTypes from "devextreme/ui/color_box_types";
export { DxColorBoxTypes };
