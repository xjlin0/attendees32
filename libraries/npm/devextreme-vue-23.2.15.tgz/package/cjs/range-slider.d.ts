/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import RangeSlider, { Properties } from "devextreme/ui/range_slider";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "end" | "endName" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "keyStep" | "label" | "max" | "min" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "showRange" | "start" | "startName" | "step" | "tabIndex" | "tooltip" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeMode" | "visible" | "width">;
interface DxRangeSlider extends AccessibleOptions {
    readonly instance?: RangeSlider;
}
declare const DxRangeSlider: any;
declare const DxFormat: any;
declare const DxLabel: any;
declare const DxTooltip: any;
export default DxRangeSlider;
export { DxRangeSlider, DxFormat, DxLabel, DxTooltip };
import type * as DxRangeSliderTypes from "devextreme/ui/range_slider_types";
export { DxRangeSliderTypes };
