/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/gallery";
import Gallery, { Properties } from "devextreme/ui/gallery";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "animationDuration" | "animationEnabled" | "dataSource" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "indicatorEnabled" | "initialItemWidth" | "itemHoldTimeout" | "items" | "itemTemplate" | "loop" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "rtlEnabled" | "selectedIndex" | "selectedItem" | "showIndicator" | "showNavButtons" | "slideshowDelay" | "stretchImages" | "swipeEnabled" | "tabIndex" | "visible" | "width" | "wrapAround">;
interface DxGallery extends AccessibleOptions {
    readonly instance?: Gallery;
}
declare const DxGallery: any;
declare const DxItem: any;
export default DxGallery;
export { DxGallery, DxItem };
import type * as DxGalleryTypes from "devextreme/ui/gallery_types";
export { DxGalleryTypes };
