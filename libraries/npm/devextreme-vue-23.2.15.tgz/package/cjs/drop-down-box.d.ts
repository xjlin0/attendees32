/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import DropDownBox, { Properties } from "devextreme/ui/drop_down_box";
declare type AccessibleOptions = Pick<Properties, "acceptCustomValue" | "accessKey" | "activeStateEnabled" | "buttons" | "contentTemplate" | "dataSource" | "deferRendering" | "disabled" | "displayExpr" | "displayValueFormatter" | "dropDownButtonTemplate" | "dropDownOptions" | "elementAttr" | "fieldTemplate" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "items" | "label" | "labelMode" | "maxLength" | "name" | "onChange" | "onClosed" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOpened" | "onOptionChanged" | "onPaste" | "onValueChanged" | "opened" | "openOnFieldClick" | "placeholder" | "readOnly" | "rtlEnabled" | "showClearButton" | "showDropDownButton" | "stylingMode" | "tabIndex" | "text" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "valueExpr" | "visible" | "width">;
interface DxDropDownBox extends AccessibleOptions {
    readonly instance?: DropDownBox;
}
declare const DxDropDownBox: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxDropDownBox;
export { DxDropDownBox, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxDropDownBoxTypes from "devextreme/ui/drop_down_box_types";
export { DxDropDownBoxTypes };
