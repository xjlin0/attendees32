/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Scheduler, { Properties } from "devextreme/ui/scheduler";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "adaptivityEnabled" | "allDayExpr" | "allDayPanelMode" | "appointmentCollectorTemplate" | "appointmentDragging" | "appointmentTemplate" | "appointmentTooltipTemplate" | "cellDuration" | "crossScrollingEnabled" | "currentDate" | "currentView" | "customizeDateNavigatorText" | "dataCellTemplate" | "dataSource" | "dateCellTemplate" | "dateSerializationFormat" | "descriptionExpr" | "disabled" | "dropDownAppointmentTemplate" | "editing" | "elementAttr" | "endDateExpr" | "endDateTimeZoneExpr" | "endDayHour" | "firstDayOfWeek" | "focusStateEnabled" | "groupByDate" | "groups" | "height" | "hint" | "indicatorUpdateInterval" | "max" | "maxAppointmentsPerCell" | "min" | "noDataText" | "offset" | "onAppointmentAdded" | "onAppointmentAdding" | "onAppointmentClick" | "onAppointmentContextMenu" | "onAppointmentDblClick" | "onAppointmentDeleted" | "onAppointmentDeleting" | "onAppointmentFormOpening" | "onAppointmentRendered" | "onAppointmentTooltipShowing" | "onAppointmentUpdated" | "onAppointmentUpdating" | "onCellClick" | "onCellContextMenu" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "recurrenceEditMode" | "recurrenceExceptionExpr" | "recurrenceRuleExpr" | "remoteFiltering" | "resourceCellTemplate" | "resources" | "rtlEnabled" | "scrolling" | "selectedCellData" | "shadeUntilCurrentTime" | "showAllDayPanel" | "showCurrentTimeIndicator" | "startDateExpr" | "startDateTimeZoneExpr" | "startDayHour" | "tabIndex" | "textExpr" | "timeCellTemplate" | "timeZone" | "useDropDownViewSwitcher" | "views" | "visible" | "width">;
interface DxScheduler extends AccessibleOptions {
    readonly instance?: Scheduler;
}
declare const DxScheduler: any;
declare const DxAppointmentDragging: any;
declare const DxEditing: any;
declare const DxResource: any;
declare const DxScrolling: any;
declare const DxView: any;
export default DxScheduler;
export { DxScheduler, DxAppointmentDragging, DxEditing, DxResource, DxScrolling, DxView };
import type * as DxSchedulerTypes from "devextreme/ui/scheduler_types";
export { DxSchedulerTypes };
