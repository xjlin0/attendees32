/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import BarGauge, { Properties } from "devextreme/viz/bar_gauge";
declare type AccessibleOptions = Pick<Properties, "animation" | "backgroundColor" | "barSpacing" | "baseValue" | "centerTemplate" | "disabled" | "elementAttr" | "endValue" | "export" | "geometry" | "label" | "legend" | "loadingIndicator" | "margin" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onTooltipHidden" | "onTooltipShown" | "palette" | "paletteExtensionMode" | "pathModified" | "redrawOnResize" | "relativeInnerRadius" | "resolveLabelOverlapping" | "rtlEnabled" | "size" | "startValue" | "theme" | "title" | "tooltip" | "values">;
interface DxBarGauge extends AccessibleOptions {
    readonly instance?: BarGauge;
}
declare const DxBarGauge: any;
declare const DxAnimation: any;
declare const DxBarGaugeTitle: any;
declare const DxBarGaugeTitleSubtitle: any;
declare const DxBorder: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxGeometry: any;
declare const DxItemTextFormat: any;
declare const DxLabel: any;
declare const DxLegend: any;
declare const DxLegendBorder: any;
declare const DxLegendTitle: any;
declare const DxLegendTitleSubtitle: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSubtitle: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
export default DxBarGauge;
export { DxBarGauge, DxAnimation, DxBarGaugeTitle, DxBarGaugeTitleSubtitle, DxBorder, DxExport, DxFont, DxFormat, DxGeometry, DxItemTextFormat, DxLabel, DxLegend, DxLegendBorder, DxLegendTitle, DxLegendTitleSubtitle, DxLoadingIndicator, DxMargin, DxShadow, DxSize, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxBarGaugeTypes from "devextreme/viz/bar_gauge_types";
export { DxBarGaugeTypes };
