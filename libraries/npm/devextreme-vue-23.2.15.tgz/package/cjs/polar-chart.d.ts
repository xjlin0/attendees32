/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import PolarChart, { Properties } from "devextreme/viz/polar_chart";
declare type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "animation" | "annotations" | "argumentAxis" | "barGroupPadding" | "barGroupWidth" | "commonAnnotationSettings" | "commonAxisSettings" | "commonSeriesSettings" | "containerBackgroundColor" | "customizeAnnotation" | "customizeLabel" | "customizePoint" | "dataPrepareSettings" | "dataSource" | "disabled" | "elementAttr" | "export" | "legend" | "loadingIndicator" | "margin" | "negativesAsZeroes" | "onArgumentAxisClick" | "onDisposing" | "onDone" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onLegendClick" | "onOptionChanged" | "onPointClick" | "onPointHoverChanged" | "onPointSelectionChanged" | "onSeriesClick" | "onSeriesHoverChanged" | "onSeriesSelectionChanged" | "onTooltipHidden" | "onTooltipShown" | "onZoomEnd" | "onZoomStart" | "palette" | "paletteExtensionMode" | "pathModified" | "pointSelectionMode" | "redrawOnResize" | "resolveLabelOverlapping" | "rtlEnabled" | "series" | "seriesSelectionMode" | "seriesTemplate" | "size" | "theme" | "title" | "tooltip" | "useSpiderWeb" | "valueAxis">;
interface DxPolarChart extends AccessibleOptions {
    readonly instance?: PolarChart;
}
declare const DxPolarChart: any;
declare const DxAdaptiveLayout: any;
declare const DxAnimation: any;
declare const DxAnnotation: any;
declare const DxAnnotationBorder: any;
declare const DxArgumentAxis: any;
declare const DxArgumentAxisMinorTick: any;
declare const DxArgumentAxisTick: any;
declare const DxArgumentFormat: any;
declare const DxAxisLabel: any;
declare const DxBorder: any;
declare const DxColor: any;
declare const DxCommonAnnotationSettings: any;
declare const DxCommonAxisSettings: any;
declare const DxCommonAxisSettingsLabel: any;
declare const DxCommonAxisSettingsMinorTick: any;
declare const DxCommonAxisSettingsTick: any;
declare const DxCommonSeriesSettings: any;
declare const DxCommonSeriesSettingsHoverStyle: any;
declare const DxCommonSeriesSettingsLabel: any;
declare const DxCommonSeriesSettingsSelectionStyle: any;
declare const DxConnector: any;
declare const DxConstantLine: any;
declare const DxConstantLineLabel: any;
declare const DxConstantLineStyle: any;
declare const DxConstantLineStyleLabel: any;
declare const DxDataPrepareSettings: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxGrid: any;
declare const DxHatching: any;
declare const DxHoverStyle: any;
declare const DxImage: any;
declare const DxLabel: any;
declare const DxLegend: any;
declare const DxLegendTitle: any;
declare const DxLegendTitleSubtitle: any;
declare const DxLength: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxMinorGrid: any;
declare const DxMinorTick: any;
declare const DxMinorTickInterval: any;
declare const DxMinVisualRangeLength: any;
declare const DxPoint: any;
declare const DxPointBorder: any;
declare const DxPointHoverStyle: any;
declare const DxPointSelectionStyle: any;
declare const DxPolarChartTitle: any;
declare const DxPolarChartTitleSubtitle: any;
declare const DxSelectionStyle: any;
declare const DxSeries: any;
declare const DxSeriesBorder: any;
declare const DxSeriesTemplate: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxStrip: any;
declare const DxStripLabel: any;
declare const DxStripStyle: any;
declare const DxStripStyleLabel: any;
declare const DxSubtitle: any;
declare const DxTick: any;
declare const DxTickInterval: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
declare const DxValueAxis: any;
declare const DxValueErrorBar: any;
declare const DxVisualRange: any;
declare const DxWholeRange: any;
export default DxPolarChart;
export { DxPolarChart, DxAdaptiveLayout, DxAnimation, DxAnnotation, DxAnnotationBorder, DxArgumentAxis, DxArgumentAxisMinorTick, DxArgumentAxisTick, DxArgumentFormat, DxAxisLabel, DxBorder, DxColor, DxCommonAnnotationSettings, DxCommonAxisSettings, DxCommonAxisSettingsLabel, DxCommonAxisSettingsMinorTick, DxCommonAxisSettingsTick, DxCommonSeriesSettings, DxCommonSeriesSettingsHoverStyle, DxCommonSeriesSettingsLabel, DxCommonSeriesSettingsSelectionStyle, DxConnector, DxConstantLine, DxConstantLineLabel, DxConstantLineStyle, DxConstantLineStyleLabel, DxDataPrepareSettings, DxExport, DxFont, DxFormat, DxGrid, DxHatching, DxHoverStyle, DxImage, DxLabel, DxLegend, DxLegendTitle, DxLegendTitleSubtitle, DxLength, DxLoadingIndicator, DxMargin, DxMinorGrid, DxMinorTick, DxMinorTickInterval, DxMinVisualRangeLength, DxPoint, DxPointBorder, DxPointHoverStyle, DxPointSelectionStyle, DxPolarChartTitle, DxPolarChartTitleSubtitle, DxSelectionStyle, DxSeries, DxSeriesBorder, DxSeriesTemplate, DxShadow, DxSize, DxStrip, DxStripLabel, DxStripStyle, DxStripStyleLabel, DxSubtitle, DxTick, DxTickInterval, DxTitle, DxTooltip, DxTooltipBorder, DxValueAxis, DxValueErrorBar, DxVisualRange, DxWholeRange };
import type * as DxPolarChartTypes from "devextreme/viz/polar_chart_types";
export { DxPolarChartTypes };
