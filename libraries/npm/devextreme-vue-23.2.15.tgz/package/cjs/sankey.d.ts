/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Sankey, { Properties } from "devextreme/viz/sankey";
declare type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "alignment" | "dataSource" | "disabled" | "elementAttr" | "export" | "hoverEnabled" | "label" | "link" | "loadingIndicator" | "margin" | "node" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onLinkClick" | "onLinkHoverChanged" | "onNodeClick" | "onNodeHoverChanged" | "onOptionChanged" | "palette" | "paletteExtensionMode" | "pathModified" | "redrawOnResize" | "rtlEnabled" | "size" | "sortData" | "sourceField" | "targetField" | "theme" | "title" | "tooltip" | "weightField">;
interface DxSankey extends AccessibleOptions {
    readonly instance?: Sankey;
}
declare const DxSankey: any;
declare const DxAdaptiveLayout: any;
declare const DxBorder: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxHatching: any;
declare const DxHoverStyle: any;
declare const DxLabel: any;
declare const DxLink: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxNode: any;
declare const DxSankeyborder: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSubtitle: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
export default DxSankey;
export { DxSankey, DxAdaptiveLayout, DxBorder, DxExport, DxFont, DxFormat, DxHatching, DxHoverStyle, DxLabel, DxLink, DxLoadingIndicator, DxMargin, DxNode, DxSankeyborder, DxShadow, DxSize, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxSankeyTypes from "devextreme/viz/sankey_types";
export { DxSankeyTypes };
