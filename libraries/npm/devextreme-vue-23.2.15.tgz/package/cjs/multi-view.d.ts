/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/multi_view";
import MultiView, { Properties } from "devextreme/ui/multi_view";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animationEnabled" | "dataSource" | "deferRendering" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "loop" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "rtlEnabled" | "selectedIndex" | "selectedItem" | "swipeEnabled" | "tabIndex" | "visible" | "width">;
interface DxMultiView extends AccessibleOptions {
    readonly instance?: MultiView;
}
declare const DxMultiView: any;
declare const DxItem: any;
export default DxMultiView;
export { DxMultiView, DxItem };
import type * as DxMultiViewTypes from "devextreme/ui/multi_view_types";
export { DxMultiViewTypes };
