/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import TreeMap, { Properties } from "devextreme/viz/tree_map";
declare type AccessibleOptions = Pick<Properties, "childrenField" | "colorField" | "colorizer" | "dataSource" | "disabled" | "elementAttr" | "export" | "group" | "hoverEnabled" | "idField" | "interactWithGroup" | "labelField" | "layoutAlgorithm" | "layoutDirection" | "loadingIndicator" | "maxDepth" | "onClick" | "onDisposing" | "onDrawn" | "onDrill" | "onExported" | "onExporting" | "onFileSaving" | "onHoverChanged" | "onIncidentOccurred" | "onInitialized" | "onNodesInitialized" | "onNodesRendering" | "onOptionChanged" | "onSelectionChanged" | "parentField" | "pathModified" | "redrawOnResize" | "rtlEnabled" | "selectionMode" | "size" | "theme" | "tile" | "title" | "tooltip" | "valueField">;
interface DxTreeMap extends AccessibleOptions {
    readonly instance?: TreeMap;
}
declare const DxTreeMap: any;
declare const DxBorder: any;
declare const DxColorizer: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxGroup: any;
declare const DxGroupLabel: any;
declare const DxHoverStyle: any;
declare const DxLabel: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxSelectionStyle: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSubtitle: any;
declare const DxTile: any;
declare const DxTileLabel: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
declare const DxTreeMapborder: any;
export default DxTreeMap;
export { DxTreeMap, DxBorder, DxColorizer, DxExport, DxFont, DxFormat, DxGroup, DxGroupLabel, DxHoverStyle, DxLabel, DxLoadingIndicator, DxMargin, DxSelectionStyle, DxShadow, DxSize, DxSubtitle, DxTile, DxTileLabel, DxTitle, DxTooltip, DxTooltipBorder, DxTreeMapborder };
import type * as DxTreeMapTypes from "devextreme/viz/tree_map_types";
export { DxTreeMapTypes };
