/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import ButtonGroup, { Properties } from "devextreme/ui/button_group";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "buttonTemplate" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "items" | "keyExpr" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onOptionChanged" | "onSelectionChanged" | "rtlEnabled" | "selectedItemKeys" | "selectedItems" | "selectionMode" | "stylingMode" | "tabIndex" | "visible" | "width">;
interface DxButtonGroup extends AccessibleOptions {
    readonly instance?: ButtonGroup;
}
declare const DxButtonGroup: any;
declare const DxItem: any;
export default DxButtonGroup;
export { DxButtonGroup, DxItem };
import type * as DxButtonGroupTypes from "devextreme/ui/button_group_types";
export { DxButtonGroupTypes };
