/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Popup, { Properties } from "devextreme/ui/popup";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "animation" | "closeOnOutsideClick" | "container" | "contentTemplate" | "copyRootClassesToWrapper" | "deferRendering" | "disabled" | "dragAndResizeArea" | "dragEnabled" | "dragOutsideBoundary" | "elementAttr" | "enableBodyScroll" | "focusStateEnabled" | "fullScreen" | "height" | "hideOnOutsideClick" | "hideOnParentScroll" | "hint" | "hoverStateEnabled" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onOptionChanged" | "onResize" | "onResizeEnd" | "onResizeStart" | "onShowing" | "onShown" | "onTitleRendered" | "position" | "resizeEnabled" | "restorePosition" | "rtlEnabled" | "shading" | "shadingColor" | "showCloseButton" | "showTitle" | "tabIndex" | "title" | "titleTemplate" | "toolbarItems" | "visible" | "width" | "wrapperAttr">;
interface DxPopup extends AccessibleOptions {
    readonly instance?: Popup;
}
declare const DxPopup: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxPopup;
export { DxPopup, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxHide, DxMy, DxOffset, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxPopupTypes from "devextreme/ui/popup_types";
export { DxPopupTypes };
