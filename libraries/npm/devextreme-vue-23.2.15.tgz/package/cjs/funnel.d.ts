/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Funnel, { Properties } from "devextreme/viz/funnel";
declare type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "algorithm" | "argumentField" | "colorField" | "dataSource" | "disabled" | "elementAttr" | "export" | "hoverEnabled" | "inverted" | "item" | "label" | "legend" | "loadingIndicator" | "margin" | "neckHeight" | "neckWidth" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onHoverChanged" | "onIncidentOccurred" | "onInitialized" | "onItemClick" | "onLegendClick" | "onOptionChanged" | "onSelectionChanged" | "palette" | "paletteExtensionMode" | "pathModified" | "redrawOnResize" | "resolveLabelOverlapping" | "rtlEnabled" | "selectionMode" | "size" | "sortData" | "theme" | "title" | "tooltip" | "valueField">;
interface DxFunnel extends AccessibleOptions {
    readonly instance?: Funnel;
}
declare const DxFunnel: any;
declare const DxAdaptiveLayout: any;
declare const DxBorder: any;
declare const DxConnector: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxFunnelTitle: any;
declare const DxFunnelTitleSubtitle: any;
declare const DxHatching: any;
declare const DxHoverStyle: any;
declare const DxItem: any;
declare const DxItemBorder: any;
declare const DxLabel: any;
declare const DxLabelBorder: any;
declare const DxLegend: any;
declare const DxLegendBorder: any;
declare const DxLegendTitle: any;
declare const DxLegendTitleSubtitle: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxSelectionStyle: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSubtitle: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
export default DxFunnel;
export { DxFunnel, DxAdaptiveLayout, DxBorder, DxConnector, DxExport, DxFont, DxFormat, DxFunnelTitle, DxFunnelTitleSubtitle, DxHatching, DxHoverStyle, DxItem, DxItemBorder, DxLabel, DxLabelBorder, DxLegend, DxLegendBorder, DxLegendTitle, DxLegendTitleSubtitle, DxLoadingIndicator, DxMargin, DxSelectionStyle, DxShadow, DxSize, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxFunnelTypes from "devextreme/viz/funnel_types";
export { DxFunnelTypes };
