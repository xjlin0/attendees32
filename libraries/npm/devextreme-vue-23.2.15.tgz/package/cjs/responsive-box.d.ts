/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/responsive_box";
import ResponsiveBox, { Properties } from "devextreme/ui/responsive_box";
declare type AccessibleOptions = Pick<Properties, "cols" | "dataSource" | "disabled" | "elementAttr" | "height" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rows" | "rtlEnabled" | "screenByWidth" | "singleColumnScreen" | "visible" | "width">;
interface DxResponsiveBox extends AccessibleOptions {
    readonly instance?: ResponsiveBox;
}
declare const DxResponsiveBox: any;
declare const DxCol: any;
declare const DxItem: any;
declare const DxLocation: any;
declare const DxRow: any;
export default DxResponsiveBox;
export { DxResponsiveBox, DxCol, DxItem, DxLocation, DxRow };
import type * as DxResponsiveBoxTypes from "devextreme/ui/responsive_box_types";
export { DxResponsiveBoxTypes };
