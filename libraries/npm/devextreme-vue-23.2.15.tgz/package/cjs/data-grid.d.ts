/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/data_grid";
import DataGrid, { Properties } from "devextreme/ui/data_grid";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowColumnReordering" | "allowColumnResizing" | "autoNavigateToFocusedRow" | "cacheEnabled" | "cellHintEnabled" | "columnAutoWidth" | "columnChooser" | "columnFixing" | "columnHidingEnabled" | "columnMinWidth" | "columnResizingMode" | "columns" | "columnWidth" | "customizeColumns" | "dataRowTemplate" | "dataSource" | "dateSerializationFormat" | "disabled" | "editing" | "elementAttr" | "errorRowEnabled" | "export" | "filterBuilder" | "filterBuilderPopup" | "filterPanel" | "filterRow" | "filterSyncEnabled" | "filterValue" | "focusedColumnIndex" | "focusedRowEnabled" | "focusedRowIndex" | "focusedRowKey" | "grouping" | "groupPanel" | "headerFilter" | "height" | "highlightChanges" | "hint" | "hoverStateEnabled" | "keyboardNavigation" | "keyExpr" | "loadPanel" | "masterDetail" | "noDataText" | "onAdaptiveDetailRowPreparing" | "onCellClick" | "onCellDblClick" | "onCellHoverChanged" | "onCellPrepared" | "onContentReady" | "onContextMenuPreparing" | "onDataErrorOccurred" | "onDisposing" | "onEditCanceled" | "onEditCanceling" | "onEditingStart" | "onEditorPrepared" | "onEditorPreparing" | "onExporting" | "onFocusedCellChanged" | "onFocusedCellChanging" | "onFocusedRowChanged" | "onFocusedRowChanging" | "onInitialized" | "onInitNewRow" | "onKeyDown" | "onOptionChanged" | "onRowClick" | "onRowCollapsed" | "onRowCollapsing" | "onRowDblClick" | "onRowExpanded" | "onRowExpanding" | "onRowInserted" | "onRowInserting" | "onRowPrepared" | "onRowRemoved" | "onRowRemoving" | "onRowUpdated" | "onRowUpdating" | "onRowValidating" | "onSaved" | "onSaving" | "onSelectionChanged" | "onToolbarPreparing" | "pager" | "paging" | "remoteOperations" | "renderAsync" | "repaintChangesOnly" | "rowAlternationEnabled" | "rowDragging" | "rowTemplate" | "rtlEnabled" | "scrolling" | "searchPanel" | "selectedRowKeys" | "selection" | "selectionFilter" | "showBorders" | "showColumnHeaders" | "showColumnLines" | "showRowLines" | "sortByGroupSummaryInfo" | "sorting" | "stateStoring" | "summary" | "syncLookupFilterValues" | "tabIndex" | "toolbar" | "twoWayBindingEnabled" | "visible" | "width" | "wordWrapEnabled">;
interface DxDataGrid extends AccessibleOptions {
    readonly instance?: DataGrid;
}
declare const DxDataGrid: any;
declare const DxAnimation: any;
declare const DxAsyncRule: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxChange: any;
declare const DxColCountByScreen: any;
declare const DxCollision: any;
declare const DxColumn: any;
declare const DxColumnChooser: any;
declare const DxColumnChooserSearch: any;
declare const DxColumnChooserSelection: any;
declare const DxColumnFixing: any;
declare const DxColumnFixingTexts: any;
declare const DxColumnHeaderFilter: any;
declare const DxColumnHeaderFilterSearch: any;
declare const DxColumnLookup: any;
declare const DxCompareRule: any;
declare const DxCursorOffset: any;
declare const DxCustomOperation: any;
declare const DxCustomRule: any;
declare const DxDataGridHeaderFilter: any;
declare const DxDataGridHeaderFilterSearch: any;
declare const DxDataGridHeaderFilterTexts: any;
declare const DxDataGridSelection: any;
declare const DxEditing: any;
declare const DxEditingTexts: any;
declare const DxEmailRule: any;
declare const DxExport: any;
declare const DxExportTexts: any;
declare const DxField: any;
declare const DxFieldLookup: any;
declare const DxFilterBuilder: any;
declare const DxFilterBuilderPopup: any;
declare const DxFilterOperationDescriptions: any;
declare const DxFilterPanel: any;
declare const DxFilterPanelTexts: any;
declare const DxFilterRow: any;
declare const DxForm: any;
declare const DxFormat: any;
declare const DxFormItem: any;
declare const DxFrom: any;
declare const DxGrouping: any;
declare const DxGroupingTexts: any;
declare const DxGroupItem: any;
declare const DxGroupOperationDescriptions: any;
declare const DxGroupPanel: any;
declare const DxHeaderFilter: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxKeyboardNavigation: any;
declare const DxLabel: any;
declare const DxLoadPanel: any;
declare const DxLookup: any;
declare const DxMasterDetail: any;
declare const DxMy: any;
declare const DxNumericRule: any;
declare const DxOffset: any;
declare const DxOperationDescriptions: any;
declare const DxPager: any;
declare const DxPaging: any;
declare const DxPatternRule: any;
declare const DxPopup: any;
declare const DxPosition: any;
declare const DxRangeRule: any;
declare const DxRemoteOperations: any;
declare const DxRequiredRule: any;
declare const DxRowDragging: any;
declare const DxScrolling: any;
declare const DxSearch: any;
declare const DxSearchPanel: any;
declare const DxSelection: any;
declare const DxShow: any;
declare const DxSortByGroupSummaryInfo: any;
declare const DxSorting: any;
declare const DxStateStoring: any;
declare const DxStringLengthRule: any;
declare const DxSummary: any;
declare const DxSummaryTexts: any;
declare const DxTexts: any;
declare const DxTo: any;
declare const DxToolbar: any;
declare const DxToolbarItem: any;
declare const DxTotalItem: any;
declare const DxValidationRule: any;
declare const DxValueFormat: any;
export default DxDataGrid;
export { DxDataGrid, DxAnimation, DxAsyncRule, DxAt, DxBoundaryOffset, DxButton, DxChange, DxColCountByScreen, DxCollision, DxColumn, DxColumnChooser, DxColumnChooserSearch, DxColumnChooserSelection, DxColumnFixing, DxColumnFixingTexts, DxColumnHeaderFilter, DxColumnHeaderFilterSearch, DxColumnLookup, DxCompareRule, DxCursorOffset, DxCustomOperation, DxCustomRule, DxDataGridHeaderFilter, DxDataGridHeaderFilterSearch, DxDataGridHeaderFilterTexts, DxDataGridSelection, DxEditing, DxEditingTexts, DxEmailRule, DxExport, DxExportTexts, DxField, DxFieldLookup, DxFilterBuilder, DxFilterBuilderPopup, DxFilterOperationDescriptions, DxFilterPanel, DxFilterPanelTexts, DxFilterRow, DxForm, DxFormat, DxFormItem, DxFrom, DxGrouping, DxGroupingTexts, DxGroupItem, DxGroupOperationDescriptions, DxGroupPanel, DxHeaderFilter, DxHide, DxItem, DxKeyboardNavigation, DxLabel, DxLoadPanel, DxLookup, DxMasterDetail, DxMy, DxNumericRule, DxOffset, DxOperationDescriptions, DxPager, DxPaging, DxPatternRule, DxPopup, DxPosition, DxRangeRule, DxRemoteOperations, DxRequiredRule, DxRowDragging, DxScrolling, DxSearch, DxSearchPanel, DxSelection, DxShow, DxSortByGroupSummaryInfo, DxSorting, DxStateStoring, DxStringLengthRule, DxSummary, DxSummaryTexts, DxTexts, DxTo, DxToolbar, DxToolbarItem, DxTotalItem, DxValidationRule, DxValueFormat };
import type * as DxDataGridTypes from "devextreme/ui/data_grid_types";
export { DxDataGridTypes };
