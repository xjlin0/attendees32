/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Button, { Properties } from "devextreme/ui/button";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "icon" | "onClick" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "stylingMode" | "tabIndex" | "template" | "text" | "type" | "useSubmitBehavior" | "validationGroup" | "visible" | "width">;
interface DxButton extends AccessibleOptions {
    readonly instance?: Button;
}
declare const DxButton: any;
export default DxButton;
export { DxButton };
import type * as DxButtonTypes from "devextreme/ui/button_types";
export { DxButtonTypes };
