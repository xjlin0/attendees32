/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/validation_summary";
import ValidationSummary, { Properties } from "devextreme/ui/validation_summary";
declare type AccessibleOptions = Pick<Properties, "elementAttr" | "hoverStateEnabled" | "items" | "itemTemplate" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onOptionChanged" | "validationGroup">;
interface DxValidationSummary extends AccessibleOptions {
    readonly instance?: ValidationSummary;
}
declare const DxValidationSummary: any;
declare const DxItem: any;
export default DxValidationSummary;
export { DxValidationSummary, DxItem };
import type * as DxValidationSummaryTypes from "devextreme/ui/validation_summary_types";
export { DxValidationSummaryTypes };
