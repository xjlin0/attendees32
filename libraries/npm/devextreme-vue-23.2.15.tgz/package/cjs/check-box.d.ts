/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import CheckBox, { Properties } from "devextreme/ui/check_box";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "enableThreeStateBehavior" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "iconSize" | "isDirty" | "isValid" | "name" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "tabIndex" | "text" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "width">;
interface DxCheckBox extends AccessibleOptions {
    readonly instance?: CheckBox;
}
declare const DxCheckBox: any;
export default DxCheckBox;
export { DxCheckBox };
import type * as DxCheckBoxTypes from "devextreme/ui/check_box_types";
export { DxCheckBoxTypes };
