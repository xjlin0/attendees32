/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/tabs";
import Tabs, { Properties } from "devextreme/ui/tabs";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "dataSource" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "iconPosition" | "itemHoldTimeout" | "items" | "itemTemplate" | "keyExpr" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "orientation" | "repaintChangesOnly" | "rtlEnabled" | "scrollByContent" | "scrollingEnabled" | "selectedIndex" | "selectedItem" | "selectedItemKeys" | "selectedItems" | "selectionMode" | "showNavButtons" | "stylingMode" | "tabIndex" | "visible" | "width">;
interface DxTabs extends AccessibleOptions {
    readonly instance?: Tabs;
}
declare const DxTabs: any;
declare const DxItem: any;
export default DxTabs;
export { DxTabs, DxItem };
import type * as DxTabsTypes from "devextreme/ui/tabs_types";
export { DxTabsTypes };
