/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Diagram, { Properties } from "devextreme/ui/diagram";
declare type AccessibleOptions = Pick<Properties, "autoZoomMode" | "contextMenu" | "contextToolbox" | "customShapes" | "customShapeTemplate" | "customShapeToolboxTemplate" | "defaultItemProperties" | "disabled" | "edges" | "editing" | "elementAttr" | "export" | "fullScreen" | "gridSize" | "hasChanges" | "height" | "historyToolbar" | "mainToolbar" | "nodes" | "onContentReady" | "onCustomCommand" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemDblClick" | "onOptionChanged" | "onRequestEditOperation" | "onRequestLayoutUpdate" | "onSelectionChanged" | "pageColor" | "pageOrientation" | "pageSize" | "propertiesPanel" | "readOnly" | "rtlEnabled" | "showGrid" | "simpleView" | "snapToGrid" | "toolbox" | "units" | "useNativeScrolling" | "viewToolbar" | "viewUnits" | "visible" | "width" | "zoomLevel">;
interface DxDiagram extends AccessibleOptions {
    readonly instance?: Diagram;
}
declare const DxDiagram: any;
declare const DxAutoLayout: any;
declare const DxCommand: any;
declare const DxCommandItem: any;
declare const DxConnectionPoint: any;
declare const DxContextMenu: any;
declare const DxContextToolbox: any;
declare const DxCustomShape: any;
declare const DxDefaultItemProperties: any;
declare const DxEdges: any;
declare const DxEditing: any;
declare const DxExport: any;
declare const DxGridSize: any;
declare const DxGroup: any;
declare const DxHistoryToolbar: any;
declare const DxItem: any;
declare const DxMainToolbar: any;
declare const DxNodes: any;
declare const DxPageSize: any;
declare const DxPageSizeItem: any;
declare const DxPropertiesPanel: any;
declare const DxTab: any;
declare const DxTabGroup: any;
declare const DxToolbox: any;
declare const DxToolboxGroup: any;
declare const DxViewToolbar: any;
declare const DxZoomLevel: any;
export default DxDiagram;
export { DxDiagram, DxAutoLayout, DxCommand, DxCommandItem, DxConnectionPoint, DxContextMenu, DxContextToolbox, DxCustomShape, DxDefaultItemProperties, DxEdges, DxEditing, DxExport, DxGridSize, DxGroup, DxHistoryToolbar, DxItem, DxMainToolbar, DxNodes, DxPageSize, DxPageSizeItem, DxPropertiesPanel, DxTab, DxTabGroup, DxToolbox, DxToolboxGroup, DxViewToolbar, DxZoomLevel };
import type * as DxDiagramTypes from "devextreme/ui/diagram_types";
export { DxDiagramTypes };
