/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import FilterBuilder, { Properties } from "devextreme/ui/filter_builder";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowHierarchicalFields" | "customOperations" | "disabled" | "elementAttr" | "fields" | "filterOperationDescriptions" | "focusStateEnabled" | "groupOperationDescriptions" | "groupOperations" | "height" | "hint" | "hoverStateEnabled" | "maxGroupLevel" | "onContentReady" | "onDisposing" | "onEditorPrepared" | "onEditorPreparing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "rtlEnabled" | "tabIndex" | "value" | "visible" | "width">;
interface DxFilterBuilder extends AccessibleOptions {
    readonly instance?: FilterBuilder;
}
declare const DxFilterBuilder: any;
declare const DxCustomOperation: any;
declare const DxField: any;
declare const DxFilterOperationDescriptions: any;
declare const DxFormat: any;
declare const DxGroupOperationDescriptions: any;
declare const DxLookup: any;
export default DxFilterBuilder;
export { DxFilterBuilder, DxCustomOperation, DxField, DxFilterOperationDescriptions, DxFormat, DxGroupOperationDescriptions, DxLookup };
import type * as DxFilterBuilderTypes from "devextreme/ui/filter_builder_types";
export { DxFilterBuilderTypes };
