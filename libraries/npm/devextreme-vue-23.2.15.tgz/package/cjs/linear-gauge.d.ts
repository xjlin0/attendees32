/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import LinearGauge, { Properties } from "devextreme/viz/linear_gauge";
declare type AccessibleOptions = Pick<Properties, "animation" | "containerBackgroundColor" | "disabled" | "elementAttr" | "export" | "geometry" | "loadingIndicator" | "margin" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onTooltipHidden" | "onTooltipShown" | "pathModified" | "rangeContainer" | "redrawOnResize" | "rtlEnabled" | "scale" | "size" | "subvalueIndicator" | "subvalues" | "theme" | "title" | "tooltip" | "value" | "valueIndicator">;
interface DxLinearGauge extends AccessibleOptions {
    readonly instance?: LinearGauge;
}
declare const DxLinearGauge: any;
declare const DxAnimation: any;
declare const DxBackgroundColor: any;
declare const DxBorder: any;
declare const DxColor: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxGeometry: any;
declare const DxLabel: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxMinorTick: any;
declare const DxRange: any;
declare const DxRangeContainer: any;
declare const DxScale: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSubtitle: any;
declare const DxSubvalueIndicator: any;
declare const DxText: any;
declare const DxTick: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxValueIndicator: any;
declare const DxWidth: any;
export default DxLinearGauge;
export { DxLinearGauge, DxAnimation, DxBackgroundColor, DxBorder, DxColor, DxExport, DxFont, DxFormat, DxGeometry, DxLabel, DxLoadingIndicator, DxMargin, DxMinorTick, DxRange, DxRangeContainer, DxScale, DxShadow, DxSize, DxSubtitle, DxSubvalueIndicator, DxText, DxTick, DxTitle, DxTooltip, DxValueIndicator, DxWidth };
import type * as DxLinearGaugeTypes from "devextreme/viz/linear_gauge_types";
export { DxLinearGaugeTypes };
