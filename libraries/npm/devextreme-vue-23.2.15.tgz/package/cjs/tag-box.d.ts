/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import TagBox, { Properties } from "devextreme/ui/tag_box";
declare type AccessibleOptions = Pick<Properties, "acceptCustomValue" | "accessKey" | "activeStateEnabled" | "applyValueMode" | "buttons" | "customItemCreateEvent" | "dataSource" | "deferRendering" | "disabled" | "displayExpr" | "dropDownButtonTemplate" | "dropDownOptions" | "elementAttr" | "fieldTemplate" | "focusStateEnabled" | "grouped" | "groupTemplate" | "height" | "hideSelectedItems" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "items" | "itemTemplate" | "label" | "labelMode" | "maxDisplayedTags" | "maxFilterQueryLength" | "maxLength" | "minSearchLength" | "multiline" | "name" | "noDataText" | "onChange" | "onClosed" | "onContentReady" | "onCustomItemCreating" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onItemClick" | "onKeyDown" | "onKeyUp" | "onMultiTagPreparing" | "onOpened" | "onOptionChanged" | "onSelectAllValueChanged" | "onSelectionChanged" | "onValueChanged" | "opened" | "openOnFieldClick" | "placeholder" | "readOnly" | "rtlEnabled" | "searchEnabled" | "searchExpr" | "searchMode" | "searchTimeout" | "selectAllMode" | "selectAllText" | "selectedItems" | "showClearButton" | "showDataBeforeSearch" | "showDropDownButton" | "showMultiTagOnly" | "showSelectionControls" | "stylingMode" | "tabIndex" | "tagTemplate" | "text" | "useItemTextAsTitle" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "valueExpr" | "visible" | "width" | "wrapItemText">;
interface DxTagBox extends AccessibleOptions {
    readonly instance?: TagBox;
}
declare const DxTagBox: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxTagBox;
export { DxTagBox, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxTagBoxTypes from "devextreme/ui/tag_box_types";
export { DxTagBoxTypes };
