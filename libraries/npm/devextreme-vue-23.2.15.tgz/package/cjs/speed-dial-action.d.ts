/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import SpeedDialAction, { Properties } from "devextreme/ui/speed_dial_action";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "elementAttr" | "focusStateEnabled" | "hint" | "hoverStateEnabled" | "icon" | "index" | "label" | "onClick" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "tabIndex" | "visible">;
interface DxSpeedDialAction extends AccessibleOptions {
    readonly instance?: SpeedDialAction;
}
declare const DxSpeedDialAction: any;
export default DxSpeedDialAction;
export { DxSpeedDialAction };
import type * as DxSpeedDialActionTypes from "devextreme/ui/speed_dial_action_types";
export { DxSpeedDialActionTypes };
