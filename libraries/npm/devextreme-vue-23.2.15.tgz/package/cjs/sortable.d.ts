/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Sortable, { Properties } from "devextreme/ui/sortable";
declare type AccessibleOptions = Pick<Properties, "allowDropInsideItem" | "allowReordering" | "autoScroll" | "boundary" | "container" | "cursorOffset" | "data" | "dragDirection" | "dragTemplate" | "dropFeedbackMode" | "elementAttr" | "filter" | "group" | "handle" | "height" | "itemOrientation" | "moveItemOnDrop" | "onAdd" | "onDisposing" | "onDragChange" | "onDragEnd" | "onDragMove" | "onDragStart" | "onInitialized" | "onOptionChanged" | "onRemove" | "onReorder" | "rtlEnabled" | "scrollSensitivity" | "scrollSpeed" | "width">;
interface DxSortable extends AccessibleOptions {
    readonly instance?: Sortable;
}
declare const DxSortable: any;
declare const DxCursorOffset: any;
export default DxSortable;
export { DxSortable, DxCursorOffset };
import type * as DxSortableTypes from "devextreme/ui/sortable_types";
export { DxSortableTypes };
