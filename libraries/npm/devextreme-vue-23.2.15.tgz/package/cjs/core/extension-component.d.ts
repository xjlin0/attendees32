/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

interface IExtension {
    $_isExtension: boolean;
    $_attachTo: (element: any) => any;
}
interface IExtensionComponentNode {
    $_hasOwner: boolean;
}
declare function initDxExtensionComponent(): import("vue").DefineComponent<{}, {}, {}, {}, {
    attachTo(element: any): void;
}, import("vue").ComponentOptionsMixin, import("vue").DefineComponent<{}, {}, {
    eventBus: import("../../../devextreme/artifacts/npm/devextreme/core/utils/callbacks").Callback<any[], any>;
}, {}, {
    $_applyConfigurationChanges(): void;
    $_createWidget(element: any): void;
    $_getIntegrationOptions(): object;
    $_getWatchMethod(): (valueGetter: () => any, valueChangeCallback: (value: any) => void, options: {
        deep: boolean;
        skipImmediate: boolean;
    }) => any;
    $_getExtraIntegrationOptions(): object;
    $_processChildren(_children: import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[]): void;
    $_createEmitters(instance: any): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>;
export { initDxExtensionComponent, IExtension, IExtensionComponentNode, };
