/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export declare function getTemplatePropName(props: Record<string, unknown> | null, templateName: string): string;
export declare function uppercaseFirst(value: string): string;
export declare function lowercaseFirst(value: string): string;
export declare function camelize(value: string): string;
export declare function toComparable(value: any): any;
export declare function isEqual(value1: any, value2: any): boolean;
export declare function forEachChildNode(el: Node, callback: (child: ReturnType<Node['childNodes']['item']>) => void): void;
export declare function allKeysAreEqual(obj1: object, obj2: object): boolean;
export declare function getOptionValue(options: any, optionPath: any): any;
export declare function getOptionInfo(name: string): IOptionInfo | ICollectionOptionInfo;
interface IOptionInfo {
    isCollection: false;
    name: string;
    fullName: string;
}
interface ICollectionOptionInfo {
    isCollection: true;
    name: string;
    fullName: string;
    index: number;
}
export {};
