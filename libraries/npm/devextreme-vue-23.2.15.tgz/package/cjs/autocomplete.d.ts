/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Autocomplete, { Properties } from "devextreme/ui/autocomplete";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "buttons" | "dataSource" | "deferRendering" | "disabled" | "displayValue" | "dropDownButtonTemplate" | "dropDownOptions" | "elementAttr" | "focusStateEnabled" | "grouped" | "groupTemplate" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "items" | "itemTemplate" | "label" | "labelMode" | "maxItemCount" | "maxLength" | "minSearchLength" | "name" | "onChange" | "onClosed" | "onContentReady" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onItemClick" | "onKeyDown" | "onKeyUp" | "onOpened" | "onOptionChanged" | "onPaste" | "onSelectionChanged" | "onValueChanged" | "opened" | "openOnFieldClick" | "placeholder" | "readOnly" | "rtlEnabled" | "searchExpr" | "searchMode" | "searchTimeout" | "selectedItem" | "showClearButton" | "showDropDownButton" | "spellcheck" | "stylingMode" | "tabIndex" | "text" | "useItemTextAsTitle" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "valueExpr" | "visible" | "width" | "wrapItemText">;
interface DxAutocomplete extends AccessibleOptions {
    readonly instance?: Autocomplete;
}
declare const DxAutocomplete: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxAutocomplete;
export { DxAutocomplete, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxAutocompleteTypes from "devextreme/ui/autocomplete_types";
export { DxAutocompleteTypes };
