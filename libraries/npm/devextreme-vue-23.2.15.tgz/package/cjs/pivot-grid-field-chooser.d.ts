/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import PivotGridFieldChooser, { Properties } from "devextreme/ui/pivot_grid_field_chooser";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowSearch" | "applyChangesMode" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "focusStateEnabled" | "headerFilter" | "height" | "hint" | "hoverStateEnabled" | "layout" | "onContentReady" | "onContextMenuPreparing" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "searchTimeout" | "state" | "tabIndex" | "texts" | "visible" | "width">;
interface DxPivotGridFieldChooser extends AccessibleOptions {
    readonly instance?: PivotGridFieldChooser;
}
declare const DxPivotGridFieldChooser: any;
declare const DxHeaderFilter: any;
declare const DxHeaderFilterTexts: any;
declare const DxPivotGridFieldChooserTexts: any;
declare const DxSearch: any;
declare const DxTexts: any;
export default DxPivotGridFieldChooser;
export { DxPivotGridFieldChooser, DxHeaderFilter, DxHeaderFilterTexts, DxPivotGridFieldChooserTexts, DxSearch, DxTexts };
import type * as DxPivotGridFieldChooserTypes from "devextreme/ui/pivot_grid_field_chooser_types";
export { DxPivotGridFieldChooserTypes };
