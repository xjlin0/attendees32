/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Drawer, { Properties } from "devextreme/ui/drawer";
declare type AccessibleOptions = Pick<Properties, "activeStateEnabled" | "animationDuration" | "animationEnabled" | "closeOnOutsideClick" | "disabled" | "elementAttr" | "height" | "hint" | "hoverStateEnabled" | "maxSize" | "minSize" | "onDisposing" | "onInitialized" | "onOptionChanged" | "opened" | "openedStateMode" | "position" | "revealMode" | "rtlEnabled" | "shading" | "template" | "visible" | "width">;
interface DxDrawer extends AccessibleOptions {
    readonly instance?: Drawer;
}
declare const DxDrawer: any;
export default DxDrawer;
export { DxDrawer };
import type * as DxDrawerTypes from "devextreme/ui/drawer_types";
export { DxDrawerTypes };
