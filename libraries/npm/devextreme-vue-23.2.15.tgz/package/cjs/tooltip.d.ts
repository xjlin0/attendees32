/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Tooltip, { Properties } from "devextreme/ui/tooltip";
declare type AccessibleOptions = Pick<Properties, "animation" | "closeOnOutsideClick" | "container" | "contentTemplate" | "copyRootClassesToWrapper" | "deferRendering" | "disabled" | "elementAttr" | "height" | "hideEvent" | "hideOnOutsideClick" | "hideOnParentScroll" | "hint" | "hoverStateEnabled" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onOptionChanged" | "onShowing" | "onShown" | "position" | "rtlEnabled" | "shading" | "shadingColor" | "showEvent" | "target" | "visible" | "width" | "wrapperAttr">;
interface DxTooltip extends AccessibleOptions {
    readonly instance?: Tooltip;
}
declare const DxTooltip: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxHideEvent: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxShowEvent: any;
declare const DxTo: any;
export default DxTooltip;
export { DxTooltip, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxHide, DxHideEvent, DxMy, DxOffset, DxPosition, DxShow, DxShowEvent, DxTo };
import type * as DxTooltipTypes from "devextreme/ui/tooltip_types";
export { DxTooltipTypes };
