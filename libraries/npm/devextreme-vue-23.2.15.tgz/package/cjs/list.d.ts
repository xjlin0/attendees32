/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/list";
import List, { Properties } from "devextreme/ui/list";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowItemDeleting" | "bounceEnabled" | "collapsibleGroups" | "dataSource" | "disabled" | "displayExpr" | "elementAttr" | "focusStateEnabled" | "grouped" | "groupTemplate" | "height" | "hint" | "hoverStateEnabled" | "indicateLoading" | "itemDeleteMode" | "itemDragging" | "itemHoldTimeout" | "items" | "itemTemplate" | "keyExpr" | "menuItems" | "menuMode" | "nextButtonText" | "noDataText" | "onContentReady" | "onDisposing" | "onGroupRendered" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemDeleted" | "onItemDeleting" | "onItemHold" | "onItemRendered" | "onItemReordered" | "onItemSwipe" | "onOptionChanged" | "onPageLoading" | "onPullRefresh" | "onScroll" | "onSelectAllValueChanged" | "onSelectionChanged" | "pageLoadingText" | "pageLoadMode" | "pulledDownText" | "pullingDownText" | "pullRefreshEnabled" | "refreshingText" | "repaintChangesOnly" | "rtlEnabled" | "scrollByContent" | "scrollByThumb" | "scrollingEnabled" | "searchEditorOptions" | "searchEnabled" | "searchExpr" | "searchMode" | "searchTimeout" | "searchValue" | "selectAllMode" | "selectAllText" | "selectByClick" | "selectedItemKeys" | "selectedItems" | "selectionMode" | "showScrollbar" | "showSelectionControls" | "tabIndex" | "useNativeScrolling" | "visible" | "width">;
interface DxList extends AccessibleOptions {
    readonly instance?: List;
}
declare const DxList: any;
declare const DxButton: any;
declare const DxCursorOffset: any;
declare const DxItem: any;
declare const DxItemDragging: any;
declare const DxMenuItem: any;
declare const DxOptions: any;
declare const DxSearchEditorOptions: any;
export default DxList;
export { DxList, DxButton, DxCursorOffset, DxItem, DxItemDragging, DxMenuItem, DxOptions, DxSearchEditorOptions };
import type * as DxListTypes from "devextreme/ui/list_types";
export { DxListTypes };
