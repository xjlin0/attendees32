/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import FileUploader, { Properties } from "devextreme/ui/file_uploader";
declare type AccessibleOptions = Pick<Properties, "abortUpload" | "accept" | "accessKey" | "activeStateEnabled" | "allowCanceling" | "allowedFileExtensions" | "chunkSize" | "dialogTrigger" | "disabled" | "dropZone" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "invalidFileExtensionMessage" | "invalidMaxFileSizeMessage" | "invalidMinFileSizeMessage" | "isDirty" | "isValid" | "labelText" | "maxFileSize" | "minFileSize" | "multiple" | "name" | "onBeforeSend" | "onContentReady" | "onDisposing" | "onDropZoneEnter" | "onDropZoneLeave" | "onFilesUploaded" | "onInitialized" | "onOptionChanged" | "onProgress" | "onUploadAborted" | "onUploaded" | "onUploadError" | "onUploadStarted" | "onValueChanged" | "progress" | "readOnly" | "readyToUploadMessage" | "rtlEnabled" | "selectButtonText" | "showFileList" | "tabIndex" | "uploadAbortedMessage" | "uploadButtonText" | "uploadChunk" | "uploadCustomData" | "uploadedMessage" | "uploadFailedMessage" | "uploadFile" | "uploadHeaders" | "uploadMethod" | "uploadMode" | "uploadUrl" | "validationError" | "validationErrors" | "validationStatus" | "value" | "visible" | "width">;
interface DxFileUploader extends AccessibleOptions {
    readonly instance?: FileUploader;
}
declare const DxFileUploader: any;
export default DxFileUploader;
export { DxFileUploader };
import type * as DxFileUploaderTypes from "devextreme/ui/file_uploader_types";
export { DxFileUploaderTypes };
