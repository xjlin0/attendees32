/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/tree_view";
import TreeView, { Properties } from "devextreme/ui/tree_view";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animationEnabled" | "collapseIcon" | "createChildren" | "dataSource" | "dataStructure" | "disabled" | "disabledExpr" | "displayExpr" | "elementAttr" | "expandAllEnabled" | "expandedExpr" | "expandEvent" | "expandIcon" | "expandNodesRecursive" | "focusStateEnabled" | "hasItemsExpr" | "height" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemsExpr" | "itemTemplate" | "keyExpr" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemCollapsed" | "onItemContextMenu" | "onItemExpanded" | "onItemHold" | "onItemRendered" | "onItemSelectionChanged" | "onOptionChanged" | "onSelectAllValueChanged" | "onSelectionChanged" | "parentIdExpr" | "rootValue" | "rtlEnabled" | "scrollDirection" | "searchEditorOptions" | "searchEnabled" | "searchExpr" | "searchMode" | "searchTimeout" | "searchValue" | "selectAllText" | "selectByClick" | "selectedExpr" | "selectionMode" | "selectNodesRecursive" | "showCheckBoxesMode" | "tabIndex" | "useNativeScrolling" | "virtualModeEnabled" | "visible" | "width">;
interface DxTreeView extends AccessibleOptions {
    readonly instance?: TreeView;
}
declare const DxTreeView: any;
declare const DxButton: any;
declare const DxItem: any;
declare const DxOptions: any;
declare const DxSearchEditorOptions: any;
export default DxTreeView;
export { DxTreeView, DxButton, DxItem, DxOptions, DxSearchEditorOptions };
import type * as DxTreeViewTypes from "devextreme/ui/tree_view_types";
export { DxTreeViewTypes };
