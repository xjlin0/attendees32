/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Bullet, { Properties } from "devextreme/viz/bullet";
declare type AccessibleOptions = Pick<Properties, "color" | "disabled" | "elementAttr" | "endScaleValue" | "margin" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onTooltipHidden" | "onTooltipShown" | "pathModified" | "rtlEnabled" | "showTarget" | "showZeroLevel" | "size" | "startScaleValue" | "target" | "targetColor" | "targetWidth" | "theme" | "tooltip" | "value">;
interface DxBullet extends AccessibleOptions {
    readonly instance?: Bullet;
}
declare const DxBullet: any;
declare const DxBorder: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxMargin: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxTooltip: any;
export default DxBullet;
export { DxBullet, DxBorder, DxFont, DxFormat, DxMargin, DxShadow, DxSize, DxTooltip };
import type * as DxBulletTypes from "devextreme/viz/bullet_types";
export { DxBulletTypes };
