/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import ScrollView, { Properties } from "devextreme/ui/scroll_view";
declare type AccessibleOptions = Pick<Properties, "bounceEnabled" | "direction" | "disabled" | "elementAttr" | "height" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onPullDown" | "onReachBottom" | "onScroll" | "onUpdated" | "pulledDownText" | "pullingDownText" | "reachBottomText" | "refreshingText" | "rtlEnabled" | "scrollByContent" | "scrollByThumb" | "showScrollbar" | "useNative" | "width">;
interface DxScrollView extends AccessibleOptions {
    readonly instance?: ScrollView;
}
declare const DxScrollView: any;
export default DxScrollView;
export { DxScrollView };
import type * as DxScrollViewTypes from "devextreme/ui/scroll_view_types";
export { DxScrollViewTypes };
