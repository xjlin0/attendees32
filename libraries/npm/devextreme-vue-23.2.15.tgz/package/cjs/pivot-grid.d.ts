/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import PivotGrid, { Properties } from "devextreme/ui/pivot_grid";
declare type AccessibleOptions = Pick<Properties, "allowExpandAll" | "allowFiltering" | "allowSorting" | "allowSortingBySummary" | "dataFieldArea" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "fieldChooser" | "fieldPanel" | "headerFilter" | "height" | "hideEmptySummaryCells" | "hint" | "loadPanel" | "onCellClick" | "onCellPrepared" | "onContentReady" | "onContextMenuPreparing" | "onDisposing" | "onExporting" | "onInitialized" | "onOptionChanged" | "rowHeaderLayout" | "rtlEnabled" | "scrolling" | "showBorders" | "showColumnGrandTotals" | "showColumnTotals" | "showRowGrandTotals" | "showRowTotals" | "showTotalsPrior" | "stateStoring" | "tabIndex" | "texts" | "visible" | "width" | "wordWrapEnabled">;
interface DxPivotGrid extends AccessibleOptions {
    readonly instance?: PivotGrid;
}
declare const DxPivotGrid: any;
declare const DxExport: any;
declare const DxFieldChooser: any;
declare const DxFieldChooserTexts: any;
declare const DxFieldPanel: any;
declare const DxFieldPanelTexts: any;
declare const DxHeaderFilter: any;
declare const DxHeaderFilterTexts: any;
declare const DxLoadPanel: any;
declare const DxPivotGridTexts: any;
declare const DxScrolling: any;
declare const DxSearch: any;
declare const DxStateStoring: any;
declare const DxTexts: any;
export default DxPivotGrid;
export { DxPivotGrid, DxExport, DxFieldChooser, DxFieldChooserTexts, DxFieldPanel, DxFieldPanelTexts, DxHeaderFilter, DxHeaderFilterTexts, DxLoadPanel, DxPivotGridTexts, DxScrolling, DxSearch, DxStateStoring, DxTexts };
import type * as DxPivotGridTypes from "devextreme/ui/pivot_grid_types";
export { DxPivotGridTypes };
