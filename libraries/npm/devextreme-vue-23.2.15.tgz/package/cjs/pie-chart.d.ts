/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import PieChart, { Properties } from "devextreme/viz/pie_chart";
declare type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "animation" | "annotations" | "centerTemplate" | "commonAnnotationSettings" | "commonSeriesSettings" | "customizeAnnotation" | "customizeLabel" | "customizePoint" | "dataSource" | "diameter" | "disabled" | "elementAttr" | "export" | "innerRadius" | "legend" | "loadingIndicator" | "margin" | "minDiameter" | "onDisposing" | "onDone" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onLegendClick" | "onOptionChanged" | "onPointClick" | "onPointHoverChanged" | "onPointSelectionChanged" | "onTooltipHidden" | "onTooltipShown" | "palette" | "paletteExtensionMode" | "pathModified" | "pointSelectionMode" | "redrawOnResize" | "resolveLabelOverlapping" | "rtlEnabled" | "segmentsDirection" | "series" | "seriesTemplate" | "size" | "sizeGroup" | "startAngle" | "theme" | "title" | "tooltip" | "type">;
interface DxPieChart extends AccessibleOptions {
    readonly instance?: PieChart;
}
declare const DxPieChart: any;
declare const DxAdaptiveLayout: any;
declare const DxAnimation: any;
declare const DxAnnotation: any;
declare const DxAnnotationBorder: any;
declare const DxArgumentFormat: any;
declare const DxBorder: any;
declare const DxColor: any;
declare const DxCommonAnnotationSettings: any;
declare const DxCommonSeriesSettings: any;
declare const DxConnector: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxHatching: any;
declare const DxHoverStyle: any;
declare const DxImage: any;
declare const DxLabel: any;
declare const DxLegend: any;
declare const DxLegendTitle: any;
declare const DxLegendTitleSubtitle: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxPieChartTitle: any;
declare const DxPieChartTitleSubtitle: any;
declare const DxSelectionStyle: any;
declare const DxSeries: any;
declare const DxSeriesBorder: any;
declare const DxSeriesTemplate: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSmallValuesGrouping: any;
declare const DxSubtitle: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
export default DxPieChart;
export { DxPieChart, DxAdaptiveLayout, DxAnimation, DxAnnotation, DxAnnotationBorder, DxArgumentFormat, DxBorder, DxColor, DxCommonAnnotationSettings, DxCommonSeriesSettings, DxConnector, DxExport, DxFont, DxFormat, DxHatching, DxHoverStyle, DxImage, DxLabel, DxLegend, DxLegendTitle, DxLegendTitleSubtitle, DxLoadingIndicator, DxMargin, DxPieChartTitle, DxPieChartTitleSubtitle, DxSelectionStyle, DxSeries, DxSeriesBorder, DxSeriesTemplate, DxShadow, DxSize, DxSmallValuesGrouping, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxPieChartTypes from "devextreme/viz/pie_chart_types";
export { DxPieChartTypes };
