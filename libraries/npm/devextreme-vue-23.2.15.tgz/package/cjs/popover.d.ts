/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Popover, { Properties } from "devextreme/ui/popover";
declare type AccessibleOptions = Pick<Properties, "animation" | "closeOnOutsideClick" | "container" | "contentTemplate" | "copyRootClassesToWrapper" | "deferRendering" | "disabled" | "elementAttr" | "enableBodyScroll" | "height" | "hideEvent" | "hideOnOutsideClick" | "hideOnParentScroll" | "hint" | "hoverStateEnabled" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onOptionChanged" | "onShowing" | "onShown" | "onTitleRendered" | "position" | "rtlEnabled" | "shading" | "shadingColor" | "showCloseButton" | "showEvent" | "showTitle" | "target" | "title" | "titleTemplate" | "toolbarItems" | "visible" | "width" | "wrapperAttr">;
interface DxPopover extends AccessibleOptions {
    readonly instance?: Popover;
}
declare const DxPopover: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxHideEvent: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxShowEvent: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxPopover;
export { DxPopover, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxHide, DxHideEvent, DxMy, DxOffset, DxPosition, DxShow, DxShowEvent, DxTo, DxToolbarItem };
import type * as DxPopoverTypes from "devextreme/ui/popover_types";
export { DxPopoverTypes };
