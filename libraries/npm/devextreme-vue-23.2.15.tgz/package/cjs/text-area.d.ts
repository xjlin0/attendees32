/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import TextArea, { Properties } from "devextreme/ui/text_area";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "autoResizeEnabled" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "label" | "labelMode" | "maxHeight" | "maxLength" | "minHeight" | "name" | "onChange" | "onContentReady" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOptionChanged" | "onPaste" | "onValueChanged" | "placeholder" | "readOnly" | "rtlEnabled" | "spellcheck" | "stylingMode" | "tabIndex" | "text" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "visible" | "width">;
interface DxTextArea extends AccessibleOptions {
    readonly instance?: TextArea;
}
declare const DxTextArea: any;
export default DxTextArea;
export { DxTextArea };
import type * as DxTextAreaTypes from "devextreme/ui/text_area_types";
export { DxTextAreaTypes };
