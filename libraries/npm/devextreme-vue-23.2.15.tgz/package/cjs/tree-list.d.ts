/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/tree_list";
import TreeList, { Properties } from "devextreme/ui/tree_list";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowColumnReordering" | "allowColumnResizing" | "autoExpandAll" | "autoNavigateToFocusedRow" | "cacheEnabled" | "cellHintEnabled" | "columnAutoWidth" | "columnChooser" | "columnFixing" | "columnHidingEnabled" | "columnMinWidth" | "columnResizingMode" | "columns" | "columnWidth" | "customizeColumns" | "dataSource" | "dataStructure" | "dateSerializationFormat" | "disabled" | "editing" | "elementAttr" | "errorRowEnabled" | "expandedRowKeys" | "expandNodesOnFiltering" | "filterBuilder" | "filterBuilderPopup" | "filterMode" | "filterPanel" | "filterRow" | "filterSyncEnabled" | "filterValue" | "focusedColumnIndex" | "focusedRowEnabled" | "focusedRowIndex" | "focusedRowKey" | "hasItemsExpr" | "headerFilter" | "height" | "highlightChanges" | "hint" | "hoverStateEnabled" | "itemsExpr" | "keyboardNavigation" | "keyExpr" | "loadPanel" | "noDataText" | "onAdaptiveDetailRowPreparing" | "onCellClick" | "onCellDblClick" | "onCellHoverChanged" | "onCellPrepared" | "onContentReady" | "onContextMenuPreparing" | "onDataErrorOccurred" | "onDisposing" | "onEditCanceled" | "onEditCanceling" | "onEditingStart" | "onEditorPrepared" | "onEditorPreparing" | "onFocusedCellChanged" | "onFocusedCellChanging" | "onFocusedRowChanged" | "onFocusedRowChanging" | "onInitialized" | "onInitNewRow" | "onKeyDown" | "onNodesInitialized" | "onOptionChanged" | "onRowClick" | "onRowCollapsed" | "onRowCollapsing" | "onRowDblClick" | "onRowExpanded" | "onRowExpanding" | "onRowInserted" | "onRowInserting" | "onRowPrepared" | "onRowRemoved" | "onRowRemoving" | "onRowUpdated" | "onRowUpdating" | "onRowValidating" | "onSaved" | "onSaving" | "onSelectionChanged" | "onToolbarPreparing" | "pager" | "paging" | "parentIdExpr" | "remoteOperations" | "renderAsync" | "repaintChangesOnly" | "rootValue" | "rowAlternationEnabled" | "rowDragging" | "rtlEnabled" | "scrolling" | "searchPanel" | "selectedRowKeys" | "selection" | "showBorders" | "showColumnHeaders" | "showColumnLines" | "showRowLines" | "sorting" | "stateStoring" | "syncLookupFilterValues" | "tabIndex" | "toolbar" | "twoWayBindingEnabled" | "visible" | "width" | "wordWrapEnabled">;
interface DxTreeList extends AccessibleOptions {
    readonly instance?: TreeList;
}
declare const DxTreeList: any;
declare const DxAnimation: any;
declare const DxAsyncRule: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxChange: any;
declare const DxColCountByScreen: any;
declare const DxCollision: any;
declare const DxColumn: any;
declare const DxColumnChooser: any;
declare const DxColumnChooserSearch: any;
declare const DxColumnChooserSelection: any;
declare const DxColumnFixing: any;
declare const DxColumnFixingTexts: any;
declare const DxColumnHeaderFilter: any;
declare const DxColumnHeaderFilterSearch: any;
declare const DxColumnLookup: any;
declare const DxCompareRule: any;
declare const DxCursorOffset: any;
declare const DxCustomOperation: any;
declare const DxCustomRule: any;
declare const DxEditing: any;
declare const DxEditingTexts: any;
declare const DxEmailRule: any;
declare const DxField: any;
declare const DxFieldLookup: any;
declare const DxFilterBuilder: any;
declare const DxFilterBuilderPopup: any;
declare const DxFilterOperationDescriptions: any;
declare const DxFilterPanel: any;
declare const DxFilterPanelTexts: any;
declare const DxFilterRow: any;
declare const DxForm: any;
declare const DxFormat: any;
declare const DxFormItem: any;
declare const DxFrom: any;
declare const DxGroupOperationDescriptions: any;
declare const DxHeaderFilter: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxKeyboardNavigation: any;
declare const DxLabel: any;
declare const DxLoadPanel: any;
declare const DxLookup: any;
declare const DxMy: any;
declare const DxNumericRule: any;
declare const DxOffset: any;
declare const DxOperationDescriptions: any;
declare const DxPager: any;
declare const DxPaging: any;
declare const DxPatternRule: any;
declare const DxPopup: any;
declare const DxPosition: any;
declare const DxRangeRule: any;
declare const DxRemoteOperations: any;
declare const DxRequiredRule: any;
declare const DxRowDragging: any;
declare const DxScrolling: any;
declare const DxSearch: any;
declare const DxSearchPanel: any;
declare const DxSelection: any;
declare const DxShow: any;
declare const DxSorting: any;
declare const DxStateStoring: any;
declare const DxStringLengthRule: any;
declare const DxTexts: any;
declare const DxTo: any;
declare const DxToolbar: any;
declare const DxToolbarItem: any;
declare const DxTreeListHeaderFilter: any;
declare const DxTreeListHeaderFilterSearch: any;
declare const DxTreeListHeaderFilterTexts: any;
declare const DxTreeListSelection: any;
declare const DxValidationRule: any;
export default DxTreeList;
export { DxTreeList, DxAnimation, DxAsyncRule, DxAt, DxBoundaryOffset, DxButton, DxChange, DxColCountByScreen, DxCollision, DxColumn, DxColumnChooser, DxColumnChooserSearch, DxColumnChooserSelection, DxColumnFixing, DxColumnFixingTexts, DxColumnHeaderFilter, DxColumnHeaderFilterSearch, DxColumnLookup, DxCompareRule, DxCursorOffset, DxCustomOperation, DxCustomRule, DxEditing, DxEditingTexts, DxEmailRule, DxField, DxFieldLookup, DxFilterBuilder, DxFilterBuilderPopup, DxFilterOperationDescriptions, DxFilterPanel, DxFilterPanelTexts, DxFilterRow, DxForm, DxFormat, DxFormItem, DxFrom, DxGroupOperationDescriptions, DxHeaderFilter, DxHide, DxItem, DxKeyboardNavigation, DxLabel, DxLoadPanel, DxLookup, DxMy, DxNumericRule, DxOffset, DxOperationDescriptions, DxPager, DxPaging, DxPatternRule, DxPopup, DxPosition, DxRangeRule, DxRemoteOperations, DxRequiredRule, DxRowDragging, DxScrolling, DxSearch, DxSearchPanel, DxSelection, DxShow, DxSorting, DxStateStoring, DxStringLengthRule, DxTexts, DxTo, DxToolbar, DxToolbarItem, DxTreeListHeaderFilter, DxTreeListHeaderFilterSearch, DxTreeListHeaderFilterTexts, DxTreeListSelection, DxValidationRule };
import type * as DxTreeListTypes from "devextreme/ui/tree_list_types";
export { DxTreeListTypes };
