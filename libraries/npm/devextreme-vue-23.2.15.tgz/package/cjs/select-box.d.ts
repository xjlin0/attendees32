/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import SelectBox, { Properties } from "devextreme/ui/select_box";
declare type AccessibleOptions = Pick<Properties, "acceptCustomValue" | "accessKey" | "activeStateEnabled" | "buttons" | "customItemCreateEvent" | "dataSource" | "deferRendering" | "disabled" | "displayExpr" | "displayValue" | "dropDownButtonTemplate" | "dropDownOptions" | "elementAttr" | "fieldTemplate" | "focusStateEnabled" | "grouped" | "groupTemplate" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "items" | "itemTemplate" | "label" | "labelMode" | "maxLength" | "minSearchLength" | "name" | "noDataText" | "onChange" | "onClosed" | "onContentReady" | "onCopy" | "onCustomItemCreating" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onItemClick" | "onKeyDown" | "onKeyUp" | "onOpened" | "onOptionChanged" | "onPaste" | "onSelectionChanged" | "onValueChanged" | "opened" | "openOnFieldClick" | "placeholder" | "readOnly" | "rtlEnabled" | "searchEnabled" | "searchExpr" | "searchMode" | "searchTimeout" | "selectedItem" | "showClearButton" | "showDataBeforeSearch" | "showDropDownButton" | "showSelectionControls" | "spellcheck" | "stylingMode" | "tabIndex" | "text" | "useItemTextAsTitle" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "valueExpr" | "visible" | "width" | "wrapItemText">;
interface DxSelectBox extends AccessibleOptions {
    readonly instance?: SelectBox;
}
declare const DxSelectBox: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxSelectBox;
export { DxSelectBox, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxSelectBoxTypes from "devextreme/ui/select_box_types";
export { DxSelectBoxTypes };
