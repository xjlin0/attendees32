/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/action_sheet";
import ActionSheet, { Properties } from "devextreme/ui/action_sheet";
declare type AccessibleOptions = Pick<Properties, "cancelText" | "dataSource" | "disabled" | "elementAttr" | "height" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "onCancelClick" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rtlEnabled" | "showCancelButton" | "showTitle" | "target" | "title" | "usePopover" | "visible" | "width">;
interface DxActionSheet extends AccessibleOptions {
    readonly instance?: ActionSheet;
}
declare const DxActionSheet: any;
declare const DxItem: any;
export default DxActionSheet;
export { DxActionSheet, DxItem };
import type * as DxActionSheetTypes from "devextreme/ui/action_sheet_types";
export { DxActionSheetTypes };
