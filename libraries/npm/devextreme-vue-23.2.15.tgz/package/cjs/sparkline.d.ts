/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Sparkline, { Properties } from "devextreme/viz/sparkline";
declare type AccessibleOptions = Pick<Properties, "argumentField" | "barNegativeColor" | "barPositiveColor" | "dataSource" | "disabled" | "elementAttr" | "firstLastColor" | "ignoreEmptyPoints" | "lineColor" | "lineWidth" | "lossColor" | "margin" | "maxColor" | "maxValue" | "minColor" | "minValue" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onTooltipHidden" | "onTooltipShown" | "pathModified" | "pointColor" | "pointSize" | "pointSymbol" | "rtlEnabled" | "showFirstLast" | "showMinMax" | "size" | "theme" | "tooltip" | "type" | "valueField" | "winColor" | "winlossThreshold">;
interface DxSparkline extends AccessibleOptions {
    readonly instance?: Sparkline;
}
declare const DxSparkline: any;
declare const DxBorder: any;
declare const DxFont: any;
declare const DxFormat: any;
declare const DxMargin: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxTooltip: any;
export default DxSparkline;
export { DxSparkline, DxBorder, DxFont, DxFormat, DxMargin, DxShadow, DxSize, DxTooltip };
import type * as DxSparklineTypes from "devextreme/viz/sparkline_types";
export { DxSparklineTypes };
