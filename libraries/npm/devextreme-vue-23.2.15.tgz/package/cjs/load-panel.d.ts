/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import LoadPanel, { Properties } from "devextreme/ui/load_panel";
declare type AccessibleOptions = Pick<Properties, "animation" | "closeOnOutsideClick" | "container" | "copyRootClassesToWrapper" | "deferRendering" | "delay" | "elementAttr" | "focusStateEnabled" | "height" | "hideOnOutsideClick" | "hideOnParentScroll" | "hint" | "hoverStateEnabled" | "indicatorSrc" | "maxHeight" | "maxWidth" | "message" | "minHeight" | "minWidth" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onOptionChanged" | "onShowing" | "onShown" | "position" | "rtlEnabled" | "shading" | "shadingColor" | "showIndicator" | "showPane" | "visible" | "width" | "wrapperAttr">;
interface DxLoadPanel extends AccessibleOptions {
    readonly instance?: LoadPanel;
}
declare const DxLoadPanel: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
export default DxLoadPanel;
export { DxLoadPanel, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxHide, DxMy, DxOffset, DxPosition, DxShow, DxTo };
import type * as DxLoadPanelTypes from "devextreme/ui/load_panel_types";
export { DxLoadPanelTypes };
