/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/box";
import Box, { Properties } from "devextreme/ui/box";
declare type AccessibleOptions = Pick<Properties, "align" | "crossAlign" | "dataSource" | "direction" | "disabled" | "elementAttr" | "height" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rtlEnabled" | "visible" | "width">;
interface DxBox extends AccessibleOptions {
    readonly instance?: Box;
}
declare const DxBox: any;
declare const DxItem: any;
export default DxBox;
export { DxBox, DxItem };
import type * as DxBoxTypes from "devextreme/ui/box_types";
export { DxBoxTypes };
