/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import DateBox, { Properties } from "devextreme/ui/date_box";
declare type AccessibleOptions = Pick<Properties, "acceptCustomValue" | "accessKey" | "activeStateEnabled" | "adaptivityEnabled" | "applyButtonText" | "applyValueMode" | "buttons" | "calendarOptions" | "cancelButtonText" | "dateOutOfRangeMessage" | "dateSerializationFormat" | "deferRendering" | "disabled" | "disabledDates" | "displayFormat" | "dropDownButtonTemplate" | "dropDownOptions" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "interval" | "invalidDateMessage" | "isDirty" | "isValid" | "label" | "labelMode" | "max" | "maxLength" | "min" | "name" | "onChange" | "onClosed" | "onContentReady" | "onCopy" | "onCut" | "onDisposing" | "onEnterKey" | "onFocusIn" | "onFocusOut" | "onInitialized" | "onInput" | "onKeyDown" | "onKeyUp" | "onOpened" | "onOptionChanged" | "onPaste" | "onValueChanged" | "opened" | "openOnFieldClick" | "pickerType" | "placeholder" | "readOnly" | "rtlEnabled" | "showAnalogClock" | "showClearButton" | "showDropDownButton" | "spellcheck" | "stylingMode" | "tabIndex" | "text" | "todayButtonText" | "type" | "useMaskBehavior" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "visible" | "width">;
interface DxDateBox extends AccessibleOptions {
    readonly instance?: DateBox;
}
declare const DxDateBox: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxButton: any;
declare const DxCalendarOptions: any;
declare const DxCollision: any;
declare const DxDisplayFormat: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxOptions: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxDateBox;
export { DxDateBox, DxAnimation, DxAt, DxBoundaryOffset, DxButton, DxCalendarOptions, DxCollision, DxDisplayFormat, DxDropDownOptions, DxFrom, DxHide, DxMy, DxOffset, DxOptions, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxDateBoxTypes from "devextreme/ui/date_box_types";
export { DxDateBoxTypes };
