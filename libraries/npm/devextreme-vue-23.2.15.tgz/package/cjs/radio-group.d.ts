/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import RadioGroup, { Properties } from "devextreme/ui/radio_group";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "dataSource" | "disabled" | "displayExpr" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "items" | "itemTemplate" | "layout" | "name" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "tabIndex" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueExpr" | "visible" | "width">;
interface DxRadioGroup extends AccessibleOptions {
    readonly instance?: RadioGroup;
}
declare const DxRadioGroup: any;
declare const DxItem: any;
export default DxRadioGroup;
export { DxRadioGroup, DxItem };
import type * as DxRadioGroupTypes from "devextreme/ui/radio_group_types";
export { DxRadioGroupTypes };
