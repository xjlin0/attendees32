/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

export { ExplicitTypes } from "devextreme/ui/toolbar";
import Toolbar, { Properties } from "devextreme/ui/toolbar";
declare type AccessibleOptions = Pick<Properties, "dataSource" | "disabled" | "elementAttr" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "menuItemTemplate" | "multiline" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rtlEnabled" | "visible" | "width">;
interface DxToolbar extends AccessibleOptions {
    readonly instance?: Toolbar;
}
declare const DxToolbar: any;
declare const DxItem: any;
export default DxToolbar;
export { DxToolbar, DxItem };
import type * as DxToolbarTypes from "devextreme/ui/toolbar_types";
export { DxToolbarTypes };
