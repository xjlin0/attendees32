/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import DeferRendering, { Properties } from "devextreme/ui/defer_rendering";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animation" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onRendered" | "onShown" | "renderWhen" | "rtlEnabled" | "showLoadIndicator" | "staggerItemSelector" | "tabIndex" | "visible" | "width">;
interface DxDeferRendering extends AccessibleOptions {
    readonly instance?: DeferRendering;
}
declare const DxDeferRendering: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxFrom: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxTo: any;
export default DxDeferRendering;
export { DxDeferRendering, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxMy, DxOffset, DxPosition, DxTo };
import type * as DxDeferRenderingTypes from "devextreme/ui/defer_rendering_types";
export { DxDeferRenderingTypes };
