/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Form, { Properties } from "devextreme/ui/form";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "alignItemLabels" | "alignItemLabelsInAllGroups" | "colCount" | "colCountByScreen" | "customizeItem" | "disabled" | "elementAttr" | "focusStateEnabled" | "formData" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "items" | "labelLocation" | "labelMode" | "minColWidth" | "onContentReady" | "onDisposing" | "onEditorEnterKey" | "onFieldDataChanged" | "onInitialized" | "onOptionChanged" | "optionalMark" | "readOnly" | "requiredMark" | "requiredMessage" | "rtlEnabled" | "screenByWidth" | "scrollingEnabled" | "showColonAfterLabel" | "showOptionalMark" | "showRequiredMark" | "showValidationSummary" | "tabIndex" | "validationGroup" | "visible" | "width">;
interface DxForm extends AccessibleOptions {
    readonly instance?: Form;
}
declare const DxForm: any;
declare const DxAsyncRule: any;
declare const DxButtonItem: any;
declare const DxButtonOptions: any;
declare const DxColCountByScreen: any;
declare const DxCompareRule: any;
declare const DxCustomRule: any;
declare const DxEmailRule: any;
declare const DxEmptyItem: any;
declare const DxGroupItem: any;
declare const DxItem: any;
declare const DxLabel: any;
declare const DxNumericRule: any;
declare const DxPatternRule: any;
declare const DxRangeRule: any;
declare const DxRequiredRule: any;
declare const DxSimpleItem: any;
declare const DxStringLengthRule: any;
declare const DxTab: any;
declare const DxTabbedItem: any;
declare const DxTabPanelOptions: any;
declare const DxTabPanelOptionsItem: any;
declare const DxValidationRule: any;
export default DxForm;
export { DxForm, DxAsyncRule, DxButtonItem, DxButtonOptions, DxColCountByScreen, DxCompareRule, DxCustomRule, DxEmailRule, DxEmptyItem, DxGroupItem, DxItem, DxLabel, DxNumericRule, DxPatternRule, DxRangeRule, DxRequiredRule, DxSimpleItem, DxStringLengthRule, DxTab, DxTabbedItem, DxTabPanelOptions, DxTabPanelOptionsItem, DxValidationRule };
import type * as DxFormTypes from "devextreme/ui/form_types";
export { DxFormTypes };
