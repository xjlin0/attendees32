/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import VectorMap, { Properties } from "devextreme/viz/vector_map";
declare type AccessibleOptions = Pick<Properties, "annotations" | "background" | "bounds" | "center" | "commonAnnotationSettings" | "controlBar" | "customizeAnnotation" | "disabled" | "elementAttr" | "export" | "layers" | "legends" | "loadingIndicator" | "maxZoomFactor" | "onCenterChanged" | "onClick" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onSelectionChanged" | "onTooltipHidden" | "onTooltipShown" | "onZoomFactorChanged" | "panningEnabled" | "pathModified" | "projection" | "redrawOnResize" | "rtlEnabled" | "size" | "theme" | "title" | "tooltip" | "touchEnabled" | "wheelEnabled" | "zoomFactor" | "zoomingEnabled">;
interface DxVectorMap extends AccessibleOptions {
    readonly instance?: VectorMap;
}
declare const DxVectorMap: any;
declare const DxAnnotation: any;
declare const DxAnnotationBorder: any;
declare const DxBackground: any;
declare const DxBorder: any;
declare const DxCommonAnnotationSettings: any;
declare const DxControlBar: any;
declare const DxExport: any;
declare const DxFont: any;
declare const DxImage: any;
declare const DxLabel: any;
declare const DxLayer: any;
declare const DxLegend: any;
declare const DxLegendTitle: any;
declare const DxLegendTitleSubtitle: any;
declare const DxLoadingIndicator: any;
declare const DxMargin: any;
declare const DxProjection: any;
declare const DxShadow: any;
declare const DxSize: any;
declare const DxSource: any;
declare const DxSubtitle: any;
declare const DxTitle: any;
declare const DxTooltip: any;
declare const DxTooltipBorder: any;
declare const DxVectorMapTitle: any;
declare const DxVectorMapTitleSubtitle: any;
export default DxVectorMap;
export { DxVectorMap, DxAnnotation, DxAnnotationBorder, DxBackground, DxBorder, DxCommonAnnotationSettings, DxControlBar, DxExport, DxFont, DxImage, DxLabel, DxLayer, DxLegend, DxLegendTitle, DxLegendTitleSubtitle, DxLoadingIndicator, DxMargin, DxProjection, DxShadow, DxSize, DxSource, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder, DxVectorMapTitle, DxVectorMapTitleSubtitle };
import type * as DxVectorMapTypes from "devextreme/viz/vector_map_types";
export { DxVectorMapTypes };
