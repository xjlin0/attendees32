/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import ValidationGroup, { Properties } from "devextreme/ui/validation_group";
declare type AccessibleOptions = Pick<Properties, "elementAttr" | "height" | "onDisposing" | "onInitialized" | "onOptionChanged" | "width">;
interface DxValidationGroup extends AccessibleOptions {
    readonly instance?: ValidationGroup;
}
declare const DxValidationGroup: any;
export default DxValidationGroup;
export { DxValidationGroup };
import type * as DxValidationGroupTypes from "devextreme/ui/validation_group_types";
export { DxValidationGroupTypes };
