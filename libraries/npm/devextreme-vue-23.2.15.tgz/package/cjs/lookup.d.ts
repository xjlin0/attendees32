/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import Lookup, { Properties } from "devextreme/ui/lookup";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "applyButtonText" | "applyValueMode" | "cancelButtonText" | "cleanSearchOnOpening" | "clearButtonText" | "dataSource" | "deferRendering" | "disabled" | "displayExpr" | "displayValue" | "dropDownCentered" | "dropDownOptions" | "elementAttr" | "fieldTemplate" | "focusStateEnabled" | "fullScreen" | "grouped" | "groupTemplate" | "height" | "hint" | "hoverStateEnabled" | "inputAttr" | "isDirty" | "isValid" | "items" | "itemTemplate" | "label" | "labelMode" | "minSearchLength" | "name" | "nextButtonText" | "noDataText" | "onClosed" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onOpened" | "onOptionChanged" | "onPageLoading" | "onPullRefresh" | "onScroll" | "onSelectionChanged" | "onValueChanged" | "opened" | "pageLoadingText" | "pageLoadMode" | "placeholder" | "pulledDownText" | "pullingDownText" | "pullRefreshEnabled" | "refreshingText" | "rtlEnabled" | "searchEnabled" | "searchExpr" | "searchMode" | "searchPlaceholder" | "searchStartEvent" | "searchTimeout" | "selectedItem" | "showCancelButton" | "showClearButton" | "showDataBeforeSearch" | "stylingMode" | "tabIndex" | "text" | "useItemTextAsTitle" | "useNativeScrolling" | "usePopover" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeEvent" | "valueExpr" | "visible" | "width" | "wrapItemText">;
interface DxLookup extends AccessibleOptions {
    readonly instance?: Lookup;
}
declare const DxLookup: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxHideEvent: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxShowEvent: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxLookup;
export { DxLookup, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxHideEvent, DxItem, DxMy, DxOffset, DxPosition, DxShow, DxShowEvent, DxTo, DxToolbarItem };
import type * as DxLookupTypes from "devextreme/ui/lookup_types";
export { DxLookupTypes };
