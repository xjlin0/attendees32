/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import DropDownButton, { Properties } from "devextreme/ui/drop_down_button";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "dataSource" | "deferRendering" | "disabled" | "displayExpr" | "dropDownContentTemplate" | "dropDownOptions" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "icon" | "items" | "itemTemplate" | "keyExpr" | "noDataText" | "onButtonClick" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onOptionChanged" | "onSelectionChanged" | "opened" | "rtlEnabled" | "selectedItem" | "selectedItemKey" | "showArrowIcon" | "splitButton" | "stylingMode" | "tabIndex" | "text" | "type" | "useItemTextAsTitle" | "useSelectMode" | "visible" | "width" | "wrapItemText">;
interface DxDropDownButton extends AccessibleOptions {
    readonly instance?: DropDownButton;
}
declare const DxDropDownButton: any;
declare const DxAnimation: any;
declare const DxAt: any;
declare const DxBoundaryOffset: any;
declare const DxCollision: any;
declare const DxDropDownOptions: any;
declare const DxFrom: any;
declare const DxHide: any;
declare const DxItem: any;
declare const DxMy: any;
declare const DxOffset: any;
declare const DxPosition: any;
declare const DxShow: any;
declare const DxTo: any;
declare const DxToolbarItem: any;
export default DxDropDownButton;
export { DxDropDownButton, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxDropDownOptions, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxDropDownButtonTypes from "devextreme/ui/drop_down_button_types";
export { DxDropDownButtonTypes };
