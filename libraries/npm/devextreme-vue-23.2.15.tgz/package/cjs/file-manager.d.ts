/*!
 * devextreme-vue
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/devextreme-vue
 */

import FileManager, { Properties } from "devextreme/ui/file_manager";
declare type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowedFileExtensions" | "contextMenu" | "currentPath" | "currentPathKeys" | "customizeDetailColumns" | "customizeThumbnail" | "disabled" | "elementAttr" | "fileSystemProvider" | "focusedItemKey" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "itemView" | "notifications" | "onContentReady" | "onContextMenuItemClick" | "onContextMenuShowing" | "onCurrentDirectoryChanged" | "onDirectoryCreated" | "onDirectoryCreating" | "onDisposing" | "onErrorOccurred" | "onFileUploaded" | "onFileUploading" | "onFocusedItemChanged" | "onInitialized" | "onItemCopied" | "onItemCopying" | "onItemDeleted" | "onItemDeleting" | "onItemDownloading" | "onItemMoved" | "onItemMoving" | "onItemRenamed" | "onItemRenaming" | "onOptionChanged" | "onSelectedFileOpened" | "onSelectionChanged" | "onToolbarItemClick" | "permissions" | "rootFolderName" | "rtlEnabled" | "selectedItemKeys" | "selectionMode" | "tabIndex" | "toolbar" | "upload" | "visible" | "width">;
interface DxFileManager extends AccessibleOptions {
    readonly instance?: FileManager;
}
declare const DxFileManager: any;
declare const DxColumn: any;
declare const DxContextMenu: any;
declare const DxContextMenuItem: any;
declare const DxDetails: any;
declare const DxFileSelectionItem: any;
declare const DxItem: any;
declare const DxItemView: any;
declare const DxNotifications: any;
declare const DxPermissions: any;
declare const DxToolbar: any;
declare const DxToolbarItem: any;
declare const DxUpload: any;
export default DxFileManager;
export { DxFileManager, DxColumn, DxContextMenu, DxContextMenuItem, DxDetails, DxFileSelectionItem, DxItem, DxItemView, DxNotifications, DxPermissions, DxToolbar, DxToolbarItem, DxUpload };
import type * as DxFileManagerTypes from "devextreme/ui/file_manager_types";
export { DxFileManagerTypes };
