/**
* DevExtreme (core/config.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { GlobalConfig } from '../common';

export type FloatingActionButtonDirection = 'auto' | 'up' | 'down';

/**
 * Gets the current global configuration.
 */
declare function config(): GlobalConfig;

/**
                                                          * Configures your application before its launch.
                                                          */
                                                         declare function config(config: GlobalConfig): void;

/**
 * @deprecated Use GlobalConfig instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type globalConfig = GlobalConfig;

export default config;
