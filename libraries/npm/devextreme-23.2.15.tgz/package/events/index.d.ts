/**
* DevExtreme (events/index.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
    DxElement,
} from '../core/element';

/* eslint-disable @typescript-eslint/no-empty-interface */
/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface EventExtension { }
/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface EventType { }
/* eslint-enable @typescript-eslint/no-empty-interface */
/**
 * 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type DxEvent<TNativeEvent = Event> = {} extends EventType ? (EventObject & TNativeEvent) : EventType;

/**
 * Specifies arguments of `initialized` event.
 */
export interface InitializedEventInfo<TComponent> {
    /**
     * The UI component&apos;s instance.
     */
    readonly component?: TComponent;
    /**
     * The UI component&apos;s container.
     */
    readonly element?: DxElement;
}

/**
 * A type that contains fields common for all events (`component`, `element`, `model`).
 */
export interface EventInfo<TComponent> {
    /**
     * The UI component&apos;s instance.
     */
    readonly component: TComponent;
    /**
     * The UI component&apos;s container.
     */
    readonly element: DxElement;
    /**
     * Model data. Available only if you use Knockout.
     */
    readonly model?: any;
}

/**
 * A type that contains fields common for all events (`component`, `element`, `model`) and the `event` field.
 */
export interface NativeEventInfo<TComponent, TNativeEvent = Event> {
    /**
     * The UI component&apos;s instance.
     */
    readonly component: TComponent;
    /**
     * The UI component&apos;s container.
     */
    readonly element: DxElement;
    /**
     * Model data. Available only if you use Knockout.
     */
    readonly model?: any;
    /**
     * Specifies the executed event.
     */
    readonly event?: DxEvent<TNativeEvent>;
}

/**
 * Specifies arguments of `optionChanged` event.
 */
export interface ChangedOptionInfo {
    /**
     * The modified property if it belongs to the first level. Otherwise, the first-level property into which it is nested.
     */
    readonly name: string;
    /**
     * The path to the modified property that includes all parent properties.
     */
    readonly fullName: string;
    /**
     * The modified property&apos;s new value.
     */
    readonly value?: any;
    /**
     * The UI component&apos;s previous value.
     */
    readonly previousValue?: any;
}

/**
 * Specifies item information used in events related to a component&apos;s items.
 */
export interface ItemInfo<TItemData = any> {
    /**
     * The item&apos;s data.
     */
    readonly itemData?: TItemData;
    /**
     * The item&apos;s container.
     */
    readonly itemElement: DxElement;
    /**
     * The item&apos;s index.
     */
    readonly itemIndex: number;
}

/**
 * A type used in events. Specifies whether the event is cancelable.
 */
export interface Cancelable {
    /**
     * Specifies whether the event is cancelable.
     */
    cancel?: boolean;
}

/**
 * @deprecated EventObject
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type dxEvent = EventObject;

/**
 * Describes EventObject, a counterpart of the jQuery.Event to be used without jQuery.
 */
export type EventObject = {
    /**
     * The DOM element within the current event propagation stage.
     */
    currentTarget: Element;

    /**
     * Data passed to the event handler.
     */
    data: any;

    /**
     * The DOM element to which the currently-called event handler was attached.
     */
    delegateTarget: Element;

    /**
     * The DOM element that initiated the event.
     */
    target: Element;
    /**
     * Checks if the preventDefault() method was called on this event object.
     */
    isDefaultPrevented(): boolean;
    /**
     * Checks if the stopImmediatePropagation() method was called on this event object.
     */
    isImmediatePropagationStopped(): boolean;
    /**
     * Checks if the stopPropagation() method was called on this event object.
     */
    isPropagationStopped(): boolean;
    /**
     * Prevents the event&apos;s default action from triggering.
     */
    preventDefault(): void;
    /**
     * Stops the event&apos;s propagation up the DOM tree, preventing the rest of the handlers from being executed.
     */
    stopImmediatePropagation(): void;
    /**
     * Stops the event&apos;s propagation up the DOM tree, keeping parent handlers unnotified of the event.
     */
    stopPropagation(): void;
};

/**
 * 
 * @deprecated 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type event = DxEvent;

/**
 * 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export function eventsHandler(event: DxEvent, extraParameters: any): boolean;

/**
 * Detaches all handlers from the specified elements.
 */
export function off(element: Element | Array<Element>): void;

/**
 * Detaches all handlers of the specified event from the specified elements.
 */
export function off(element: Element | Array<Element>, eventName: string): void;

/**
 * Detaches an event handler from the specified elements.
 */
export function off(element: Element | Array<Element>, eventName: string, handler: Function): void;

/**
 * Detaches all event handlers of the specified type attached using the on(element, eventName, selector, data, handler) or on(element, eventName, selector, handler) method.
 */
export function off(element: Element | Array<Element>, eventName: string, selector: string): void;

/**
 * Detaches the specified event handler attached using the on(element, eventName, selector, data, handler) or on(element, eventName, selector, handler) method.
 */
export function off(element: Element | Array<Element>, eventName: string, selector: string, handler: Function): void;

/**
 * Attaches an event handler to the specified elements. Allows you to pass custom data to the handler.
 */
export function on(element: Element | Array<Element>, eventName: string, data: any, handler: Function): void;

/**
 * Attaches an event handler to the specified elements.
 */
export function on(element: Element | Array<Element>, eventName: string, handler: Function): void;

/**
 * Attaches an event handler to the specified elements&apos; descendants. Allows you to pass custom data to the handler.
 */
export function on(element: Element | Array<Element>, eventName: string, selector: string, data: any, handler: Function): void;

/**
 * Attaches an event handler to the specified elements&apos; descendants.
 */
export function on(element: Element | Array<Element>, eventName: string, selector: string, handler: Function): void;

/**
 * Attaches an event handler that is executed only once to the specified elements. Allows you to pass custom data to the handler.
 */
export function one(element: Element | Array<Element>, eventName: string, data: any, handler: Function): void;

/**
 * Attaches an event handler that is executed only once to the specified elements.
 */
export function one(element: Element | Array<Element>, eventName: string, handler: Function): void;

/**
 * Attaches an event handler that is executed only once to the specified elements&apos; descendants. Allows you to pass custom data to the handler.
 */
export function one(element: Element | Array<Element>, eventName: string, selector: string, data: any, handler: Function): void;

/**
 * Attaches an event handler that is executed only once to the specified elements&apos; descendants.
 */
export function one(element: Element | Array<Element>, eventName: string, selector: string, handler: Function): void;

/**
 * Triggers an event for the specified elements.
 */
export function trigger(element: Element | Array<Element>, event: string | DxEvent): void;

/**
 * Triggers an event for the specified elements. Allows you to pass custom parameters to event handlers.
 */
export function trigger(element: Element | Array<Element>, event: string | DxEvent, extraParameters: any): void;

/**
 * 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export function triggerHandler(element: Element | Array<Element>, event: string | DxEvent): void;

/**
 * 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export function triggerHandler(element: Element | Array<Element>, event: string | DxEvent, extraParameters: any): void;
