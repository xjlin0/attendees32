/**
* DevExtreme (viz/linear_gauge_types.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  HorizontalAlignment,
  Orientation,
  VerticalAlignment,
  DisposingEvent,
  DrawnEvent,
  ExportedEvent,
  ExportingEvent,
  FileSavingEvent,
  IncidentOccurredEvent,
  InitializedEvent,
  OptionChangedEvent,
  TooltipHiddenEvent,
  TooltipShownEvent,
  RangeContainer,
  Scale,
  ScaleLabel,
  Properties,
} from './linear_gauge';
