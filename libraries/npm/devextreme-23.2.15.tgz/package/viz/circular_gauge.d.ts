/**
* DevExtreme (viz/circular_gauge.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
    UserDefinedElement,
} from '../core/element';

import {
    EventInfo,
    InitializedEventInfo,
    ChangedOptionInfo,
} from '../events/index';

import {
    FileSavingEventInfo,
    ExportInfo,
    IncidentInfo,
} from './core/base_widget';

import {
    template,
} from '../core/templates/template';

import {
    BaseGauge,
    BaseGaugeOptions,
    BaseGaugeRangeContainer,
    BaseGaugeScale,
    BaseGaugeScaleLabel,
    GaugeIndicator,
    TooltipInfo,
} from './gauges/base_gauge';

export type CircularGaugeElementOrientation = 'center' | 'inside' | 'outside';
export type CircularGaugeLabelOverlap = 'first' | 'last';

/**
 * The type of the disposing event handler&apos;s argument.
 */
export type DisposingEvent = EventInfo<dxCircularGauge>;

/**
 * The type of the drawn event handler&apos;s argument.
 */
export type DrawnEvent = EventInfo<dxCircularGauge>;

/**
 * The type of the exported event handler&apos;s argument.
 */
export type ExportedEvent = EventInfo<dxCircularGauge>;

/**
 * The type of the exporting event handler&apos;s argument.
 */
export type ExportingEvent = EventInfo<dxCircularGauge> & ExportInfo;

/**
 * The type of the fileSaving event handler&apos;s argument.
 */
export type FileSavingEvent = FileSavingEventInfo<dxCircularGauge>;

/**
 * The type of the incidentOccurred event handler&apos;s argument.
 */
export type IncidentOccurredEvent = EventInfo<dxCircularGauge> & IncidentInfo;

/**
 * The type of the initialized event handler&apos;s argument.
 */
export type InitializedEvent = InitializedEventInfo<dxCircularGauge>;

/**
 * The type of the optionChanged event handler&apos;s argument.
 */
export type OptionChangedEvent = EventInfo<dxCircularGauge> & ChangedOptionInfo;

/**
 * The type of the tooltipHidden event handler&apos;s argument.
 */
export type TooltipHiddenEvent = EventInfo<dxCircularGauge> & TooltipInfo;

/**
 * The type of the tooltipShown event handler&apos;s argument.
 */
export type TooltipShownEvent = EventInfo<dxCircularGauge> & TooltipInfo;

/**
 * 
 * @deprecated 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface dxCircularGaugeOptions extends BaseGaugeOptions<dxCircularGauge> {
    /**
     * Specifies the properties required to set the geometry of the CircularGauge UI component.
     */
    geometry?: {
      /**
       * Specifies the end angle of the circular gauge&apos;s arc.
       */
      endAngle?: number;
      /**
       * Specifies the start angle of the circular gauge&apos;s arc.
       */
      startAngle?: number;
    };
    /**
     * Specifies a custom template for content in the component&apos;s center.
     */
    centerTemplate?: template | ((component: dxCircularGauge, element: SVGGElement) => string | UserDefinedElement<SVGElement>);
    /**
     * Specifies gauge range container properties.
     */
    rangeContainer?: RangeContainer;
    /**
     * Specifies a gauge&apos;s scale properties.
     */
    scale?: Scale;
    /**
     * Specifies the appearance properties of subvalue indicators.
     */
    subvalueIndicator?: GaugeIndicator;
    /**
     * Specifies the appearance properties of the value indicator.
     */
    valueIndicator?: GaugeIndicator;
}
/**
 * Specifies gauge range container properties.
 */
export type RangeContainer = BaseGaugeRangeContainer & {
    /**
     * Specifies the orientation of the range container in the CircularGauge UI component.
     */
    orientation?: CircularGaugeElementOrientation;
    /**
     * Specifies the range container&apos;s width in pixels.
     */
    width?: number;
};
/**
 * Specifies a gauge&apos;s scale properties.
 */
export type Scale = BaseGaugeScale & {
    /**
     * Specifies common properties for scale labels.
     */
    label?: ScaleLabel;
    /**
     * Specifies the orientation of scale ticks.
     */
    orientation?: CircularGaugeElementOrientation;
};
/**
 * Specifies common properties for scale labels.
 */
export type ScaleLabel = BaseGaugeScaleLabel & {
    /**
     * Specifies which label to hide in case of overlapping.
     */
    hideFirstOrLast?: CircularGaugeLabelOverlap;
    /**
     * Specifies the spacing between scale labels and ticks.
     */
    indentFromTick?: number;
};
/**
 * The CircularGauge is a UI component that indicates values on a circular numeric scale.
 */
export default class dxCircularGauge extends BaseGauge<dxCircularGaugeOptions> { }

export type Properties = dxCircularGaugeOptions;

/**
 * @deprecated use Properties instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type Options = dxCircularGaugeOptions;

// #region deprecated in v23.1

/**
 * @deprecated Use RangeContainer instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type dxCircularGaugeRangeContainer = RangeContainer;

/**
 * @deprecated Use Scale instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type dxCircularGaugeScale = Scale;

/**
 * @deprecated Use ScaleLabel instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type dxCircularGaugeScaleLabel = ScaleLabel;

// #endregion


