/**
* DevExtreme (viz/bar_gauge_types.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  LabelOverlap,
  Palette,
  PaletteExtensionMode,
  ShiftLabelOverlap,
  LegendItem,
  DisposingEvent,
  DrawnEvent,
  ExportedEvent,
  ExportingEvent,
  FileSavingEvent,
  IncidentOccurredEvent,
  InitializedEvent,
  OptionChangedEvent,
  TooltipHiddenEvent,
  TooltipShownEvent,
  Legend,
  LoadingIndicator,
  Tooltip,
  Properties,
} from './bar_gauge';
