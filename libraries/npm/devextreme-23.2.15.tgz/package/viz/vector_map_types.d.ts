/**
* DevExtreme (viz/vector_map_types.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  SingleMultipleOrNone,
  Palette,
  VectorMapProjection,
  VerticalEdge,
  VectorMapLayerType,
  VectorMapMarkerShape,
  VectorMapMarkerType,
  CenterChangedEvent,
  ClickEvent,
  DisposingEvent,
  DrawnEvent,
  ExportedEvent,
  ExportingEvent,
  FileSavingEvent,
  IncidentOccurredEvent,
  InitializedEvent,
  OptionChangedEvent,
  SelectionChangedEvent,
  TooltipHiddenEvent,
  TooltipShownEvent,
  ZoomFactorChangedEvent,
  LegendItem,
  Legend,
  Tooltip,
  Properties,
} from './vector_map';
