/**
* DevExtreme (viz/funnel_types.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  DashStyle,
  HatchDirection,
  HorizontalEdge,
  LabelPosition,
  Palette,
  PaletteExtensionMode,
  TextOverflow,
  ShiftLabelOverlap,
  WordWrap,
  FunnelAlgorithm,
  LegendItem,
  DisposingEvent,
  DrawnEvent,
  ExportedEvent,
  ExportingEvent,
  FileSavingEvent,
  HoverChangedEvent,
  IncidentOccurredEvent,
  InitializedEvent,
  ItemClickEvent,
  LegendClickEvent,
  OptionChangedEvent,
  SelectionChangedEvent,
  Legend,
  Tooltip,
  Item,
  Properties,
} from './funnel';
