/**
* DevExtreme (excel_exporter.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { DxPromise } from './core/utils/deferred';
import dxDataGrid, { Column } from './ui/data_grid';
import dxPivotGrid, { Cell } from './ui/pivot_grid';
import { ExportLoadPanel } from './exporter/export_load_panel';

export type DataGridCell = ExcelDataGridCell;

/**
 * @deprecated Use DataGridCell instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface ExcelDataGridCell {
    /**
     * The configuration of the cell&apos;s column.
     */
    column?: Column;
    /**
     * The data object of the cell&apos;s row.
     */
    data?: any;
    /**
     * The group index of the cell&apos;s row. Available when the rowType is &apos;group&apos;.
     */
    groupIndex?: number;
    /**
     * Information about group summary items the cell represents.
     */
    groupSummaryItems?: Array<{
      /**
       * The group summary item&apos;s identifier.
       */
      name?: string;
      /**
       * The group summary item&apos;s raw value.
       */
      value?: any;
    }>;
    /**
     * The type of the cell&apos;s row.
     */
    rowType?: string;
    /**
     * The identifier of the total summary item that the cell represents.
     */
    totalSummaryItemName?: string;
    /**
     * The cell&apos;s raw value.
     */
    value?: any;
}

export type PivotGridCell = ExcelPivotGridCell;

/**
 * @deprecated Use PivotGridCell instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface ExcelPivotGridCell extends Cell {
    /**
     * The area to which the cell belongs.
     */
    area?: 'column' | 'row' | 'data';
    /**
     * A zero-based index that indicates the position of the cell&apos;s row.
     */
    rowIndex?: number;
    /**
     * A zero-based index that indicates the position of the cell&apos;s column.
     */
    columnIndex?: number;
    /**
     * The header type. Available if the cell belongs to the field panel.
     */
    headerType?: 'column' | 'row' | 'data' | 'filter';
}

/**
 * 
 */
export interface CellAddress {
    /**
     * The index of a row that contains the cell.
     */
    row?: number;
    /**
     * The index of a column that contains the cell.
     */
    column?: number;
}

/**
 * The coordinates of the exported DataGrid in the Excel file.
 */
export interface CellRange {
    /**
     * Coordinates of the top left cell.
     */
    from?: CellAddress;
    /**
     * Coordinates of the bottom right cell.
     */
    to?: CellAddress;
}

/**
 * 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface ExcelExportBaseProps {
    /**
     * An Excel worksheet to which the grid should be exported.
     */
    worksheet?: object;
    /**
     * A cell used as a start position for export.
     */
    topLeftCell?: CellAddress | string;
    /**
     * Specifies whether Excel columns should have the same width as their source UI component&apos;s columns.
     */
    keepColumnWidths?: boolean;
    /**
     * Configures the load panel.
     */
    loadPanel?: ExportLoadPanel;
    /**
      * Specifies if the CSV export routine saves potentially dangerous content as plain text data.
      */
     encodeExecutableContent?: boolean;
}

/**
 * Properties that can be passed to the exportDataGrid(options) method from the excelExporter module.
 */
export interface ExcelExportDataGridProps extends ExcelExportBaseProps {
    /**
     * A DataGrid instance. This setting is required.
     */
    component?: dxDataGrid;
    /**
     * Specifies whether to export only selected rows.
     */
    selectedRowsOnly?: boolean;
    /**
     * Specifies whether to enable Excel filtering in the document.
     */
    autoFilterEnabled?: boolean;
    /**
     * Customizes an Excel cell after creation.
     */
    customizeCell?: ((options: { gridCell?: DataGridCell; excelCell?: any }) => void);
}

/**
 * Properties that can be passed to the exportPivotGrid(options) method from the excelExporter module.
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface ExcelExportPivotGridProps extends ExcelExportBaseProps {
    /**
     * A PivotGrid instance. This setting is required.
     */
    component?: dxPivotGrid;
    /**
     * Specifies whether to merge neighbouring cells in the row field if they have the same values.
     */
    mergeRowFieldValues?: boolean;
    /**
     * Specifies whether to merge neighbouring cells in the column field if they have the same values.
     */
    mergeColumnFieldValues?: boolean;
    /**
     * Specifies whether to export headers of the filter fields on the field panel.
     */
    exportFilterFieldHeaders?: boolean;
    /**
     * Specifies whether to export headers of the data fields on the field panel.
     */
    exportDataFieldHeaders?: boolean;
    /**
     * Specifies whether to export headers of the column fields on the field panel.
     */
    exportColumnFieldHeaders?: boolean;
    /**
     * Specifies whether to export headers of the row fields on the field panel.
     */
    exportRowFieldHeaders?: boolean;
    /**
     * Customizes an Excel cell after creation.
     */
    customizeCell?: ((options: { pivotCell?: PivotGridCell; excelCell?: any }) => void);
}

/**
 * Exports grid data to Excel.
 */
export function exportDataGrid(options: ExcelExportDataGridProps): DxPromise<CellRange>;

/**
 * Exports pivot grid data to Excel.
 */
export function exportPivotGrid(options: ExcelExportPivotGridProps): DxPromise<CellRange>;
