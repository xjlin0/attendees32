/**
* DevExtreme (common/data/custom-store.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
/**
 * An additional type for LoadResult.
 */
export type GroupItem<
    TItem = any,
> = {
  /**
   * A key to group items by.
   */
  key: any | string | number;
  /**
   * Contains an array of items or GroupItems, or nothing.
   */
  items: Array<TItem> | Array<GroupItem<TItem>> | null;
  /**
   * A total number of items.
   */
  count?: number;
  /**
   * A summary array that contains the resulting values in the same order as the summary definitions.
   */
  summary?: Array<any>;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
type LoadResultArray<TItem = any> = Array<TItem> | Array<GroupItem<TItem>>;

/**
 * An additional type for LoadResult.
 */
export type LoadResultObject<TItem = any> = {
    /**
     * Contains an array of items or GroupItems.
     */
    data: Array<TItem> | Array<GroupItem<TItem>>;
    /**
     * A total number of items.
     */
    totalCount?: number;
    /**
     * A summary array that contains the resulting values in the same order as the summary definitions.
     */
    summary?: Array<any>;
    /**
     * A number of groups.
     */
    groupCount?: number;
  };

/**
 * Specifies returned data of the `load()` method in CustomStore.
 */
export type LoadResult<
    TItem = any,
> =
  | Object
  | LoadResultArray<TItem>
  | LoadResultObject<TItem>;

/**
 * A type guard function that checks whether LoadResult is a LoadResultObject.
 */
export function isLoadResultObject<TItem>(res: LoadResult<TItem>): res is LoadResultObject<TItem>;

/**
 * A type guard function that checks whether LoadResult is an array of GroupItems.
 */
export function isGroupItemsArray<TItem>(res: LoadResult<TItem>): res is Array<GroupItem<TItem>>;

/**
 * A type guard function that checks whether LoadResult is an array of items.
 */
export function isItemsArray<TItem>(res: LoadResult<TItem>): res is Array<TItem>;
