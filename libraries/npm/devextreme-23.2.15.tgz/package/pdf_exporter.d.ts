/**
* DevExtreme (pdf_exporter.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { DxPromise } from './core/utils/deferred';
import dxDataGrid from './ui/data_grid';
import { ExportLoadPanel } from './exporter/export_load_panel';
import dxGantt, {
  GanttPdfExportMode,
  GanttPdfExportDateRange,
} from './ui/gantt';
import {
  DataGridCell as ExcelCell,
} from './excel_exporter';

export type DataGridCell = PdfDataGridCell;

 /**
 * @deprecated Use DataGridCell instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface PdfDataGridCell extends ExcelCell {}

/**
 * An object that configures export to PDF settings in a DataGrid cell.
 */
export interface Cell {
  /**
   * Specifies the background color of the cell.
   */
  backgroundColor?: string;
  /**
   * Specifies the color of the cell&apos;s outer borders.
   */
  borderColor?: string;
  /**
   * Specifies the width of the cell&apos;s borders.
   */
  borderWidth?: number;
  /**
   * Specifies whether to show cell&apos;s left border.
   */
  drawLeftBorder?: boolean;
  /**
   * Specifies whether to show cell&apos;s top border.
   */
  drawTopBorder?: boolean;
  /**
   * Specifies whether to show cell&apos;s right border.
   */
  drawRightBorder?: boolean;
  /**
   * Specifies whether to show cell&apos;s bottom border.
   */
  drawBottomBorder?: boolean;
  /**
   * An object that contains information about the font&apos;s size, name, and style.
   */
  font?: {
    /**
     * Specifies the font size.
     */
    size?: number;
    /**
     * Specifies the font name.
     */
    name?: string;
    /**
     * Specifies the font style.
     */
    style?: 'normal' | 'bold' | 'italic';
  };
  /**
   * Specifies the horizontal alignment for the text inside the exported cell.
   */
  horizontalAlign?: 'left' | 'center' | 'right';
  /**
   * Specifies the top, bottom, left, and right paddings of the DataGrid cell.
   */
  padding?: {
    /**
     * Specifies the top padding of the DataGrid cell.
     */
    top?: number;
    /**
     * Specifies the left padding of the DataGrid cell.
     */
    left?: number;
    /**
     * Specifies the right padding of the DataGrid cell.
     */
    right?: number;
    /**
     * Specifies the bottom padding of the DataGrid cell.
     */
    bottom?: number;
  };
  /**
   * The cell&apos;s text.
   */
  text?: string;
  /**
   * Specifies the text color for the cell.
   */
  textColor?: string;
  /**
   * Specifies the vertical alignment for the text inside the exported cell.
   */
  verticalAlign?: 'top' | 'middle' | 'bottom';
  /**
   * Specifies whether to enable word wrapping in the resulting PDF file.
   */
  wordWrapEnabled?: boolean;
}

/**
 * Properties that can be passed as a parameter to the exportDataGrid(options) method from the pdfExporter module.
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface PdfExportDataGridProps {
    /**
     * A jsPDF instance. This setting is required.
     */
    jsPDFDocument?: object;
    /**
     * A DataGrid instance. This setting is required.
     */
    component?: dxDataGrid;
    /**
     * Specifies the top left position of the DataGrid in the exported PDF document. Contains x and y properties. You can locate this position only below the page margins.
     */
    topLeft?: {
      /**
       * Specifies the horizontal position of the exported DataGrid.
       */
      x?: number;
      /**
       * Specifies the vertical position of the exported DataGrid.
       */
      y?: number;
    };
    /**
     * Specifies a custom width for the exported DataGrid columns.
     */
    columnWidths?: Array<number>;
    /**
     * Specifies the width of the indent of data rows relative to their group header row.
     */
    indent?: number;
    /**
     * Specifies the margin for the top, bottom, left, and right sides of the exported Grid.
     */
    margin?: {
      /**
       * Specifies the margin at the top of the page.
       */
      top?: number;
      /**
       * Specifies the margin at the left side of the page.
       */
      left?: number;
      /**
       * Specifies the margin at the right side of the page.
       */
      right?: number;
      /**
       * Specifies the margin at the bottom of the page.
       */
      bottom?: number;
    };
    /**
     * Specifies whether to repeat the DataGrid column headers on each page.
     */
    repeatHeaders?: boolean;
    /**
     * Specifies whether or not to export only selected rows.
     */
    selectedRowsOnly?: boolean;
    /**
     * A function that allows you to draw cell content of the exported DataGrid. This function is executed before the cell is exported.
     */
    customDrawCell?: ((options: { gridCell?: DataGridCell; pdfCell?: Cell; doc?: any; rect?: { x: number; y: number; h: number; w: number }; cancel?: boolean }) => void);
    /**
     * Customizes a cell in PDF after creation.
     */
    customizeCell?: ((options: { gridCell?: DataGridCell; pdfCell?: Cell }) => void);
    /**
     * A function that allows you to customize the height of the exported row. This function is executed before the row export.
     */
    onRowExporting?: ((options: { rowCells?: Array<Cell>; rowHeight?: number }) => void);
    /**
     * Configures the load panel.
     */
    loadPanel?: ExportLoadPanel;
}

/**
 * Exports grid data to a PDF file.
 */
export function exportDataGrid(options: PdfExportDataGridProps): DxPromise<void>;

/**
 * Properties that you can pass as a parameter to the exportGantt(options) method from the pdfExporter module.
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface PdfExportGanttProps {
  /**
   * A function that creates a PDF document.
   */
  createDocumentMethod?: ((options: any) => object);
  /**
   * A jsPDF instance. This setting is required.
   */
  jsPDFDocument?: object;
  /**
   * A Gantt instance. This setting is required.
   */
  component?: dxGantt;
  /**
   * Specifies the document size.
   */
  format?: string | object;
  /**
   * Specifies whether to use horizontal orientation for the document.
   */
  landscape?: boolean;
  /**
   * Specifies the file name.
   */
  fileName?: string;
  /**
   * Specifies the outer indents of the exported area.
   */
  margins?: object;
  /**
   * Specifies which part of the component to export (chart area, tree list area, or the entire component).
   */
  exportMode?: GanttPdfExportMode;
  /**
   * Specifies the date range for which to export tasks.
   */
  dateRange?: GanttPdfExportDateRange | object;
  /**
   * Specifies the font.
   */
  font?: PdfExportGanttFont;
}

/**
 * Configures a custom font used for the Gantt data export.
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface PdfExportGanttFont {
  /**
   * A custom font object.
   */
  fontObject: object;
  /**
   * The font name.
   */
  name: string;
  /**
   * The font style.
   */
  style?: string;
  /**
   * The font weight.
   */
  weight?: string | number;
}

/**
 * Exports Gantt data to a PDF file.
 */
export function exportGantt(options: PdfExportGanttProps): DxPromise<any>;
