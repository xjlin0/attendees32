/**
 * DevExtreme (renovation/ui/scroll_view/scroll_view.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.ScrollView = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _type = require("../../../core/utils/type");
var _scrollable = require("./scrollable");
var _scrollview_props = require("./common/scrollview_props");
var _load_panel = require("./internal/load_panel");
const _excluded = ["addWidgetClass", "aria", "bounceEnabled", "children", "classes", "direction", "disabled", "forceGeneratePockets", "height", "inertiaEnabled", "loadPanelTemplate", "needRenderScrollbars", "needScrollViewContentWrapper", "onBounce", "onEnd", "onPullDown", "onReachBottom", "onScroll", "onStart", "onUpdated", "onVisibilityChange", "pullDownEnabled", "pulledDownText", "pullingDownText", "reachBottomEnabled", "reachBottomText", "refreshStrategy", "refreshingText", "rtlEnabled", "scrollByContent", "scrollByThumb", "scrollLocationChange", "showScrollbar", "useKeyboard", "useNative", "useSimulatedScrollbar", "visible", "width"];

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _assertThisInitialized(self) {
    if (void 0 === self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
    }
    return self
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const viewFunction = viewModel => {
    const {
        props: {
            aria: aria,
            bounceEnabled: bounceEnabled,
            children: children,
            direction: direction,
            disabled: disabled,
            height: height,
            inertiaEnabled: inertiaEnabled,
            onBounce: onBounce,
            onEnd: onEnd,
            onPullDown: onPullDown,
            onReachBottom: onReachBottom,
            onScroll: onScroll,
            onStart: onStart,
            onUpdated: onUpdated,
            pullDownEnabled: pullDownEnabled,
            pulledDownText: pulledDownText,
            pullingDownText: pullingDownText,
            reachBottomText: reachBottomText,
            refreshStrategy: refreshStrategy,
            refreshingText: refreshingText,
            rtlEnabled: rtlEnabled,
            scrollByContent: scrollByContent,
            scrollByThumb: scrollByThumb,
            showScrollbar: showScrollbar,
            useKeyboard: useKeyboard,
            useNative: useNative,
            useSimulatedScrollbar: useSimulatedScrollbar,
            visible: visible,
            width: width
        },
        reachBottomEnabled: reachBottomEnabled,
        restAttributes: restAttributes,
        scrollableRef: scrollableRef
    } = viewModel;
    return (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, _scrollable.Scrollable, _extends({
        useNative: useNative,
        classes: "dx-scrollview",
        aria: aria,
        width: width,
        height: height,
        disabled: disabled,
        visible: visible,
        rtlEnabled: rtlEnabled,
        direction: direction,
        showScrollbar: showScrollbar,
        scrollByThumb: scrollByThumb,
        pullDownEnabled: pullDownEnabled,
        reachBottomEnabled: reachBottomEnabled,
        onScroll: onScroll,
        onUpdated: onUpdated,
        onPullDown: onPullDown,
        onReachBottom: onReachBottom,
        refreshStrategy: refreshStrategy,
        pulledDownText: pulledDownText,
        pullingDownText: pullingDownText,
        refreshingText: refreshingText,
        reachBottomText: reachBottomText,
        forceGeneratePockets: true,
        needScrollViewContentWrapper: true,
        useSimulatedScrollbar: useSimulatedScrollbar,
        inertiaEnabled: inertiaEnabled,
        bounceEnabled: bounceEnabled,
        scrollByContent: scrollByContent,
        useKeyboard: useKeyboard,
        onStart: onStart,
        onEnd: onEnd,
        onBounce: onBounce,
        loadPanelTemplate: _load_panel.ScrollViewLoadPanel
    }, restAttributes, {
        children: children
    }), null, scrollableRef))
};
exports.viewFunction = viewFunction;
const getTemplate = TemplateProp => TemplateProp && (TemplateProp.defaultProps ? props => (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, TemplateProp, _extends({}, props))) : TemplateProp);
let ScrollView = function(_InfernoWrapperCompon) {
    _inheritsLoose(ScrollView, _InfernoWrapperCompon);

    function ScrollView(props) {
        var _this;
        _this = _InfernoWrapperCompon.call(this, props) || this;
        _this.scrollableRef = (0, _inferno.createRef)();
        _this.state = {
            forceReachBottom: void 0
        };
        _this.release = _this.release.bind(_assertThisInitialized(_this));
        _this.refresh = _this.refresh.bind(_assertThisInitialized(_this));
        _this.content = _this.content.bind(_assertThisInitialized(_this));
        _this.container = _this.container.bind(_assertThisInitialized(_this));
        _this.scrollBy = _this.scrollBy.bind(_assertThisInitialized(_this));
        _this.scrollTo = _this.scrollTo.bind(_assertThisInitialized(_this));
        _this.scrollToElement = _this.scrollToElement.bind(_assertThisInitialized(_this));
        _this.scrollHeight = _this.scrollHeight.bind(_assertThisInitialized(_this));
        _this.scrollWidth = _this.scrollWidth.bind(_assertThisInitialized(_this));
        _this.scrollOffset = _this.scrollOffset.bind(_assertThisInitialized(_this));
        _this.scrollTop = _this.scrollTop.bind(_assertThisInitialized(_this));
        _this.scrollLeft = _this.scrollLeft.bind(_assertThisInitialized(_this));
        _this.clientHeight = _this.clientHeight.bind(_assertThisInitialized(_this));
        _this.clientWidth = _this.clientWidth.bind(_assertThisInitialized(_this));
        _this.toggleLoading = _this.toggleLoading.bind(_assertThisInitialized(_this));
        _this.startLoading = _this.startLoading.bind(_assertThisInitialized(_this));
        _this.finishLoading = _this.finishLoading.bind(_assertThisInitialized(_this));
        _this.updateHandler = _this.updateHandler.bind(_assertThisInitialized(_this));
        return _this
    }
    var _proto = ScrollView.prototype;
    _proto.createEffects = function() {
        return [(0, _inferno2.createReRenderEffect)()]
    };
    _proto.release = function(preventScrollBottom) {
        if (void 0 !== preventScrollBottom) {
            this.toggleLoading(!preventScrollBottom)
        }
        this.scrollableRef.current.release()
    };
    _proto.refresh = function() {
        if (this.props.pullDownEnabled) {
            this.scrollableRef.current.refresh()
        }
    };
    _proto.content = function() {
        return this.scrollableRef.current.content()
    };
    _proto.container = function() {
        return this.scrollableRef.current.container()
    };
    _proto.scrollBy = function(distance) {
        this.scrollableRef.current.scrollBy(distance)
    };
    _proto.scrollTo = function(targetLocation) {
        this.scrollableRef.current.scrollTo(targetLocation)
    };
    _proto.scrollToElement = function(element, offset) {
        this.scrollableRef.current.scrollToElement(element, offset)
    };
    _proto.scrollHeight = function() {
        return this.scrollableRef.current.scrollHeight()
    };
    _proto.scrollWidth = function() {
        return this.scrollableRef.current.scrollWidth()
    };
    _proto.scrollOffset = function() {
        return this.scrollableRef.current.scrollOffset()
    };
    _proto.scrollTop = function() {
        return this.scrollableRef.current.scrollTop()
    };
    _proto.scrollLeft = function() {
        return this.scrollableRef.current.scrollLeft()
    };
    _proto.clientHeight = function() {
        return this.scrollableRef.current.clientHeight()
    };
    _proto.clientWidth = function() {
        return this.scrollableRef.current.clientWidth()
    };
    _proto.toggleLoading = function(showOrHide) {
        this.setState(__state_argument => ({
            forceReachBottom: showOrHide
        }))
    };
    _proto.startLoading = function() {
        this.scrollableRef.current.startLoading()
    };
    _proto.finishLoading = function() {
        this.scrollableRef.current.finishLoading()
    };
    _proto.updateHandler = function() {
        this.scrollableRef.current.updateHandler()
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props, {
                loadPanelTemplate: (TemplateProp = props.loadPanelTemplate, TemplateProp && (TemplateProp.defaultProps ? props => (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, TemplateProp, _extends({}, props))) : TemplateProp))
            }),
            forceReachBottom: this.state.forceReachBottom,
            scrollableRef: this.scrollableRef,
            reachBottomEnabled: this.reachBottomEnabled,
            restAttributes: this.restAttributes
        });
        var TemplateProp
    };
    _createClass(ScrollView, [{
        key: "reachBottomEnabled",
        get: function() {
            if ((0, _type.isDefined)(this.state.forceReachBottom)) {
                return this.state.forceReachBottom
            }
            return this.props.reachBottomEnabled
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props, _excluded);
            return restProps
        }
    }]);
    return ScrollView
}(_inferno2.InfernoWrapperComponent);
exports.ScrollView = ScrollView;
ScrollView.defaultProps = _scrollview_props.ScrollViewProps;
