/**
 * DevExtreme (renovation/ui/scroll_view/utils/get_bounding_rect.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.getBoundingRect = getBoundingRect;

function getBoundingRect(el) {
    return null !== el && void 0 !== el && el.getBoundingClientRect ? el.getBoundingClientRect() : {
        width: 0,
        height: 0,
        bottom: 0,
        top: 0,
        left: 0,
        right: 0
    }
}
