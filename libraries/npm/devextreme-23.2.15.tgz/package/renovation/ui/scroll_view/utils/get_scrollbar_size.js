/**
 * DevExtreme (renovation/ui/scroll_view/utils/get_scrollbar_size.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.getScrollbarSize = getScrollbarSize;

function getScrollbarSize(element, direction) {
    if ("vertical" === direction) {
        return element.offsetWidth - element.clientWidth
    }
    return element.offsetHeight - element.clientHeight
}
