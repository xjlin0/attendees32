/**
 * DevExtreme (renovation/ui/scroll_view/utils/convert_location.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.convertToLocation = convertToLocation;
var _type = require("../../../../core/utils/type");
var _common = require("../../../../core/utils/common");
var _scroll_direction = require("./scroll_direction");

function convertToLocation(location, direction) {
    if ((0, _type.isPlainObject)(location)) {
        const left = (0, _common.ensureDefined)(location.left, location.x);
        const top = (0, _common.ensureDefined)(location.top, location.y);
        return {
            left: (0, _type.isDefined)(left) ? left : void 0,
            top: (0, _type.isDefined)(top) ? top : void 0
        }
    }
    const {
        isHorizontal: isHorizontal,
        isVertical: isVertical
    } = new _scroll_direction.ScrollDirection(direction);
    return {
        left: isHorizontal && (0, _type.isDefined)(location) ? location : void 0,
        top: isVertical && (0, _type.isDefined)(location) ? location : void 0
    }
}
