/**
 * DevExtreme (renovation/ui/scroll_view/utils/get_allowed_direction.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.allowedDirection = allowedDirection;
var _consts = require("../common/consts");
var _scroll_direction = require("./scroll_direction");

function allowedDirection(direction, scrollTopMax, scrollLeftMax, bounceEnabled) {
    const {
        isBoth: isBoth,
        isHorizontal: isHorizontal,
        isVertical: isVertical
    } = new _scroll_direction.ScrollDirection(direction);
    const vDirectionAllowed = isVertical && (scrollTopMax > 0 || bounceEnabled);
    const hDirectionAllowed = isHorizontal && (scrollLeftMax > 0 || bounceEnabled);
    if (isBoth && vDirectionAllowed && hDirectionAllowed) {
        return _consts.DIRECTION_BOTH
    }
    if (isHorizontal && hDirectionAllowed) {
        return _consts.DIRECTION_HORIZONTAL
    }
    if (isVertical && vDirectionAllowed) {
        return _consts.DIRECTION_VERTICAL
    }
    return
}
