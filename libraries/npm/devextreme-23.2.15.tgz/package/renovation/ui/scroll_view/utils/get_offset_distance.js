/**
 * DevExtreme (renovation/ui/scroll_view/utils/get_offset_distance.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.getOffsetDistance = getOffsetDistance;
var _common = require("../../../../core/utils/common");

function getOffsetDistance(targetLocation, scrollOffset) {
    return {
        top: (0, _common.ensureDefined)(targetLocation.top, scrollOffset.top) - scrollOffset.top,
        left: (0, _common.ensureDefined)(targetLocation.left, scrollOffset.left) - scrollOffset.left
    }
}
