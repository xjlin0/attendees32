/**
 * DevExtreme (renovation/ui/scroll_view/internal/pocket/top.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.TopPocketProps = exports.TopPocket = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _load_indicator = require("../../../load_indicator");
var _combine_classes = require("../../../../utils/combine_classes");
var _message = _interopRequireDefault(require("../../../../../localization/message"));
var _consts = require("../../common/consts");
var _themes = require("../../../../../ui/themes");
const _excluded = ["pocketState", "pocketTop", "pullDownIconAngle", "pullDownOpacity", "pullDownTranslateTop", "pulledDownText", "pullingDownText", "refreshStrategy", "refreshingText", "topPocketRef", "topPocketTranslateTop", "visible"];

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}
const viewFunction = viewModel => {
    const {
        props: {
            pulledDownText: pulledDownText,
            pullingDownText: pullingDownText,
            refreshStrategy: refreshStrategy,
            refreshingText: refreshingText,
            topPocketRef: topPocketRef
        },
        pullDownClasses: pullDownClasses,
        pullDownIconStyles: pullDownIconStyles,
        pullDownRef: pullDownRef,
        pullDownStyles: pullDownStyles,
        readyVisibleClass: readyVisibleClass,
        refreshVisibleClass: refreshVisibleClass,
        releaseVisibleClass: releaseVisibleClass,
        topPocketClasses: topPocketClasses,
        topPocketStyles: topPocketStyles
    } = viewModel;
    return (0, _inferno.createVNode)(1, "div", topPocketClasses, (0, _inferno.createVNode)(1, "div", pullDownClasses, ["swipeDown" !== refreshStrategy && (0, _inferno.createVNode)(1, "div", _consts.SCROLLVIEW_PULLDOWN_IMAGE_CLASS), "swipeDown" === refreshStrategy && (0, _inferno.createVNode)(1, "div", _consts.PULLDOWN_ICON_CLASS, null, 1, {
        style: (0, _inferno2.normalizeStyles)(pullDownIconStyles)
    }), (0, _inferno.createVNode)(1, "div", _consts.SCROLLVIEW_PULLDOWN_INDICATOR_CLASS, (0, _inferno.createComponentVNode)(2, _load_indicator.LoadIndicator), 2), "swipeDown" !== refreshStrategy && (0, _inferno.createVNode)(1, "div", _consts.SCROLLVIEW_PULLDOWN_TEXT_CLASS, [(0, _inferno.createVNode)(1, "div", releaseVisibleClass, pullingDownText, 0), (0, _inferno.createVNode)(1, "div", readyVisibleClass, pulledDownText, 0), (0, _inferno.createVNode)(1, "div", refreshVisibleClass, refreshingText, 0)], 4)], 0, {
        style: (0, _inferno2.normalizeStyles)(pullDownStyles)
    }, null, pullDownRef), 2, {
        style: (0, _inferno2.normalizeStyles)(topPocketStyles)
    }, null, topPocketRef)
};
exports.viewFunction = viewFunction;
const TopPocketProps = Object.defineProperties({
    pullDownTranslateTop: 0,
    pullDownIconAngle: 0,
    pullDownOpacity: 0,
    pocketTop: 0,
    topPocketTranslateTop: 0,
    visible: true
}, {
    pullingDownText: {
        get: function() {
            return (0, _themes.isMaterial)((0, _themes.current)()) ? "" : _message.default.format("dxScrollView-pullingDownText")
        },
        configurable: true,
        enumerable: true
    },
    pulledDownText: {
        get: function() {
            return (0, _themes.isMaterial)((0, _themes.current)()) ? "" : _message.default.format("dxScrollView-pulledDownText")
        },
        configurable: true,
        enumerable: true
    },
    refreshingText: {
        get: function() {
            return (0, _themes.isMaterial)((0, _themes.current)()) ? "" : _message.default.format("dxScrollView-refreshingText")
        },
        configurable: true,
        enumerable: true
    },
    pocketState: {
        get: function() {
            return _consts.TopPocketState.STATE_RELEASED
        },
        configurable: true,
        enumerable: true
    }
});
exports.TopPocketProps = TopPocketProps;
let TopPocket = function(_BaseInfernoComponent) {
    _inheritsLoose(TopPocket, _BaseInfernoComponent);

    function TopPocket(props) {
        var _this;
        _this = _BaseInfernoComponent.call(this, props) || this;
        _this.state = {};
        _this.pullDownRef = (0, _inferno.createRef)();
        _this.__getterCache = {};
        return _this
    }
    var _proto = TopPocket.prototype;
    _proto.componentWillUpdate = function(nextProps, nextState, context) {
        if (this.props.refreshStrategy !== nextProps.refreshStrategy || this.props.pullDownOpacity !== nextProps.pullDownOpacity || this.props.pullDownTranslateTop !== nextProps.pullDownTranslateTop) {
            this.__getterCache.pullDownStyles = void 0
        }
        if (this.props.refreshStrategy !== nextProps.refreshStrategy || this.props.pocketTop !== nextProps.pocketTop || this.props.topPocketTranslateTop !== nextProps.topPocketTranslateTop) {
            this.__getterCache.topPocketStyles = void 0
        }
        if (this.props.pullDownIconAngle !== nextProps.pullDownIconAngle) {
            this.__getterCache.pullDownIconStyles = void 0
        }
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props),
            pullDownRef: this.pullDownRef,
            releaseVisibleClass: this.releaseVisibleClass,
            readyVisibleClass: this.readyVisibleClass,
            refreshVisibleClass: this.refreshVisibleClass,
            pullDownClasses: this.pullDownClasses,
            topPocketClasses: this.topPocketClasses,
            pullDownStyles: this.pullDownStyles,
            topPocketStyles: this.topPocketStyles,
            pullDownIconStyles: this.pullDownIconStyles,
            restAttributes: this.restAttributes
        })
    };
    _createClass(TopPocket, [{
        key: "releaseVisibleClass",
        get: function() {
            return this.props.pocketState === _consts.TopPocketState.STATE_RELEASED ? _consts.SCROLLVIEW_PULLDOWN_VISIBLE_TEXT_CLASS : void 0
        }
    }, {
        key: "readyVisibleClass",
        get: function() {
            return this.props.pocketState === _consts.TopPocketState.STATE_READY ? _consts.SCROLLVIEW_PULLDOWN_VISIBLE_TEXT_CLASS : void 0
        }
    }, {
        key: "refreshVisibleClass",
        get: function() {
            return this.props.pocketState === _consts.TopPocketState.STATE_REFRESHING ? _consts.SCROLLVIEW_PULLDOWN_VISIBLE_TEXT_CLASS : void 0
        }
    }, {
        key: "pullDownClasses",
        get: function() {
            const {
                pocketState: pocketState,
                visible: visible
            } = this.props;
            const classesMap = {
                [_consts.SCROLLVIEW_PULLDOWN]: true,
                [_consts.SCROLLVIEW_PULLDOWN_READY_CLASS]: pocketState === _consts.TopPocketState.STATE_READY,
                [_consts.SCROLLVIEW_PULLDOWN_LOADING_CLASS]: pocketState === _consts.TopPocketState.STATE_REFRESHING,
                "dx-state-invisible": !visible
            };
            return (0, _combine_classes.combineClasses)(classesMap)
        }
    }, {
        key: "topPocketClasses",
        get: function() {
            const classesMap = {
                [_consts.SCROLLVIEW_TOP_POCKET_CLASS]: true,
                "dx-state-invisible": !this.props.visible
            };
            return (0, _combine_classes.combineClasses)(classesMap)
        }
    }, {
        key: "pullDownStyles",
        get: function() {
            if (void 0 !== this.__getterCache.pullDownStyles) {
                return this.__getterCache.pullDownStyles
            }
            return this.__getterCache.pullDownStyles = (() => {
                if ("swipeDown" === this.props.refreshStrategy) {
                    return {
                        opacity: this.props.pullDownOpacity,
                        transform: "translate(0px, ".concat(this.props.pullDownTranslateTop, "px)")
                    }
                }
                return
            })()
        }
    }, {
        key: "topPocketStyles",
        get: function() {
            if (void 0 !== this.__getterCache.topPocketStyles) {
                return this.__getterCache.topPocketStyles
            }
            return this.__getterCache.topPocketStyles = (() => {
                if ("pullDown" === this.props.refreshStrategy) {
                    return {
                        top: "".concat(-this.props.pocketTop, "px"),
                        transform: "translate(0px, ".concat(this.props.topPocketTranslateTop, "px)")
                    }
                }
                return
            })()
        }
    }, {
        key: "pullDownIconStyles",
        get: function() {
            if (void 0 !== this.__getterCache.pullDownIconStyles) {
                return this.__getterCache.pullDownIconStyles
            }
            return this.__getterCache.pullDownIconStyles = (() => ({
                transform: "rotate(".concat(this.props.pullDownIconAngle, "deg)")
            }))()
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props, _excluded);
            return restProps
        }
    }]);
    return TopPocket
}(_inferno2.BaseInfernoComponent);
exports.TopPocket = TopPocket;
TopPocket.defaultProps = TopPocketProps;
