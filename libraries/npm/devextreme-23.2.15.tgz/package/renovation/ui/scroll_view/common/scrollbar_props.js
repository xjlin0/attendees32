/**
 * DevExtreme (renovation/ui/scroll_view/common/scrollbar_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.ScrollbarProps = void 0;
const ScrollbarProps = {
    direction: "vertical",
    containerSize: 0,
    contentSize: 0,
    visible: false,
    containerHasSizes: false,
    scrollLocation: 0,
    minOffset: 0,
    maxOffset: 0
};
exports.ScrollbarProps = ScrollbarProps;
