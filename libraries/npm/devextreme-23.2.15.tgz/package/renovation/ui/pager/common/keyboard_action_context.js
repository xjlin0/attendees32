/**
 * DevExtreme (renovation/ui/pager/common/keyboard_action_context.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.KeyboardActionContext = void 0;
var _inferno = require("@devextreme/runtime/inferno");
const KeyboardActionContext = (0, _inferno.createContext)(void 0);
exports.KeyboardActionContext = KeyboardActionContext;
