/**
 * DevExtreme (renovation/ui/pager/common/consts.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.PAGER_SELECTION_CLASS = exports.PAGER_SELECTED_PAGE_SIZE_CLASS = exports.PAGER_PAGE_SIZE_CLASS = exports.PAGER_PAGE_SIZES_CLASS = exports.PAGER_PAGE_INDEXES_CLASS = exports.PAGER_PAGE_CLASS = exports.PAGER_PAGES_CLASS = exports.PAGER_CLASS = exports.LIGHT_MODE_CLASS = exports.FIRST_CHILD_CLASS = void 0;
const PAGER_CLASS = "dx-pager";
exports.PAGER_CLASS = "dx-pager";
const LIGHT_MODE_CLASS = "dx-light-mode";
exports.LIGHT_MODE_CLASS = "dx-light-mode";
const PAGER_PAGES_CLASS = "dx-pages";
exports.PAGER_PAGES_CLASS = "dx-pages";
const PAGER_PAGE_INDEXES_CLASS = "dx-page-indexes";
exports.PAGER_PAGE_INDEXES_CLASS = "dx-page-indexes";
const PAGER_PAGE_CLASS = "dx-page";
exports.PAGER_PAGE_CLASS = "dx-page";
const PAGER_SELECTION_CLASS = "dx-selection";
exports.PAGER_SELECTION_CLASS = "dx-selection";
const PAGER_PAGE_SIZE_CLASS = "dx-page-size";
exports.PAGER_PAGE_SIZE_CLASS = "dx-page-size";
const PAGER_PAGE_SIZES_CLASS = "dx-page-sizes";
exports.PAGER_PAGE_SIZES_CLASS = "dx-page-sizes";
const PAGER_SELECTED_PAGE_SIZE_CLASS = "".concat("dx-page-size", " ").concat("dx-selection");
exports.PAGER_SELECTED_PAGE_SIZE_CLASS = PAGER_SELECTED_PAGE_SIZE_CLASS;
const FIRST_CHILD_CLASS = "dx-first-child";
exports.FIRST_CHILD_CLASS = "dx-first-child";
