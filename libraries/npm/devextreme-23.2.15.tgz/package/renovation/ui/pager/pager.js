/**
 * DevExtreme (renovation/ui/pager/pager.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.Pager = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _resizable_container = require("./resizable_container");
var _pager_props = require("./common/pager_props");
var _content = require("./content");
var _combine_classes = require("../../utils/combine_classes");
const _excluded = ["className", "defaultPageIndex", "defaultPageSize", "displayMode", "gridCompatibility", "hasKnownLastPage", "infoText", "label", "lightModeEnabled", "maxPagesCount", "onKeyDown", "pageCount", "pageIndex", "pageIndexChange", "pageSize", "pageSizeChange", "pageSizes", "pagesCountText", "pagesNavigatorVisible", "rtlEnabled", "showInfo", "showNavigationButtons", "showPageSizes", "totalCount", "visible"];

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _assertThisInitialized(self) {
    if (void 0 === self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
    }
    return self
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const viewFunction = _ref => {
    let {
        pagerProps: pagerProps,
        restAttributes: restAttributes
    } = _ref;
    return (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, _resizable_container.ResizableContainer, _extends({
        contentTemplate: _content.PagerContent,
        pagerProps: pagerProps
    }, restAttributes)))
};
exports.viewFunction = viewFunction;
let Pager = function(_InfernoWrapperCompon) {
    _inheritsLoose(Pager, _InfernoWrapperCompon);

    function Pager(props) {
        var _this;
        _this = _InfernoWrapperCompon.call(this, props) || this;
        _this.__getterCache = {};
        _this.state = {
            pageSize: void 0 !== _this.props.pageSize ? _this.props.pageSize : _this.props.defaultPageSize,
            pageIndex: void 0 !== _this.props.pageIndex ? _this.props.pageIndex : _this.props.defaultPageIndex
        };
        _this.pageIndexChange = _this.pageIndexChange.bind(_assertThisInitialized(_this));
        _this.pageSizeChange = _this.pageSizeChange.bind(_assertThisInitialized(_this));
        return _this
    }
    var _proto = Pager.prototype;
    _proto.createEffects = function() {
        return [(0, _inferno2.createReRenderEffect)()]
    };
    _proto.pageIndexChange = function(newPageIndex) {
        if (this.props.gridCompatibility) {
            let __newValue;
            this.setState(__state_argument => {
                __newValue = newPageIndex + 1;
                return {
                    pageIndex: __newValue
                }
            });
            this.props.pageIndexChange(__newValue)
        } else {
            let __newValue;
            this.setState(__state_argument => {
                __newValue = newPageIndex;
                return {
                    pageIndex: __newValue
                }
            });
            this.props.pageIndexChange(__newValue)
        }
    };
    _proto.pageSizeChange = function(newPageSize) {
        {
            let __newValue;
            this.setState(__state_argument => {
                __newValue = newPageSize;
                return {
                    pageSize: __newValue
                }
            });
            this.props.pageSizeChange(__newValue)
        }
    };
    _proto.componentWillUpdate = function(nextProps, nextState, context) {
        _InfernoWrapperCompon.prototype.componentWillUpdate.call(this);
        if (this.props !== nextProps || this.props.gridCompatibility !== nextProps.gridCompatibility || this.props.className !== nextProps.className || this.state.pageIndex !== nextState.pageIndex || this.props.pageIndex !== nextProps.pageIndex || this.props.pageIndexChange !== nextProps.pageIndexChange || this.props.pageSizeChange !== nextProps.pageSizeChange) {
            this.__getterCache.pagerProps = void 0
        }
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props, {
                pageSize: void 0 !== this.props.pageSize ? this.props.pageSize : this.state.pageSize,
                pageIndex: void 0 !== this.props.pageIndex ? this.props.pageIndex : this.state.pageIndex
            }),
            pageIndexChange: this.pageIndexChange,
            pageIndex: this.pageIndex,
            pageSizeChange: this.pageSizeChange,
            className: this.className,
            pagerProps: this.pagerProps,
            restAttributes: this.restAttributes
        })
    };
    _createClass(Pager, [{
        key: "pageIndex",
        get: function() {
            if (this.props.gridCompatibility) {
                return (void 0 !== this.props.pageIndex ? this.props.pageIndex : this.state.pageIndex) - 1
            }
            return void 0 !== this.props.pageIndex ? this.props.pageIndex : this.state.pageIndex
        }
    }, {
        key: "className",
        get: function() {
            if (this.props.gridCompatibility) {
                return (0, _combine_classes.combineClasses)({
                    "dx-datagrid-pager": true,
                    ["".concat(this.props.className)]: !!this.props.className
                })
            }
            return this.props.className
        }
    }, {
        key: "pagerProps",
        get: function() {
            if (void 0 !== this.__getterCache.pagerProps) {
                return this.__getterCache.pagerProps
            }
            return this.__getterCache.pagerProps = (() => _extends({}, _extends({}, this.props, {
                pageSize: void 0 !== this.props.pageSize ? this.props.pageSize : this.state.pageSize,
                pageIndex: void 0 !== this.props.pageIndex ? this.props.pageIndex : this.state.pageIndex
            }), {
                className: this.className,
                pageIndex: this.pageIndex,
                pageIndexChange: pageIndex => this.pageIndexChange(pageIndex),
                pageSizeChange: pageSize => this.pageSizeChange(pageSize)
            }))()
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props$pageSize$ = _extends({}, this.props, {
                    pageSize: void 0 !== this.props.pageSize ? this.props.pageSize : this.state.pageSize,
                    pageIndex: void 0 !== this.props.pageIndex ? this.props.pageIndex : this.state.pageIndex
                }),
                restProps = _objectWithoutPropertiesLoose(_this$props$pageSize$, _excluded);
            return restProps
        }
    }]);
    return Pager
}(_inferno2.InfernoWrapperComponent);
exports.Pager = Pager;
Pager.defaultProps = _pager_props.PagerProps;
