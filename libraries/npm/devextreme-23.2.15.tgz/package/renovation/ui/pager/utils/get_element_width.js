/**
 * DevExtreme (renovation/ui/pager/utils/get_element_width.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.getElementContentWidth = getElementContentWidth;
exports.getElementMinWidth = getElementMinWidth;
exports.getElementStyle = getElementStyle;
exports.getElementWidth = getElementWidth;
var _get_computed_style = _interopRequireDefault(require("../../../utils/get_computed_style"));
var _type_conversion = require("../../../utils/type_conversion");

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function getElementStyle(name, element) {
    var _getElementComputedSt;
    const computedStyle = null !== (_getElementComputedSt = (0, _get_computed_style.default)(element)) && void 0 !== _getElementComputedSt ? _getElementComputedSt : {};
    return (0, _type_conversion.toNumber)(computedStyle[name])
}

function getElementContentWidth(element) {
    const padding = getElementStyle("paddingLeft", element) + getElementStyle("paddingRight", element);
    const width = getElementStyle("width", element);
    return width - padding
}

function getElementWidth(element) {
    const margin = getElementStyle("marginLeft", element) + getElementStyle("marginRight", element);
    const width = getElementStyle("width", element);
    return margin + width
}

function getElementMinWidth(element) {
    return getElementStyle("minWidth", element)
}
