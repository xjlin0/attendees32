/**
 * DevExtreme (renovation/ui/pager/utils/calculate_values_fitted_width.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.calculateValuesFittedWidth = calculateValuesFittedWidth;
exports.oneDigitWidth = void 0;
const oneDigitWidth = 10;
exports.oneDigitWidth = 10;

function calculateValuesFittedWidth(minWidth, values) {
    return minWidth + 10 * Math.max(...values).toString().length
}
