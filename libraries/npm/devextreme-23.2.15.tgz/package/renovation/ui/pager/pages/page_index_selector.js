/**
 * DevExtreme (renovation/ui/pager/pages/page_index_selector.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.PageIndexSelectorProps = exports.PageIndexSelector = exports.PAGER_BUTTON_DISABLE_CLASS = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _light_button = require("../common/light_button");
var _large = require("./large");
var _small = require("./small");
var _pager_props = require("../common/pager_props");
var _config_context = require("../../../common/config_context");
var _message = _interopRequireDefault(require("../../../../localization/message"));
const _excluded = ["hasKnownLastPage", "isLargeDisplayMode", "maxPagesCount", "pageCount", "pageIndex", "pageIndexChange", "pagesCountText", "showNavigationButtons", "totalCount"];

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _assertThisInitialized(self) {
    if (void 0 === self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
    }
    return self
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}
const PAGER_NAVIGATE_BUTTON = "dx-navigate-button";
const PAGER_PREV_BUTTON_CLASS = "dx-prev-button";
const PAGER_NEXT_BUTTON_CLASS = "dx-next-button";
const PAGER_BUTTON_DISABLE_CLASS = "dx-button-disable";
exports.PAGER_BUTTON_DISABLE_CLASS = "dx-button-disable";
const getNextButtonLabel = () => _message.default.getFormatter("dxPager-nextPage")();
const getPrevButtonLabel = () => _message.default.getFormatter("dxPager-prevPage")();
const classNames = {
    nextEnabledClass: "".concat("dx-navigate-button", " ").concat("dx-next-button"),
    prevEnabledClass: "".concat("dx-navigate-button", " ").concat("dx-prev-button"),
    nextDisabledClass: "".concat("dx-button-disable", " ").concat("dx-navigate-button", " ").concat("dx-next-button"),
    prevDisabledClass: "".concat("dx-button-disable", " ").concat("dx-navigate-button", " ").concat("dx-prev-button")
};
const reverseDirections = {
    next: "prev",
    prev: "next"
};
const viewFunction = _ref => {
    let {
        nextButtonProps: nextButtonProps,
        pageIndexChange: pageIndexChange,
        prevButtonProps: prevButtonProps,
        props: {
            isLargeDisplayMode: isLargeDisplayMode,
            maxPagesCount: maxPagesCount,
            pageCount: pageCount,
            pageIndex: pageIndex,
            pagesCountText: pagesCountText
        },
        renderNextButton: renderNextButton,
        renderPrevButton: renderPrevButton
    } = _ref;
    return (0, _inferno.createFragment)([renderPrevButton && (0, _inferno.createComponentVNode)(2, _light_button.LightButton, {
        label: _message.default.getFormatter("dxPager-prevPage")(),
        className: prevButtonProps.className,
        tabIndex: prevButtonProps.tabIndex,
        onClick: prevButtonProps.navigate
    }), isLargeDisplayMode && (0, _inferno.createComponentVNode)(2, _large.PagesLarge, {
        maxPagesCount: maxPagesCount,
        pageCount: pageCount,
        pageIndex: pageIndex,
        pageIndexChange: pageIndexChange
    }), !isLargeDisplayMode && (0, _inferno.createComponentVNode)(2, _small.PagesSmall, {
        pageCount: pageCount,
        pageIndex: pageIndex,
        pageIndexChange: pageIndexChange,
        pagesCountText: pagesCountText
    }), renderNextButton && (0, _inferno.createComponentVNode)(2, _light_button.LightButton, {
        label: _message.default.getFormatter("dxPager-nextPage")(),
        className: nextButtonProps.className,
        tabIndex: nextButtonProps.tabIndex,
        onClick: nextButtonProps.navigate
    })], 0)
};
exports.viewFunction = viewFunction;

function getIncrement(direction) {
    return "next" === direction ? 1 : -1
}
const PageIndexSelectorProps = {
    isLargeDisplayMode: true
};
exports.PageIndexSelectorProps = PageIndexSelectorProps;
const PageIndexSelectorPropsType = Object.defineProperties({}, {
    pageIndex: {
        get: function() {
            return _pager_props.InternalPagerProps.pageIndex
        },
        configurable: true,
        enumerable: true
    },
    maxPagesCount: {
        get: function() {
            return _pager_props.InternalPagerProps.maxPagesCount
        },
        configurable: true,
        enumerable: true
    },
    pageCount: {
        get: function() {
            return _pager_props.InternalPagerProps.pageCount
        },
        configurable: true,
        enumerable: true
    },
    hasKnownLastPage: {
        get: function() {
            return _pager_props.InternalPagerProps.hasKnownLastPage
        },
        configurable: true,
        enumerable: true
    },
    showNavigationButtons: {
        get: function() {
            return _pager_props.InternalPagerProps.showNavigationButtons
        },
        configurable: true,
        enumerable: true
    },
    totalCount: {
        get: function() {
            return _pager_props.InternalPagerProps.totalCount
        },
        configurable: true,
        enumerable: true
    },
    isLargeDisplayMode: {
        get: function() {
            return PageIndexSelectorProps.isLargeDisplayMode
        },
        configurable: true,
        enumerable: true
    }
});
let PageIndexSelector = function(_BaseInfernoComponent) {
    _inheritsLoose(PageIndexSelector, _BaseInfernoComponent);

    function PageIndexSelector(props) {
        var _this;
        _this = _BaseInfernoComponent.call(this, props) || this;
        _this.state = {};
        _this.__getterCache = {};
        _this.pageIndexChange = _this.pageIndexChange.bind(_assertThisInitialized(_this));
        _this.getButtonProps = _this.getButtonProps.bind(_assertThisInitialized(_this));
        _this.canNavigateToPage = _this.canNavigateToPage.bind(_assertThisInitialized(_this));
        _this.getNextPageIndex = _this.getNextPageIndex.bind(_assertThisInitialized(_this));
        _this.canNavigateTo = _this.canNavigateTo.bind(_assertThisInitialized(_this));
        _this.navigateToPage = _this.navigateToPage.bind(_assertThisInitialized(_this));
        return _this
    }
    var _proto = PageIndexSelector.prototype;
    _proto.pageIndexChange = function(pageIndex) {
        if (this.canNavigateToPage(pageIndex)) {
            this.props.pageIndexChange(pageIndex)
        }
    };
    _proto.getButtonProps = function(direction) {
        var _this$config;
        const rtlAwareDirection = null !== (_this$config = this.config) && void 0 !== _this$config && _this$config.rtlEnabled ? reverseDirections[direction] : direction;
        const canNavigate = this.canNavigateTo(rtlAwareDirection);
        const className = classNames["".concat(direction).concat(canNavigate ? "Enabled" : "Disabled", "Class")];
        return {
            className: className,
            tabIndex: canNavigate ? 0 : -1,
            navigate: () => this.navigateToPage(rtlAwareDirection)
        }
    };
    _proto.canNavigateToPage = function(pageIndex) {
        if (!this.props.hasKnownLastPage) {
            return pageIndex >= 0
        }
        return pageIndex >= 0 && pageIndex <= this.props.pageCount - 1
    };
    _proto.getNextPageIndex = function(direction) {
        return this.props.pageIndex + getIncrement(direction)
    };
    _proto.canNavigateTo = function(direction) {
        return this.canNavigateToPage(this.getNextPageIndex(direction))
    };
    _proto.navigateToPage = function(direction) {
        this.pageIndexChange(this.getNextPageIndex(direction))
    };
    _proto.componentWillUpdate = function(nextProps, nextState, context) {
        if (this.context[_config_context.ConfigContext.id] !== context[_config_context.ConfigContext.id] || this.props.hasKnownLastPage !== nextProps.hasKnownLastPage || this.props.pageCount !== nextProps.pageCount || this.props.pageIndex !== nextProps.pageIndex || this.props.pageIndexChange !== nextProps.pageIndexChange) {
            this.__getterCache.prevButtonProps = void 0
        }
        if (this.context[_config_context.ConfigContext.id] !== context[_config_context.ConfigContext.id] || this.props.hasKnownLastPage !== nextProps.hasKnownLastPage || this.props.pageCount !== nextProps.pageCount || this.props.pageIndex !== nextProps.pageIndex || this.props.pageIndexChange !== nextProps.pageIndexChange) {
            this.__getterCache.nextButtonProps = void 0
        }
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props),
            config: this.config,
            pageIndexChange: this.pageIndexChange,
            renderPrevButton: this.renderPrevButton,
            renderNextButton: this.renderNextButton,
            prevButtonProps: this.prevButtonProps,
            nextButtonProps: this.nextButtonProps,
            restAttributes: this.restAttributes
        })
    };
    _createClass(PageIndexSelector, [{
        key: "config",
        get: function() {
            if (this.context[_config_context.ConfigContext.id]) {
                return this.context[_config_context.ConfigContext.id]
            }
            return _config_context.ConfigContext.defaultValue
        }
    }, {
        key: "renderPrevButton",
        get: function() {
            const {
                isLargeDisplayMode: isLargeDisplayMode,
                showNavigationButtons: showNavigationButtons
            } = this.props;
            return !isLargeDisplayMode || showNavigationButtons
        }
    }, {
        key: "renderNextButton",
        get: function() {
            return this.renderPrevButton || !this.props.hasKnownLastPage
        }
    }, {
        key: "prevButtonProps",
        get: function() {
            if (void 0 !== this.__getterCache.prevButtonProps) {
                return this.__getterCache.prevButtonProps
            }
            return this.__getterCache.prevButtonProps = (() => this.getButtonProps("prev"))()
        }
    }, {
        key: "nextButtonProps",
        get: function() {
            if (void 0 !== this.__getterCache.nextButtonProps) {
                return this.__getterCache.nextButtonProps
            }
            return this.__getterCache.nextButtonProps = (() => this.getButtonProps("next"))()
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props, _excluded);
            return restProps
        }
    }]);
    return PageIndexSelector
}(_inferno2.BaseInfernoComponent);
exports.PageIndexSelector = PageIndexSelector;
PageIndexSelector.defaultProps = PageIndexSelectorPropsType;
