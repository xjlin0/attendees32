/**
 * DevExtreme (renovation/ui/pager/pages/small.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.PagesSmall = exports.PagerSmallProps = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _page = require("./page");
var _info = require("../info");
var _number_box = require("../../editors/number_box");
var _message = _interopRequireDefault(require("../../../../localization/message"));
var _calculate_values_fitted_width = require("../utils/calculate_values_fitted_width");
var _get_element_width = require("../utils/get_element_width");
var _pager_props = require("../common/pager_props");
const _excluded = ["inputAttr", "pageCount", "pageIndex", "pageIndexChange", "pagesCountText"];

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _assertThisInitialized(self) {
    if (void 0 === self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
    }
    return self
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}
const PAGER_INFO_TEXT_CLASS = "".concat(_info.PAGER_INFO_CLASS, "  dx-info-text");
const PAGER_PAGE_INDEX_CLASS = "dx-page-index";
const LIGHT_PAGES_CLASS = "dx-light-pages";
const PAGER_PAGES_COUNT_CLASS = "dx-pages-count";
const viewFunction = _ref => {
    let {
        pageIndexRef: pageIndexRef,
        pagesCountText: pagesCountText,
        props: {
            inputAttr: inputAttr,
            pageCount: pageCount
        },
        selectLastPageIndex: selectLastPageIndex,
        value: value,
        valueChange: valueChange,
        width: width
    } = _ref;
    return (0, _inferno.createVNode)(1, "div", "dx-light-pages", [(0, _inferno.createComponentVNode)(2, _number_box.NumberBox, {
        className: "dx-page-index",
        min: 1,
        max: Math.max(pageCount, value),
        width: width,
        value: value,
        valueChange: valueChange,
        inputAttr: inputAttr
    }), (0, _inferno.createVNode)(1, "span", PAGER_INFO_TEXT_CLASS, pagesCountText, 0), (0, _inferno.createComponentVNode)(2, _page.Page, {
        className: "dx-pages-count",
        selected: false,
        index: pageCount - 1,
        onClick: selectLastPageIndex
    })], 4, null, null, pageIndexRef)
};
exports.viewFunction = viewFunction;
const PagerSmallProps = {
    inputAttr: Object.freeze({
        "aria-label": _message.default.format("dxPager-ariaPageNumber")
    })
};
exports.PagerSmallProps = PagerSmallProps;
const PagerSmallPropsType = Object.defineProperties({}, {
    pageIndex: {
        get: function() {
            return _pager_props.InternalPagerProps.pageIndex
        },
        configurable: true,
        enumerable: true
    },
    pageCount: {
        get: function() {
            return _pager_props.InternalPagerProps.pageCount
        },
        configurable: true,
        enumerable: true
    },
    inputAttr: {
        get: function() {
            return PagerSmallProps.inputAttr
        },
        configurable: true,
        enumerable: true
    }
});
let PagesSmall = function(_InfernoComponent) {
    _inheritsLoose(PagesSmall, _InfernoComponent);

    function PagesSmall(props) {
        var _this;
        _this = _InfernoComponent.call(this, props) || this;
        _this.pageIndexRef = (0, _inferno.createRef)();
        _this.state = {
            minWidth: 10
        };
        _this.updateWidth = _this.updateWidth.bind(_assertThisInitialized(_this));
        _this.selectLastPageIndex = _this.selectLastPageIndex.bind(_assertThisInitialized(_this));
        _this.valueChange = _this.valueChange.bind(_assertThisInitialized(_this));
        return _this
    }
    var _proto = PagesSmall.prototype;
    _proto.createEffects = function() {
        return [new _inferno2.InfernoEffect(this.updateWidth, [this.state.minWidth])]
    };
    _proto.updateEffects = function() {
        var _this$_effects$;
        null === (_this$_effects$ = this._effects[0]) || void 0 === _this$_effects$ ? void 0 : _this$_effects$.update([this.state.minWidth])
    };
    _proto.updateWidth = function() {
        var _this$pageIndexRef$cu;
        const el = null === (_this$pageIndexRef$cu = this.pageIndexRef.current) || void 0 === _this$pageIndexRef$cu ? void 0 : _this$pageIndexRef$cu.querySelector(".".concat("dx-page-index"));
        this.setState(__state_argument => ({
            minWidth: el && (0, _get_element_width.getElementMinWidth)(el) || __state_argument.minWidth
        }))
    };
    _proto.selectLastPageIndex = function() {
        this.props.pageIndexChange(this.props.pageCount - 1)
    };
    _proto.valueChange = function(value) {
        this.props.pageIndexChange(value - 1)
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props),
            pageIndexRef: this.pageIndexRef,
            value: this.value,
            width: this.width,
            pagesCountText: this.pagesCountText,
            selectLastPageIndex: this.selectLastPageIndex,
            valueChange: this.valueChange,
            restAttributes: this.restAttributes
        })
    };
    _createClass(PagesSmall, [{
        key: "value",
        get: function() {
            return this.props.pageIndex + 1
        }
    }, {
        key: "width",
        get: function() {
            const {
                pageCount: pageCount
            } = this.props;
            return (0, _calculate_values_fitted_width.calculateValuesFittedWidth)(this.state.minWidth, [pageCount])
        }
    }, {
        key: "pagesCountText",
        get: function() {
            var _this$props$pagesCoun;
            return (null !== (_this$props$pagesCoun = this.props.pagesCountText) && void 0 !== _this$props$pagesCoun ? _this$props$pagesCoun : "") || _message.default.getFormatter("dxPager-pagesCountText")()
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props, _excluded);
            return restProps
        }
    }]);
    return PagesSmall
}(_inferno2.InfernoComponent);
exports.PagesSmall = PagesSmall;
PagesSmall.defaultProps = PagerSmallPropsType;
