/**
 * DevExtreme (renovation/ui/toolbar/toolbar.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.Toolbar = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _toolbar = _interopRequireDefault(require("../../../ui/toolbar"));
var _dom_component_wrapper = require("../common/dom_component_wrapper");
var _toolbar_props = require("./toolbar_props");
var _type = require("../../../core/utils/type");
var _config_context = require("../../common/config_context");
var _resolve_rtl = require("../../utils/resolve_rtl");
const _excluded = ["accessKey", "activeStateEnabled", "className", "disabled", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "items", "onClick", "onKeyDown", "rtlEnabled", "tabIndex", "visible", "width"];

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const viewFunction = _ref => {
    let {
        componentProps: componentProps,
        restAttributes: restAttributes
    } = _ref;
    return (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, _dom_component_wrapper.DomComponentWrapper, _extends({
        componentType: _toolbar.default,
        componentProps: componentProps,
        templateNames: []
    }, restAttributes)))
};
exports.viewFunction = viewFunction;
let Toolbar = function(_BaseInfernoComponent) {
    _inheritsLoose(Toolbar, _BaseInfernoComponent);

    function Toolbar(props) {
        var _this;
        _this = _BaseInfernoComponent.call(this, props) || this;
        _this.state = {};
        _this.__getterCache = {};
        return _this
    }
    var _proto = Toolbar.prototype;
    _proto.componentWillUpdate = function(nextProps, nextState, context) {
        if (this.props.items !== nextProps.items || this.props.rtlEnabled !== nextProps.rtlEnabled || this.context[_config_context.ConfigContext.id] !== context[_config_context.ConfigContext.id] || this.props !== nextProps) {
            this.__getterCache.componentProps = void 0
        }
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props),
            config: this.config,
            componentProps: this.componentProps,
            resolvedRtlEnabled: this.resolvedRtlEnabled,
            restAttributes: this.restAttributes
        })
    };
    _createClass(Toolbar, [{
        key: "config",
        get: function() {
            if (this.context[_config_context.ConfigContext.id]) {
                return this.context[_config_context.ConfigContext.id]
            }
            return _config_context.ConfigContext.defaultValue
        }
    }, {
        key: "componentProps",
        get: function() {
            if (void 0 !== this.__getterCache.componentProps) {
                return this.__getterCache.componentProps
            }
            return this.__getterCache.componentProps = (() => {
                const {
                    items: items
                } = this.props;
                const toolbarItems = null === items || void 0 === items ? void 0 : items.map(item => {
                    var _item$options, _options$rtlEnabled;
                    if (!(0, _type.isObject)(item)) {
                        return item
                    }
                    const options = null !== (_item$options = item.options) && void 0 !== _item$options ? _item$options : {};
                    options.rtlEnabled = null !== (_options$rtlEnabled = options.rtlEnabled) && void 0 !== _options$rtlEnabled ? _options$rtlEnabled : this.resolvedRtlEnabled;
                    return _extends({}, item, {
                        options: options
                    })
                });
                return _extends({}, this.props, {
                    items: toolbarItems
                })
            })()
        }
    }, {
        key: "resolvedRtlEnabled",
        get: function() {
            const {
                rtlEnabled: rtlEnabled
            } = this.props;
            return !!(0, _resolve_rtl.resolveRtlEnabled)(rtlEnabled, this.config)
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props, _excluded);
            return restProps
        }
    }]);
    return Toolbar
}(_inferno2.BaseInfernoComponent);
exports.Toolbar = Toolbar;
Toolbar.defaultProps = _toolbar_props.ToolbarProps;
