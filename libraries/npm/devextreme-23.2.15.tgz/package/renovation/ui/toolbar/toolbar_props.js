/**
 * DevExtreme (renovation/ui/toolbar/toolbar_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.ToolbarTextBoxProps = exports.ToolbarProps = exports.ToolbarItemType = exports.ToolbarItem = exports.ToolbarDropDownButtonProps = exports.ToolbarDropDownButtonItemPropsType = exports.ToolbarDropDownButtonItemProps = exports.ToolbarCheckBoxProps = exports.ToolbarButtonProps = exports.ToolbarButtonGroupProps = exports.CollectionWidgetItem = exports.BaseToolbarItemProps = void 0;
var _base_props = require("../common/base_props");

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const CollectionWidgetItem = {};
exports.CollectionWidgetItem = CollectionWidgetItem;
const BaseToolbarItemProps = {};
exports.BaseToolbarItemProps = BaseToolbarItemProps;
const ToolbarTextBoxProps = Object.create(Object.prototype, _extends(Object.getOwnPropertyDescriptors(BaseToolbarItemProps), Object.getOwnPropertyDescriptors({
    value: ""
})));
exports.ToolbarTextBoxProps = ToolbarTextBoxProps;
const ToolbarCheckBoxProps = Object.create(Object.prototype, _extends(Object.getOwnPropertyDescriptors(BaseToolbarItemProps), Object.getOwnPropertyDescriptors({
    value: false
})));
exports.ToolbarCheckBoxProps = ToolbarCheckBoxProps;
const ToolbarButtonGroupProps = BaseToolbarItemProps;
exports.ToolbarButtonGroupProps = ToolbarButtonGroupProps;
const ToolbarButtonProps = BaseToolbarItemProps;
exports.ToolbarButtonProps = ToolbarButtonProps;
const ToolbarDropDownButtonItemProps = CollectionWidgetItem;
exports.ToolbarDropDownButtonItemProps = ToolbarDropDownButtonItemProps;
const ToolbarDropDownButtonItemPropsType = {};
exports.ToolbarDropDownButtonItemPropsType = ToolbarDropDownButtonItemPropsType;
const ToolbarDropDownButtonProps = BaseToolbarItemProps;
exports.ToolbarDropDownButtonProps = ToolbarDropDownButtonProps;
const ToolbarItem = CollectionWidgetItem;
exports.ToolbarItem = ToolbarItem;
const ToolbarItemType = {};
exports.ToolbarItemType = ToolbarItemType;
const ToolbarProps = _base_props.BaseWidgetProps;
exports.ToolbarProps = ToolbarProps;
