/**
 * DevExtreme (renovation/ui/common/base_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.BaseWidgetProps = void 0;
const BaseWidgetProps = {
    className: "",
    activeStateEnabled: false,
    disabled: false,
    focusStateEnabled: false,
    hoverStateEnabled: false,
    tabIndex: 0,
    visible: true
};
exports.BaseWidgetProps = BaseWidgetProps;
