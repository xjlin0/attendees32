/**
 * DevExtreme (renovation/ui/common/icon.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.IconProps = exports.Icon = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _icon = require("../../../core/utils/icon");
var _combine_classes = require("../../utils/combine_classes");
const _excluded = ["iconTemplate", "position", "source"];

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const viewFunction = _ref => {
    let {
        iconClassName: iconClassName,
        props: {
            iconTemplate: IconTemplate,
            source: source
        },
        sourceType: sourceType
    } = _ref;
    return (0, _inferno.createFragment)(["dxIcon" === sourceType && (0, _inferno.createVNode)(1, "i", iconClassName), "fontIcon" === sourceType && (0, _inferno.createVNode)(1, "i", iconClassName), "image" === sourceType && (0, _inferno.createVNode)(1, "img", iconClassName, null, 1, {
        alt: "",
        src: source
    }), IconTemplate && (0, _inferno.createVNode)(1, "i", iconClassName, IconTemplate({}), 0)], 0)
};
exports.viewFunction = viewFunction;
const IconProps = {
    position: "left",
    source: ""
};
exports.IconProps = IconProps;
const getTemplate = TemplateProp => TemplateProp && (TemplateProp.defaultProps ? props => (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, TemplateProp, _extends({}, props))) : TemplateProp);
let Icon = function(_BaseInfernoComponent) {
    _inheritsLoose(Icon, _BaseInfernoComponent);

    function Icon(props) {
        var _this;
        _this = _BaseInfernoComponent.call(this, props) || this;
        _this.state = {};
        return _this
    }
    var _proto = Icon.prototype;
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props, {
                iconTemplate: (TemplateProp = props.iconTemplate, TemplateProp && (TemplateProp.defaultProps ? props => (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, TemplateProp, _extends({}, props))) : TemplateProp))
            }),
            sourceType: this.sourceType,
            cssClass: this.cssClass,
            iconClassName: this.iconClassName,
            restAttributes: this.restAttributes
        });
        var TemplateProp
    };
    _createClass(Icon, [{
        key: "sourceType",
        get: function() {
            return (0, _icon.getImageSourceType)(this.props.source)
        }
    }, {
        key: "cssClass",
        get: function() {
            return "left" !== this.props.position ? "dx-icon-right" : ""
        }
    }, {
        key: "iconClassName",
        get: function() {
            const generalClasses = {
                "dx-icon": true,
                [this.cssClass]: !!this.cssClass
            };
            const {
                source: source
            } = this.props;
            if ("dxIcon" === this.sourceType) {
                return (0, _combine_classes.combineClasses)(_extends({}, generalClasses, {
                    ["dx-icon-".concat(source)]: true
                }))
            }
            if ("fontIcon" === this.sourceType) {
                return (0, _combine_classes.combineClasses)(_extends({}, generalClasses, {
                    [String(source)]: !!source
                }))
            }
            if ("image" === this.sourceType) {
                return (0, _combine_classes.combineClasses)(generalClasses)
            }
            if ("svg" === this.sourceType) {
                return (0, _combine_classes.combineClasses)(_extends({}, generalClasses, {
                    "dx-svg-icon": true
                }))
            }
            return ""
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props, _excluded);
            return restProps
        }
    }]);
    return Icon
}(_inferno2.BaseInfernoComponent);
exports.Icon = Icon;
Icon.defaultProps = IconProps;
