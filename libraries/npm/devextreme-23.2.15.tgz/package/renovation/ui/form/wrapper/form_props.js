/**
 * DevExtreme (renovation/ui/form/wrapper/form_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.FormProps = void 0;
var _base_props = require("../../common/base_props");
const FormProps = _base_props.BaseWidgetProps;
exports.FormProps = FormProps;
