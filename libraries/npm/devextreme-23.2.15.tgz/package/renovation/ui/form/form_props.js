/**
 * DevExtreme (renovation/ui/form/form_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.FormProps = void 0;
var _screen_utils = require("../responsive_box/screen_utils");
const FormProps = {
    scrollingEnabled: false,
    screenByWidth: _screen_utils.convertToScreenSizeQualifier
};
exports.FormProps = FormProps;
