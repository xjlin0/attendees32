/**
 * DevExtreme (renovation/ui/resizable/container.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.ResizableContainerProps = exports.ResizableContainer = void 0;
exports.defaultOptions = defaultOptions;
exports.viewFunction = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _handle = require("./handle");
var _combine_classes = require("../../utils/combine_classes");
var _visibility_change = require("../../../events/visibility_change");
var _utils = require("../../../core/options/utils");
const _excluded = ["children", "disabled", "handles", "height", "mainRef", "onResize", "onResizeEnd", "onResizeStart", "rtlEnabled", "width"];

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _assertThisInitialized(self) {
    if (void 0 === self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
    }
    return self
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const getCssClasses = (disabled, rtlEnabled, isResizing) => (0, _combine_classes.combineClasses)({
    "dx-resizable": true,
    "dx-state-disabled": disabled,
    "dx-rtl": rtlEnabled,
    "dx-resizable-resizing": isResizing
});
const viewFunction = viewModel => {
    const {
        cssClasses: cssClasses,
        handles: handles,
        mainContainerRef: mainContainerRef,
        onHandleResize: onHandleResize,
        onHandleResizeEnd: onHandleResizeEnd,
        onHandleResizeStart: onHandleResizeStart,
        props: props,
        restAttributes: restAttributes,
        styles: styles
    } = viewModel;
    const {
        children: children,
        disabled: disabled
    } = props;
    return (0, _inferno.normalizeProps)((0, _inferno.createVNode)(1, "div", cssClasses, [children, handles.map(handleType => (0, _inferno.createComponentVNode)(2, _handle.ResizableHandle, {
        onResizeStart: event => onHandleResizeStart(event, handleType),
        onResize: event => onHandleResize(event, handleType),
        onResizeEnd: event => onHandleResizeEnd(event, handleType),
        disabled: disabled,
        direction: handleType
    }, handleType))], 0, _extends({
        style: (0, _inferno2.normalizeStyles)(styles)
    }, restAttributes), null, mainContainerRef))
};
exports.viewFunction = viewFunction;
const ResizableContainerProps = {
    handles: Object.freeze([]),
    children: Object.freeze([]),
    rtlEnabled: false,
    disabled: false
};
exports.ResizableContainerProps = ResizableContainerProps;
let ResizableContainer = function(_InfernoComponent) {
    _inheritsLoose(ResizableContainer, _InfernoComponent);

    function ResizableContainer(props) {
        var _this;
        _this = _InfernoComponent.call(this, props) || this;
        _this.startX = Number.NaN;
        _this.startY = Number.NaN;
        _this.mainContainerRef = (0, _inferno.createRef)();
        _this.__getterCache = {};
        _this.state = {
            isResizing: false
        };
        _this.forwardRefInitEffect = _this.forwardRefInitEffect.bind(_assertThisInitialized(_this));
        _this.onHandleResizeStart = _this.onHandleResizeStart.bind(_assertThisInitialized(_this));
        _this.onHandleResize = _this.onHandleResize.bind(_assertThisInitialized(_this));
        _this.onHandleResizeEnd = _this.onHandleResizeEnd.bind(_assertThisInitialized(_this));
        return _this
    }
    var _proto = ResizableContainer.prototype;
    _proto.createEffects = function() {
        return [new _inferno2.InfernoEffect(this.forwardRefInitEffect, [])]
    };
    _proto.forwardRefInitEffect = function() {
        if (this.props.mainRef) {
            this.props.mainRef.current = this.mainContainerRef.current
        }
        return
    };
    _proto.onHandleResizeStart = function(event, handle) {
        var _this$props$onResizeS, _this$props;
        this.setState(__state_argument => ({
            isResizing: true
        }));
        this.startX = event.clientX;
        this.startY = event.clientY;
        null === (_this$props$onResizeS = (_this$props = this.props).onResizeStart) || void 0 === _this$props$onResizeS ? void 0 : _this$props$onResizeS.call(_this$props, {
            event: event,
            handle: handle
        });
        event.targetElements = [];
        return
    };
    _proto.onHandleResize = function(event, handle) {
        const {
            onResize: onResize
        } = this.props;
        null === onResize || void 0 === onResize ? void 0 : onResize({
            event: event,
            handle: handle,
            delta: {
                x: event.clientX - this.startX,
                y: event.clientY - this.startY
            }
        });
        (0, _visibility_change.triggerResizeEvent)(this.mainContainerRef.current);
        return
    };
    _proto.onHandleResizeEnd = function(event, handle) {
        var _this$props$onResizeE, _this$props2;
        this.setState(__state_argument => ({
            isResizing: false
        }));
        this.startX = Number.NaN;
        this.startY = Number.NaN;
        null === (_this$props$onResizeE = (_this$props2 = this.props).onResizeEnd) || void 0 === _this$props$onResizeE ? void 0 : _this$props$onResizeE.call(_this$props2, {
            event: event,
            handle: handle
        });
        return
    };
    _proto.componentWillUpdate = function(nextProps, nextState, context) {
        _InfernoComponent.prototype.componentWillUpdate.call(this);
        if (this.props.handles !== nextProps.handles) {
            this.__getterCache.handles = void 0
        }
    };
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props),
            isResizing: this.state.isResizing,
            mainContainerRef: this.mainContainerRef,
            onHandleResizeStart: this.onHandleResizeStart,
            onHandleResize: this.onHandleResize,
            onHandleResizeEnd: this.onHandleResizeEnd,
            cssClasses: this.cssClasses,
            styles: this.styles,
            handles: this.handles,
            restAttributes: this.restAttributes
        })
    };
    _createClass(ResizableContainer, [{
        key: "cssClasses",
        get: function() {
            const {
                disabled: disabled,
                rtlEnabled: rtlEnabled
            } = this.props;
            return getCssClasses(!!disabled, !!rtlEnabled, this.state.isResizing)
        }
    }, {
        key: "styles",
        get: function() {
            const {
                height: height,
                width: width
            } = this.props;
            const style = this.restAttributes.style || {};
            return _extends({}, style, {
                height: height,
                width: width
            })
        }
    }, {
        key: "handles",
        get: function() {
            if (void 0 !== this.__getterCache.handles) {
                return this.__getterCache.handles
            }
            return this.__getterCache.handles = (() => {
                let {
                    handles: handles
                } = this.props;
                if ("string" === typeof handles) {
                    handles = [handles]
                }
                const result = handles.map(handle => handle);
                if (result.includes("bottom")) {
                    result.includes("right") && result.push("corner-bottom-right");
                    result.includes("left") && result.push("corner-bottom-left")
                }
                if (result.includes("top")) {
                    result.includes("right") && result.push("corner-top-right");
                    result.includes("left") && result.push("corner-top-left")
                }
                return result
            })()
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props3 = this.props,
                restProps = _objectWithoutPropertiesLoose(_this$props3, _excluded);
            return restProps
        }
    }]);
    return ResizableContainer
}(_inferno2.InfernoComponent);
exports.ResizableContainer = ResizableContainer;
ResizableContainer.defaultProps = Object.create(Object.prototype, _extends(Object.getOwnPropertyDescriptors(ResizableContainerProps), Object.getOwnPropertyDescriptors(_extends({}, (0, _utils.convertRulesToOptions)([])))));
const __defaultOptionRules = [];

function defaultOptions(rule) {
    __defaultOptionRules.push(rule);
    ResizableContainer.defaultProps = Object.create(Object.prototype, _extends(Object.getOwnPropertyDescriptors(ResizableContainer.defaultProps), Object.getOwnPropertyDescriptors((0, _utils.convertRulesToOptions)([])), Object.getOwnPropertyDescriptors((0, _utils.convertRulesToOptions)(__defaultOptionRules))))
}
