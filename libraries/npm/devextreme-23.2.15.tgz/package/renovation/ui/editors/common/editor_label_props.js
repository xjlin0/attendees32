/**
 * DevExtreme (renovation/ui/editors/common/editor_label_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.EditorLabelProps = void 0;
var _themes = require("../../../../ui/themes");
const EditorLabelProps = Object.defineProperties({
    label: ""
}, {
    labelMode: {
        get: function() {
            return (0, _themes.isMaterial)((0, _themes.current)()) ? "floating" : "static"
        },
        configurable: true,
        enumerable: true
    }
});
exports.EditorLabelProps = EditorLabelProps;
