/**
 * DevExtreme (renovation/ui/editors/common/editor_state_props.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.EditorStateProps = void 0;
var _devices = _interopRequireDefault(require("../../../../core/devices"));

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}
const EditorStateProps = Object.defineProperties({
    hoverStateEnabled: true,
    activeStateEnabled: true
}, {
    focusStateEnabled: {
        get: function() {
            return "desktop" === _devices.default.real().deviceType && !_devices.default.isSimulator()
        },
        configurable: true,
        enumerable: true
    }
});
exports.EditorStateProps = EditorStateProps;
