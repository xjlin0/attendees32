/**
 * DevExtreme (renovation/ui/editors/text_box.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.viewFunction = exports.TextBoxPropsType = exports.TextBoxProps = exports.TextBox = void 0;
var _inferno = require("inferno");
var _inferno2 = require("@devextreme/runtime/inferno");
var _text_box = _interopRequireDefault(require("../../../ui/text_box"));
var _dom_component_wrapper = require("../common/dom_component_wrapper");
var _editor = require("./common/editor");
var _editor_state_props = require("./common/editor_state_props");
var _editor_label_props = require("./common/editor_label_props");
var _text_editor_props = require("./common/text_editor_props");
const _excluded = ["accessKey", "activeStateEnabled", "buttons", "className", "defaultValue", "disabled", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "inputAttr", "isDirty", "isValid", "label", "labelMode", "mask", "maskChar", "maskInvalidMessage", "maskRules", "maxLength", "mode", "name", "onClick", "onFocusIn", "onKeyDown", "readOnly", "rtlEnabled", "showClearButton", "showMaskMode", "spellCheck", "stylingMode", "tabIndex", "useMaskedValue", "validationError", "validationErrors", "validationMessageMode", "validationMessagePosition", "validationStatus", "value", "valueChange", "valueChangeEvent", "visible", "width"];

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function _objectWithoutPropertiesLoose(source, excluded) {
    if (null == source) {
        return {}
    }
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) {
            continue
        }
        target[key] = source[key]
    }
    return target
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) {
            descriptor.writable = true
        }
        Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor)
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) {
        _defineProperties(Constructor.prototype, protoProps)
    }
    if (staticProps) {
        _defineProperties(Constructor, staticProps)
    }
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor
}

function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return "symbol" === typeof key ? key : String(key)
}

function _toPrimitive(input, hint) {
    if ("object" !== typeof input || null === input) {
        return input
    }
    var prim = input[Symbol.toPrimitive];
    if (void 0 !== prim) {
        var res = prim.call(input, hint || "default");
        if ("object" !== typeof res) {
            return res
        }
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return ("string" === hint ? String : Number)(input)
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}

function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key]
                }
            }
        }
        return target
    };
    return _extends.apply(this, arguments)
}
const viewFunction = _ref => {
    let {
        componentProps: componentProps,
        restAttributes: restAttributes
    } = _ref;
    return (0, _inferno.normalizeProps)((0, _inferno.createComponentVNode)(2, _dom_component_wrapper.DomComponentWrapper, _extends({
        componentType: _text_box.default,
        componentProps: componentProps,
        templateNames: []
    }, restAttributes)))
};
exports.viewFunction = viewFunction;
const TextBoxProps = Object.create(Object.prototype, _extends(Object.getOwnPropertyDescriptors(_editor.EditorProps), Object.getOwnPropertyDescriptors({
    mask: "",
    maskChar: "_",
    maskInvalidMessage: "Value is invalid",
    maskRules: Object.freeze({}),
    mode: "text",
    showClearButton: false,
    showMaskMode: "always",
    useMaskedValue: false,
    isReactComponentWrapper: true
})));
exports.TextBoxProps = TextBoxProps;
const TextBoxPropsType = Object.defineProperties({
    isReactComponentWrapper: true
}, {
    mask: {
        get: function() {
            return TextBoxProps.mask
        },
        configurable: true,
        enumerable: true
    },
    maskChar: {
        get: function() {
            return TextBoxProps.maskChar
        },
        configurable: true,
        enumerable: true
    },
    maskInvalidMessage: {
        get: function() {
            return TextBoxProps.maskInvalidMessage
        },
        configurable: true,
        enumerable: true
    },
    maskRules: {
        get: function() {
            return TextBoxProps.maskRules
        },
        configurable: true,
        enumerable: true
    },
    mode: {
        get: function() {
            return TextBoxProps.mode
        },
        configurable: true,
        enumerable: true
    },
    showClearButton: {
        get: function() {
            return TextBoxProps.showClearButton
        },
        configurable: true,
        enumerable: true
    },
    showMaskMode: {
        get: function() {
            return TextBoxProps.showMaskMode
        },
        configurable: true,
        enumerable: true
    },
    useMaskedValue: {
        get: function() {
            return TextBoxProps.useMaskedValue
        },
        configurable: true,
        enumerable: true
    },
    readOnly: {
        get: function() {
            return TextBoxProps.readOnly
        },
        configurable: true,
        enumerable: true
    },
    name: {
        get: function() {
            return TextBoxProps.name
        },
        configurable: true,
        enumerable: true
    },
    validationError: {
        get: function() {
            return TextBoxProps.validationError
        },
        configurable: true,
        enumerable: true
    },
    validationErrors: {
        get: function() {
            return TextBoxProps.validationErrors
        },
        configurable: true,
        enumerable: true
    },
    validationMessageMode: {
        get: function() {
            return TextBoxProps.validationMessageMode
        },
        configurable: true,
        enumerable: true
    },
    validationMessagePosition: {
        get: function() {
            return TextBoxProps.validationMessagePosition
        },
        configurable: true,
        enumerable: true
    },
    validationStatus: {
        get: function() {
            return TextBoxProps.validationStatus
        },
        configurable: true,
        enumerable: true
    },
    isValid: {
        get: function() {
            return TextBoxProps.isValid
        },
        configurable: true,
        enumerable: true
    },
    isDirty: {
        get: function() {
            return TextBoxProps.isDirty
        },
        configurable: true,
        enumerable: true
    },
    defaultValue: {
        get: function() {
            return _text_editor_props.TextEditorProps.defaultValue
        },
        configurable: true,
        enumerable: true
    },
    className: {
        get: function() {
            return TextBoxProps.className
        },
        configurable: true,
        enumerable: true
    },
    activeStateEnabled: {
        get: function() {
            return _editor_state_props.EditorStateProps.activeStateEnabled
        },
        configurable: true,
        enumerable: true
    },
    disabled: {
        get: function() {
            return TextBoxProps.disabled
        },
        configurable: true,
        enumerable: true
    },
    focusStateEnabled: {
        get: function() {
            return _editor_state_props.EditorStateProps.focusStateEnabled
        },
        configurable: true,
        enumerable: true
    },
    hoverStateEnabled: {
        get: function() {
            return _editor_state_props.EditorStateProps.hoverStateEnabled
        },
        configurable: true,
        enumerable: true
    },
    tabIndex: {
        get: function() {
            return TextBoxProps.tabIndex
        },
        configurable: true,
        enumerable: true
    },
    visible: {
        get: function() {
            return TextBoxProps.visible
        },
        configurable: true,
        enumerable: true
    },
    label: {
        get: function() {
            return _editor_label_props.EditorLabelProps.label
        },
        configurable: true,
        enumerable: true
    },
    labelMode: {
        get: function() {
            return _editor_label_props.EditorLabelProps.labelMode
        },
        configurable: true,
        enumerable: true
    },
    maxLength: {
        get: function() {
            return _text_editor_props.TextEditorProps.maxLength
        },
        configurable: true,
        enumerable: true
    },
    spellCheck: {
        get: function() {
            return _text_editor_props.TextEditorProps.spellCheck
        },
        configurable: true,
        enumerable: true
    },
    valueChangeEvent: {
        get: function() {
            return _text_editor_props.TextEditorProps.valueChangeEvent
        },
        configurable: true,
        enumerable: true
    },
    stylingMode: {
        get: function() {
            return _text_editor_props.TextEditorProps.stylingMode
        },
        configurable: true,
        enumerable: true
    }
});
exports.TextBoxPropsType = TextBoxPropsType;
let TextBox = function(_BaseInfernoComponent) {
    _inheritsLoose(TextBox, _BaseInfernoComponent);

    function TextBox(props) {
        var _this;
        _this = _BaseInfernoComponent.call(this, props) || this;
        _this.state = {
            value: void 0 !== _this.props.value ? _this.props.value : _this.props.defaultValue
        };
        return _this
    }
    var _proto = TextBox.prototype;
    _proto.render = function() {
        const props = this.props;
        return viewFunction({
            props: _extends({}, props, {
                value: void 0 !== this.props.value ? this.props.value : this.state.value
            }),
            componentProps: this.componentProps,
            restAttributes: this.restAttributes
        })
    };
    _createClass(TextBox, [{
        key: "componentProps",
        get: function() {
            return _extends({}, this.props, {
                value: void 0 !== this.props.value ? this.props.value : this.state.value
            })
        }
    }, {
        key: "restAttributes",
        get: function() {
            const _this$props$value = _extends({}, this.props, {
                    value: void 0 !== this.props.value ? this.props.value : this.state.value
                }),
                restProps = _objectWithoutPropertiesLoose(_this$props$value, _excluded);
            return restProps
        }
    }]);
    return TextBox
}(_inferno2.BaseInfernoComponent);
exports.TextBox = TextBox;
TextBox.defaultProps = TextBoxPropsType;
