/**
 * DevExtreme (renovation/component_wrapper/grid_pager.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.GridPagerWrapper = void 0;
var _component = _interopRequireDefault(require("./common/component"));

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass)
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, p) {
        o.__proto__ = p;
        return o
    };
    return _setPrototypeOf(o, p)
}
let GridPagerWrapper = function(_Component) {
    _inheritsLoose(GridPagerWrapper, _Component);

    function GridPagerWrapper() {
        return _Component.apply(this, arguments) || this
    }
    var _proto = GridPagerWrapper.prototype;
    _proto._optionChanged = function(args) {
        switch (args.name) {
            case "pageIndex": {
                const pageIndexChanged = this.option("pageIndexChanged");
                if (pageIndexChanged) {
                    pageIndexChanged(args.value)
                }
                break
            }
            case "pageSize": {
                const pageSizeChanged = this.option("pageSizeChanged");
                if (pageSizeChanged) {
                    pageSizeChanged(args.value)
                }
                break
            }
        }
        _Component.prototype._optionChanged.call(this, args)
    };
    return GridPagerWrapper
}(_component.default);
exports.GridPagerWrapper = GridPagerWrapper;
