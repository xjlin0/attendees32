/**
 * DevExtreme (renovation/utils/render_template.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.renderTemplate = renderTemplate;
var _inferno = require("inferno");
var _infernoCreateElement = require("inferno-create-element");

function renderTemplate(template, props, container) {
    setTimeout(() => {
        (0, _inferno.render)((0, _infernoCreateElement.createElement)(template, props), null === container || void 0 === container ? void 0 : container.get(0))
    }, 0)
}
