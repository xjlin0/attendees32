/**
 * DevExtreme (renovation/utils/shallow_equals.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.shallowEquals = void 0;
const shallowEquals = (firstObject, secondObject) => {
    if (Object.keys(firstObject).length !== Object.keys(secondObject).length) {
        return false
    }
    return Object.keys(firstObject).every(key => firstObject[key] === secondObject[key])
};
exports.shallowEquals = shallowEquals;
