/**
 * DevExtreme (renovation/utils/getThemeType.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.default = void 0;
var _themes = require("../../ui/themes");
const getThemeType = () => {
    const theme = (0, _themes.current)();
    return {
        isCompact: (0, _themes.isCompact)(theme),
        isMaterial: (0, _themes.isMaterial)(theme),
        isFluent: (0, _themes.isFluent)(theme),
        isMaterialBased: (0, _themes.isMaterialBased)(theme)
    }
};
var _default = getThemeType;
exports.default = _default;
module.exports = exports.default;
module.exports.default = exports.default;
