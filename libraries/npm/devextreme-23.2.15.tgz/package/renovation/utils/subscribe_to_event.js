/**
 * DevExtreme (renovation/utils/subscribe_to_event.js)
 * Version: 23.2.15
 * Build date: Mon Nov 10 2025
 *
 * Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
exports.subscribeToDxInactiveEvent = exports.subscribeToDxHoverStartEvent = exports.subscribeToDxHoverEndEvent = exports.subscribeToDxFocusOutEvent = exports.subscribeToDxFocusInEvent = exports.subscribeToDxActiveEvent = exports.subscribeToDXScrollStopEvent = exports.subscribeToDXScrollStartEvent = exports.subscribeToDXScrollMoveEvent = exports.subscribeToDXScrollEndEvent = exports.subscribeToDXScrollCancelEvent = exports.subscribeToDXPointerUpEvent = exports.subscribeToDXPointerMoveEvent = exports.subscribeToDXPointerDownEvent = exports.subscribeToClickEvent = void 0;
exports.subscribeToEvent = subscribeToEvent;
exports.subscribeToScrollInitEvent = exports.subscribeToScrollEvent = exports.subscribeToMouseLeaveEvent = exports.subscribeToMouseEnterEvent = exports.subscribeToKeyDownEvent = void 0;
var _events_engine = _interopRequireDefault(require("../../events/core/events_engine"));
var clickEvent = _interopRequireWildcard(require("../../events/click"));
var _index = require("../../events/utils/index");
var _emitterGesture = _interopRequireDefault(require("../../events/gesture/emitter.gesture.scroll"));
var _pointer = _interopRequireDefault(require("../../events/pointer"));

function _getRequireWildcardCache(nodeInterop) {
    if ("function" !== typeof WeakMap) {
        return null
    }
    var cacheBabelInterop = new WeakMap;
    var cacheNodeInterop = new WeakMap;
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop
    })(nodeInterop)
}

function _interopRequireWildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj
    }
    if (null === obj || "object" !== typeof obj && "function" !== typeof obj) {
        return {
            default: obj
        }
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj)
    }
    var newObj = {};
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var key in obj) {
        if ("default" !== key && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc)
            } else {
                newObj[key] = obj[key]
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj)
    }
    return newObj
}

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    }
}

function subscribeToEvent(eventName) {
    return (element, handler, eventData, namespace) => {
        const event = namespace ? (0, _index.addNamespace)(eventName, namespace) : eventName;
        if (handler) {
            _events_engine.default.on(element, event, eventData, handler);
            return () => {
                _events_engine.default.off(element, event, handler)
            }
        }
        return
    }
}
const subscribeToClickEvent = subscribeToEvent(clickEvent.name);
exports.subscribeToClickEvent = subscribeToClickEvent;
const subscribeToScrollEvent = subscribeToEvent(_emitterGesture.default.scroll);
exports.subscribeToScrollEvent = subscribeToScrollEvent;
const subscribeToScrollInitEvent = subscribeToEvent(_emitterGesture.default.init);
exports.subscribeToScrollInitEvent = subscribeToScrollInitEvent;
const subscribeToDXScrollStartEvent = subscribeToEvent(_emitterGesture.default.start);
exports.subscribeToDXScrollStartEvent = subscribeToDXScrollStartEvent;
const subscribeToDXScrollMoveEvent = subscribeToEvent(_emitterGesture.default.move);
exports.subscribeToDXScrollMoveEvent = subscribeToDXScrollMoveEvent;
const subscribeToDXScrollEndEvent = subscribeToEvent(_emitterGesture.default.end);
exports.subscribeToDXScrollEndEvent = subscribeToDXScrollEndEvent;
const subscribeToDXScrollStopEvent = subscribeToEvent(_emitterGesture.default.stop);
exports.subscribeToDXScrollStopEvent = subscribeToDXScrollStopEvent;
const subscribeToDXScrollCancelEvent = subscribeToEvent(_emitterGesture.default.cancel);
exports.subscribeToDXScrollCancelEvent = subscribeToDXScrollCancelEvent;
const subscribeToDXPointerDownEvent = subscribeToEvent(_pointer.default.down);
exports.subscribeToDXPointerDownEvent = subscribeToDXPointerDownEvent;
const subscribeToDXPointerUpEvent = subscribeToEvent(_pointer.default.up);
exports.subscribeToDXPointerUpEvent = subscribeToDXPointerUpEvent;
const subscribeToDXPointerMoveEvent = subscribeToEvent(_pointer.default.move);
exports.subscribeToDXPointerMoveEvent = subscribeToDXPointerMoveEvent;
const subscribeToMouseEnterEvent = subscribeToEvent("mouseenter");
exports.subscribeToMouseEnterEvent = subscribeToMouseEnterEvent;
const subscribeToMouseLeaveEvent = subscribeToEvent("mouseleave");
exports.subscribeToMouseLeaveEvent = subscribeToMouseLeaveEvent;
const subscribeToKeyDownEvent = subscribeToEvent("keydown");
exports.subscribeToKeyDownEvent = subscribeToKeyDownEvent;
const subscribeToDxActiveEvent = subscribeToEvent("dxactive");
exports.subscribeToDxActiveEvent = subscribeToDxActiveEvent;
const subscribeToDxInactiveEvent = subscribeToEvent("dxinactive");
exports.subscribeToDxInactiveEvent = subscribeToDxInactiveEvent;
const subscribeToDxHoverStartEvent = subscribeToEvent("dxhoverstart");
exports.subscribeToDxHoverStartEvent = subscribeToDxHoverStartEvent;
const subscribeToDxHoverEndEvent = subscribeToEvent("dxhoverend");
exports.subscribeToDxHoverEndEvent = subscribeToDxHoverEndEvent;
const subscribeToDxFocusInEvent = subscribeToEvent("focusin");
exports.subscribeToDxFocusInEvent = subscribeToDxFocusInEvent;
const subscribeToDxFocusOutEvent = subscribeToEvent("focusout");
exports.subscribeToDxFocusOutEvent = subscribeToDxFocusOutEvent;
