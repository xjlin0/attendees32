/**
* DevExtreme (ui/validation_rules.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import type * as Common from '../common';

/**
 * @deprecated Use AsyncRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type AsyncRule = Common.AsyncRule;

/**
 * @deprecated Use CompareRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type CompareRule = Common.CompareRule;

/**
 * @deprecated Use CustomRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type CustomRule = Common.CustomRule;

/**
 * @deprecated Use EmailRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type EmailRule = Common.EmailRule;

/**
 * @deprecated Use NumericRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type NumericRule = Common.NumericRule;

/**
 * @deprecated Use PatternRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type PatternRule = Common.PatternRule;

/**
 * @deprecated Use RangeRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type RangeRule = Common.RangeRule;

/**
 * @deprecated Use RequiredRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type RequiredRule = Common.RequiredRule;

/**
 * @deprecated Use StringLengthRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type StringLengthRule = Common.StringLengthRule;

/**
 * @deprecated Use ValidationRule from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ValidationRule = Common.ValidationRule;

/**
 * @deprecated Use ValidationRuleType from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ValidationRuleType = Common.ValidationRuleType;

/**
 * @deprecated Use ValidationCallbackData from 'devextreme/common' instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type ValidationCallbackData = Common.ValidationCallbackData;
