/**
* DevExtreme (ui/drawer_types.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
export {
  OpenedStateMode,
  PanelLocation,
  RevealMode,
  DisposingEvent,
  InitializedEvent,
  OptionChangedEvent,
  Properties,
} from './drawer';
