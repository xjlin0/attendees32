/**
* DevExtreme (data/custom_store.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { FilterDescriptor, GroupDescriptor, LoadOptions } from './index';
import { Store, Options as StoreOptions } from './store';
import { DxExtendedPromise, DxPromise } from '../core/utils/deferred';
import { GroupItem as CustomStoreGroupItem, LoadResult } from '../common/data/custom-store';

export type Options<
    TItem = any,
    TKey = any,
> = CustomStoreOptions<TItem, TKey>;

/**
 * @deprecated Use GroupItem from common/data/custom-store instead
 */
export type GroupItem<TItem = any> = CustomStoreGroupItem<TItem>;

/**
 * Specifies returned data of the `load()` method in CustomStore.
 * @deprecated Use LoadResult instead.
 */
export type ResolvedData<TItem = any> = LoadResult<TItem>;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
type LoadFunctionResult<T> = T | DxPromise<T> | PromiseLike<T>;

/**
 * 
 * @deprecated 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface CustomStoreOptions<
    TItem = any,
    TKey = any,
> extends StoreOptions<TItem, TKey> {
    /**
     * Specifies a custom implementation of the byKey(key) method.
     */
    byKey?: ((key: TKey, extraOptions?: LoadOptions<TItem>) => PromiseLike<TItem>);
    /**
     * Specifies whether raw data should be saved in the cache. Applies only if loadMode is &apos;raw&apos;.
     */
    cacheRawData?: boolean;
    /**
     * Specifies a custom implementation of the insert(values) method.
     */
    insert?: ((values: TItem) => PromiseLike<TItem>);
    /**
     * Specifies a custom implementation of the load(options) method.
     */
    load: (options: LoadOptions<TItem>) => LoadFunctionResult<LoadResult<TItem>>;
    /**
     * Specifies how data returned by the load function is treated.
     */
    loadMode?: 'processed' | 'raw';
    /**
     * A function that is executed after data is loaded to the store.
     */
    onLoaded?: ((result: LoadResult<TItem>, loadOptions: LoadOptions<TItem>) => void);
    /**
     * Specifies a custom implementation of the remove(key) method.
     */
    remove?: ((key: TKey) => PromiseLike<void>);
    /**
     * Specifies a custom implementation of the totalCount(options) method.
     */
    totalCount?: ((loadOptions: { filter?: FilterDescriptor | Array<FilterDescriptor>; group?: GroupDescriptor<TItem> | Array<GroupDescriptor<TItem>> }) => PromiseLike<number>);
    /**
     * Specifies a custom implementation of the update(key, values) method.
     */
    update?: ((key: TKey, values: TItem) => PromiseLike<any>);
    /**
     * Specifies whether the store combines the search and filter expressions. Defaults to true if the loadMode is &apos;raw&apos; and false if it is &apos;processed&apos;.
     */
    useDefaultSearch?: boolean;
}

/**
 * The CustomStore enables you to implement custom data access logic for consuming data from any source.
 */
export default class CustomStore<
    TItem = any,
    TKey = any,
> extends Store<TItem, TKey> {
    constructor(options?: Options<TItem, TKey>);
    /**
     * Gets a data item with a specific key.
     */
    byKey(key: TKey, extraOptions?: LoadOptions<TItem>): DxPromise<TItem>;
    /**
     * Deletes data from the cache. Takes effect only if the cacheRawData property is true.
     */
    clearRawDataCache(): void;
    /**
     * Starts loading data.
     */
    load(): DxExtendedPromise<LoadResult<TItem>>;
    /**
     * Starts loading data.
     */
    load(options: LoadOptions<TItem>): DxExtendedPromise<LoadResult<TItem>>;
}
