/**
* DevExtreme (data/abstract_store.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import {
  DxExtendedPromise,
} from '../core/utils/deferred';
import {
  Store as BaseStore,
  Options as BaseStoreOptions,
} from './store';
import {
  LoadOptions,
} from './index';

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type Options<
  TItem = any,
  TKey = any,
  > = AbstractStoreOptions<TItem, TKey>;

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
interface AbstractStoreOptions<
  TItem = any,
  TKey = any,
  > extends BaseStoreOptions<TItem, TKey> {
  /**
   * A function that is executed after data is loaded to the store.
   */
  onLoaded?: ((result: Array<TItem>, loadOptions: LoadOptions<TItem>) => void);
}

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export default class AbstractStore<
  TItem = any,
  TKey = any,
  > extends BaseStore<TItem, TKey> {
  constructor(options?: Options<TItem, TKey>);
  /**
   * Starts loading data.
   */
  load(): DxExtendedPromise<Array<TItem>>;
  /**
   * Starts loading data.
   */
  load(options: LoadOptions<TItem>): DxExtendedPromise<Array<TItem>>;
}

/**
 * @deprecated Use Options from data/store instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type StoreOptions<TItem = any, TKey = any> = BaseStoreOptions<TItem, TKey>;

/**
 * @deprecated Use Store from data/store instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export type Store<TItem = any, TKey = any> = BaseStore<TItem, TKey>;
