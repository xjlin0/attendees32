/**
* DevExtreme (data/array_store.d.ts)
* Version: 23.2.15
* Build date: Mon Nov 10 2025
*
* Copyright (c) 2012 - 2025 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import Store, {
    Options as StoreOptions,
} from './abstract_store';
import { Query } from './query';
import { DxPromise } from '../core/utils/deferred';

export type Options<
    TItem = any,
    TKey = any,
> = ArrayStoreOptions<TItem, TKey>;

/**
 * 
 * @deprecated 
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface ArrayStoreOptions<
    TItem = any,
    TKey = any,
> extends StoreOptions<TItem, TKey> {
    /**
     * Specifies the store&apos;s associated array.
     */
    data?: Array<TItem>;
}

/**
 * The ArrayStore is a store that provides an interface for loading and editing an in-memory array and handling related events.
 */
export default class ArrayStore<
    TItem = any,
    TKey = any,
> extends Store<TItem, TKey> {
    constructor(options?: Options<TItem, TKey>);
    /**
     * Gets a data item with a specific key.
     */
    byKey(key: TKey): DxPromise<TItem>;
    /**
     * Clears all the ArrayStore&apos;s associated data.
     */
    clear(): void;
    /**
     * Creates a Query for the underlying array.
     */
    createQuery(): Query;
}
